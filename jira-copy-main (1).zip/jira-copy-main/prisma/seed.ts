// Demo məlumat: komanda, layihələr, sprintlər, tapşırıqlar, iş vaxtı qeydləri.
// İşə salmaq: npm run db:seed   |   Bazanı sıfırlayıb yenidən doldurmaq: npm run db:reset
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

// Təkrarlanan nəticə üçün sabit təsadüfi generator
let seed = 20261103;
const rand = () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const pick = <T,>(arr: T[]): T => arr[Math.floor(rand() * arr.length)]!;
const between = (a: number, b: number) => Math.floor(a + rand() * (b - a + 1));

const DAY = 86_400_000;
const now = new Date();
const daysAgo = (d: number, hour = 10) => {
  const x = new Date(now.getTime() - d * DAY);
  x.setHours(hour, between(0, 59), 0, 0);
  return x;
};
const addDays = (date: Date, d: number) => new Date(date.getTime() + d * DAY);
const clampPast = (d: Date) => (d.getTime() > now.getTime() - 60_000 ? new Date(now.getTime() - between(5, 300) * 60_000) : d);

async function main() {
  if ((await db.user.count()) > 0) {
    console.log("Baza artıq doludur. Sıfırlamaq üçün: npm run db:reset");
    return;
  }

  const hash = await bcrypt.hash("parol123", 10);
  const people = [
    { name: "Elvin Məmmədov", email: "admin@solo.az", role: "ADMIN", title: "Komanda rəhbəri", department: "Məhsul", avatarColor: "#0C66E4" },
    { name: "Aysel Həsənova", email: "aysel@solo.az", role: "MEMBER", title: "Frontend developer", department: "İnkişaf", avatarColor: "#AE4787" },
    { name: "Murad Əliyev", email: "murad@solo.az", role: "MEMBER", title: "Backend developer", department: "İnkişaf", avatarColor: "#22A06B" },
    { name: "Nigar Quliyeva", email: "nigar@solo.az", role: "MEMBER", title: "UI/UX dizayner", department: "Dizayn", avatarColor: "#6E5DC6" },
    { name: "Tural İsmayılov", email: "tural@solo.az", role: "MEMBER", title: "QA mühəndisi", department: "Keyfiyyət", avatarColor: "#D97008" },
    { name: "Leyla Hüseynova", email: "leyla@solo.az", role: "MEMBER", title: "Backend developer", department: "İnkişaf", avatarColor: "#1D9AAA" },
    { name: "Kamran Rzayev", email: "kamran@solo.az", role: "MEMBER", title: "DevOps mühəndisi", department: "İnfrastruktur", avatarColor: "#5B7F24" },
  ];
  const users: Awaited<ReturnType<typeof db.user.create>>[] = [];
  for (const p of people) {
    users.push(await db.user.create({ data: { ...p, passwordHash: hash, createdAt: daysAgo(120), lastSeenAt: daysAgo(between(0, 2)) } }));
  }
  const [elvin, aysel, murad, nigar, tural, leyla, kamran] = users as [(typeof users)[number], ...typeof users];
  const byName = (n: string) => users.find((u) => u.name.startsWith(n))!;

  // ---------- Layihələr ----------
  const projectDefs = [
    {
      key: "WEB", name: "Veb Platforma", type: "SCRUM", color: "#0C66E4", lead: elvin,
      description: "Şirkətin əsas veb platforması — müştəri kabineti, ödənişlər və admin panel.",
      members: [elvin, aysel, murad!, nigar!, tural!, leyla!],
    },
    {
      key: "MOB", name: "Mobil Tətbiq", type: "SCRUM", color: "#6E5DC6", lead: aysel!,
      description: "iOS və Android üçün müştəri tətbiqi.",
      members: [elvin, aysel!, murad!, nigar!, tural!],
    },
    {
      key: "OPS", name: "Dəstək və Əməliyyat", type: "KANBAN", color: "#22A06B", lead: kamran!,
      description: "İnfrastruktur, monitorinq və daxili dəstək sorğuları.",
      members: [elvin, kamran!, tural!, leyla!, murad!],
    },
  ];

  for (const def of projectDefs) {
    const project = await db.project.create({
      data: {
        key: def.key, name: def.name, type: def.type, color: def.color, description: def.description,
        leadId: def.lead!.id, createdAt: daysAgo(90),
        members: { create: def.members.map((u) => ({ userId: u!.id, role: u!.id === def.lead!.id || u!.role === "ADMIN" ? "ADMIN" : "MEMBER", joinedAt: daysAgo(90) })) },
      },
    });
    const team = def.members.map((u) => u!);
    let counter = 0;
    let rank = 0;

    // Sprintlər (yalnız Scrum)
    type S = { id: string; state: string; start: Date; end: Date };
    const sprints: S[] = [];
    if (def.type === "SCRUM") {
      const plan = def.key === "WEB"
        ? [{ s: 48, st: "COMPLETED" }, { s: 34, st: "COMPLETED" }, { s: 20, st: "COMPLETED" }, { s: 6, st: "ACTIVE" }, { s: -8, st: "PLANNED" }]
        : [{ s: 30, st: "COMPLETED" }, { s: 16, st: "COMPLETED" }, { s: 2, st: "ACTIVE" }];
      for (let i = 0; i < plan.length; i++) {
        const { s, st } = plan[i]!;
        const start = daysAgo(s, 9);
        const end = addDays(start, 14);
        const sp = await db.sprint.create({
          data: {
            projectId: project.id, name: `${def.key} Sprint ${i + 1}`, state: st,
            goal: st === "PLANNED" ? null : pick(["Ödəniş axınını tamamlamaq", "Giriş və qeydiyyatı stabil etmək", "Performans problemlərini həll etmək", "Yeni dizaynı tətbiq etmək", "Bildiriş sistemini işə salmaq"]),
            startDate: st === "PLANNED" ? null : start, endDate: st === "PLANNED" ? null : end,
            completedAt: st === "COMPLETED" ? end : null, createdAt: addDays(start, -3),
          },
        });
        sprints.push({ id: sp.id, state: st, start, end });
      }
    }

    // Epiclər
    const epicTitles: Record<string, string[]> = {
      WEB: ["İstifadəçi qeydiyyatı və giriş", "Ödəniş sistemi", "Admin panel", "Performans optimallaşdırması"],
      MOB: ["Onboarding axını", "Push bildirişlər", "Profil və parametrlər"],
      OPS: ["Monitorinq və alertlər"],
    };
    const epics: { id: string; start: Date; due: Date }[] = [];
    for (const [i, title] of epicTitles[def.key]!.entries()) {
      counter++;
      const start = daysAgo(60 - i * 12, 9);
      const due = addDays(start, between(30, 55));
      const epic = await db.issue.create({
        data: {
          projectId: project.id, number: counter, key: `${def.key}-${counter}`, type: "EPIC", title,
          status: due < now ? "DONE" : "IN_PROGRESS", priority: "HIGH", reporterId: def.lead!.id, assigneeId: def.lead!.id,
          description: `${title} üzrə bütün işləri əhatə edən epic.`, startDate: start, dueDate: due,
          rank: (rank += 1000), createdAt: addDays(start, -2), resolvedAt: due < now ? due : null,
        },
      });
      await db.activity.create({ data: { issueId: epic.id, actorId: def.lead!.id, action: "CREATED", createdAt: epic.createdAt } });
      epics.push({ id: epic.id, start, due });
    }

    const titles: Record<string, string[]> = {
      WEB: [
        "Giriş səhifəsinin dizaynını yenilə", "Şifrə bərpası e-poçtu göndərilmir", "Ödəniş forması üçün validasiya əlavə et",
        "Kart məlumatlarının şifrələnməsi", "Admin paneldə istifadəçi siyahısı", "Səhifə yüklənmə sürətini artır",
        "API cavab vaxtını 200ms-ə endir", "Mobil görünüşdə menyu açılmır", "İki faktorlu autentifikasiya",
        "Faktura PDF generasiyası", "Hesabat ixracı (Excel)", "Axtarış nəticələrində səhifələmə",
        "Sessiya müddəti bitəndə xəta", "Qaranlıq rejim dəstəyi", "Ödəniş tarixçəsi səhifəsi",
        "Rol əsaslı giriş idarəetməsi", "Şəkil yükləmə limiti 5MB", "Dashboard qrafikləri yanlış göstərir",
        "Keşləmə qatı (Redis)", "Bildiriş e-poçt şablonları", "Profil şəkli kəsilmir", "SEO meta teqləri",
        "Abunə planlarının müqayisə cədvəli", "Kupon kodu tətbiqi", "Audit log yazılması", "Tarix formatı Safari-də xətalı",
        "Qeydiyyatda telefon nömrəsi təsdiqi", "Admin üçün istifadəçini bloklama", "Lazy loading şəkillər üçün",
        "Ödəniş uğursuz olanda yenidən cəhd", "CSV idxal funksiyası", "Çoxdilli dəstək (AZ/EN/RU)",
      ],
      MOB: [
        "Onboarding ekranlarının animasiyası", "Push token qeydiyyatı", "Android-də klaviatura inputu örtür",
        "Profil redaktə ekranı", "Biometrik giriş (Face ID)", "Tətbiq açılış vaxtını azalt", "Offline rejim üçün keş",
        "iOS 18 uyğunluq testi", "Bildiriş parametrləri ekranı", "Deep link dəstəyi", "Dil seçimi ekranı",
        "Tətbiqdaxili rəy forması", "Crash: profil şəkli yükləyəndə", "Dark mode ikonları", "App Store skrinşotları",
        "Səbət ekranında qiymət yuvarlaqlaşdırılması", "Push bildiriş klikində yanlış ekran",
      ],
      OPS: [
        "Server disk sahəsi 85%-i keçib", "SSL sertifikatını yenilə", "Gecə backup skriptini yoxla", "Grafana dashboard qur",
        "Staging mühitinə deploy xətası", "Yeni əməkdaş üçün VPN girişi", "Docker image ölçüsünü azalt", "CI pipeline 20 dəq çəkir",
        "Log rotasiyası qurulmayıb", "Verilənlər bazası yavaş sorğular", "Uptime monitorinqi əlavə et", "Nginx rate limit",
        "Kubernetes node yeniləməsi", "E-poçt serverinin SPF qeydi", "Alert: yaddaş sızması (worker)", "Sentry inteqrasiyası",
        "Gitlab runner yenilənməsi", "Ofis Wi-Fi şəbəkəsi kəsilir",
      ],
    };

    const comments = [
      "Buna baxıram, bu gün sonuna qədər yeniləmə verəcəm.", "PR açdım, review edə bilərsiniz.", "Test mühitində yoxladım — işləyir ✅",
      "Bu problem yalnız Safari-də təkrarlanır.", "Dizayn faylını Figma-da yenilədim.", "Backend tərəfdə endpoint hazırdır.",
      "Bir az daha vaxt lazımdır, gözlənilməz asılılıq çıxdı.", "QA tərəfindən təsdiqləndi.", "Müştəri tərəfindən də bu bildirilib.",
      "Bunu növbəti sprintə keçirməyi təklif edirəm.", "Loglarda səbəbi tapdım — konfiqurasiya xətası idi.",
    ];

    const statusFlow = ["TODO", "IN_PROGRESS", "IN_REVIEW", "DONE"];
    const pool = titles[def.key]!;

    for (let i = 0; i < pool.length; i++) {
      counter++;
      const title = pool[i]!;
      const isBug = /xəta|xətalı|açılmır|göndərilmir|Crash|örtür|yanlış|kəsilir|sızması|kəsilmir|Alert/i.test(title);
      const type = isBug ? "BUG" : def.type === "KANBAN" ? "TASK" : rand() < 0.55 ? "STORY" : "TASK";
      const assignee = rand() < 0.08 ? null : pick(team.filter((u) => u.role !== "ADMIN" || rand() < 0.3));
      const reporter = pick(team);

      // Sprint və status təyini
      let sprint: S | undefined;
      let status = "TODO";
      let created: Date;
      let resolved: Date | null = null;

      if (def.type === "SCRUM") {
        const r = rand();
        const completed = sprints.filter((s) => s.state === "COMPLETED");
        const active = sprints.find((s) => s.state === "ACTIVE");
        const planned = sprints.find((s) => s.state === "PLANNED");
        if (r < 0.45 && completed.length) {
          sprint = pick(completed);
          status = rand() < 0.88 ? "DONE" : "TODO"; // bəzi işlər bitməyib → backlog-a qayıdıb
          if (status !== "DONE") sprint = active;
        } else if (r < 0.8 && active) {
          sprint = active;
          status = pick(["TODO", "TODO", "IN_PROGRESS", "IN_PROGRESS", "IN_REVIEW", "DONE", "DONE"]);
        } else if (r < 0.88 && planned) {
          sprint = planned;
        }
        created = clampPast(sprint ? addDays(sprint.start, -between(1, 6)) : daysAgo(between(3, 40)));
        if (status === "DONE" && sprint) {
          const end = sprint.state === "ACTIVE" ? now : sprint.end;
          resolved = clampPast(new Date(sprint.start.getTime() + rand() * (end.getTime() - sprint.start.getTime())));
          resolved.setHours(between(10, 18));
          resolved = clampPast(resolved);
        }
      } else {
        status = pick(["TODO", "TODO", "IN_PROGRESS", "IN_REVIEW", "DONE", "DONE", "DONE"]);
        created = daysAgo(between(2, 55));
        if (status === "DONE") resolved = clampPast(addDays(created, between(1, 8)));
      }

      const points = def.type === "SCRUM" && type !== "BUG" ? pick([1, 2, 3, 3, 5, 5, 8, 13]) : type === "BUG" && def.type === "SCRUM" ? pick([1, 2, 3]) : null;
      const epic = epics.length && rand() < 0.75 ? pick(epics) : null;
      const due = rand() < 0.55 ? addDays(created, between(5, 25)) : null;
      const priority = isBug ? pick(["HIGHEST", "HIGH", "HIGH", "MEDIUM"]) : pick(["HIGH", "MEDIUM", "MEDIUM", "MEDIUM", "LOW", "LOWEST"]);
      const labels = pick(["", "", "frontend", "backend", "dizayn", "texniki-borc", "müştəri", "frontend,müştəri", "backend,texniki-borc"]);

      const issue = await db.issue.create({
        data: {
          projectId: project.id, number: counter, key: `${def.key}-${counter}`, type, title, status, priority,
          description: isBug
            ? `**Addımlar:**\n1. Səhifəni açın\n2. Əməliyyatı icra edin\n\n**Gözlənilən:** düzgün işləməli\n**Faktiki:** ${title.toLowerCase()}`
            : `${title} — tələblər və qəbul kriteriyaları:\n\n- Funksionallıq dizayna uyğun olmalıdır\n- Unit testlər yazılmalıdır\n- Mobil görünüş yoxlanılmalıdır`,
          assigneeId: assignee?.id ?? null, reporterId: reporter.id, parentId: epic?.id ?? null, sprintId: sprint?.id ?? null,
          storyPoints: points, estimateMinutes: rand() < 0.6 ? pick([60, 120, 240, 480, 960]) : null,
          dueDate: due, labels, rank: (rank += 1000), createdAt: created, resolvedAt: resolved,
          updatedAt: resolved ?? clampPast(addDays(created, between(0, 5))),
        },
      });

      await db.activity.create({ data: { issueId: issue.id, actorId: reporter.id, action: "CREATED", createdAt: created } });
      await db.watcher.create({ data: { issueId: issue.id, userId: reporter.id } });
      if (assignee && assignee.id !== reporter.id) await db.watcher.create({ data: { issueId: issue.id, userId: assignee.id } });

      // Status keçidləri tarixçəsi
      const target = statusFlow.indexOf(status);
      const actor = assignee ?? reporter;
      const endT = (resolved ?? now).getTime();
      const startT = Math.min(created.getTime() + between(2, 30) * 3_600_000, endT - 3_600_000);
      for (let s = 1; s <= target; s++) {
        const at = clampPast(new Date(startT + ((endT - startT) * (s - 1)) / Math.max(target, 1)));
        await db.activity.create({
          data: { issueId: issue.id, actorId: actor.id, action: "UPDATED", field: "status", fromValue: statusFlow[s - 1], toValue: statusFlow[s], createdAt: s === target && resolved ? resolved : at },
        });
      }

      // İş vaxtı qeydləri
      if (assignee && target >= 1) {
        const n = between(1, target + 2);
        for (let w = 0; w < n; w++) {
          const at = clampPast(new Date(startT + rand() * Math.max(endT - startT, 3_600_000)));
          at.setHours(between(9, 17), pick([0, 15, 30, 45]));
          await db.workLog.create({
            data: {
              issueId: issue.id, userId: assignee.id, minutes: pick([30, 45, 60, 90, 120, 180, 240]), startedAt: clampPast(at), createdAt: clampPast(at),
              note: rand() < 0.4 ? pick(["Kod yazıldı", "Testlər", "Code review düzəlişləri", "Araşdırma", "Debug"]) : null,
            },
          });
        }
      }

      // Şərhlər
      const cCount = between(0, 3);
      for (let c = 0; c < cCount; c++) {
        const author = c === 0 && assignee ? assignee : pick(team);
        const at = clampPast(new Date(created.getTime() + rand() * Math.max(endT - created.getTime(), 3_600_000)));
        await db.comment.create({ data: { issueId: issue.id, authorId: author.id, body: pick(comments), createdAt: at, updatedAt: at } });
        await db.activity.create({ data: { issueId: issue.id, actorId: author.id, action: "COMMENTED", createdAt: at } });
      }

      // Bəzi story-lərə alt tapşırıqlar
      if (type === "STORY" && rand() < 0.3) {
        for (const sub of ["Frontend hissəsi", "Backend endpoint", "Testlər"].slice(0, between(1, 3))) {
          counter++;
          const subDone = status === "DONE" || (status !== "TODO" && rand() < 0.5);
          await db.issue.create({
            data: {
              projectId: project.id, number: counter, key: `${def.key}-${counter}`, type: "SUBTASK", title: `${sub}: ${title.toLowerCase()}`,
              status: subDone ? "DONE" : "TODO", priority: "MEDIUM", assigneeId: assignee?.id ?? null, reporterId: reporter.id,
              parentId: issue.id, sprintId: sprint?.id ?? null, rank: (rank += 1000), createdAt: created,
              resolvedAt: subDone ? (resolved ?? clampPast(addDays(created, 1))) : null,
            },
          });
        }
      }
    }

    await db.project.update({ where: { id: project.id }, data: { issueCounter: counter } });

    // Sprint statistikası (velocity üçün)
    for (const s of sprints.filter((x) => x.state !== "PLANNED")) {
      const issues = await db.issue.findMany({ where: { sprintId: s.id, type: { notIn: ["EPIC", "SUBTASK"] } }, select: { storyPoints: true, status: true } });
      const done = issues.filter((i) => i.status === "DONE").reduce((a, i) => a + (i.storyPoints ?? 0), 0);
      const all = issues.reduce((a, i) => a + (i.storyPoints ?? 0), 0);
      await db.sprint.update({
        where: { id: s.id },
        data: { committedPoints: s.state === "COMPLETED" ? all + between(0, 8) : all, completedPoints: s.state === "COMPLETED" ? done : null },
      });
    }
  }

  // Bir neçə əlaqə və bildiriş
  const some = await db.issue.findMany({ where: { project: { key: "WEB" }, type: { in: ["STORY", "TASK", "BUG"] } }, take: 6, orderBy: { number: "asc" } });
  if (some.length >= 4) {
    await db.issueLink.create({ data: { type: "BLOCKS", fromId: some[0]!.id, toId: some[1]!.id } });
    await db.issueLink.create({ data: { type: "RELATES", fromId: some[2]!.id, toId: some[3]!.id } });
  }
  const recent = await db.issue.findMany({ where: { assigneeId: elvin.id }, take: 3, orderBy: { updatedAt: "desc" } });
  for (const [i, iss] of recent.entries()) {
    await db.notification.create({
      data: {
        userId: elvin.id, actorId: byName(["Aysel", "Murad", "Tural"][i]!).id, issueId: iss.id,
        type: i === 1 ? "COMMENTED" : "ASSIGNED", message: JSON.stringify({ k: i === 1 ? "commented" : "assigned", p: { key: iss.key } }),
        createdAt: daysAgo(i * 0.3),
      },
    });
  }

  const counts = { users: await db.user.count(), projects: await db.project.count(), issues: await db.issue.count(), worklogs: await db.workLog.count() };
  console.log("✔ Demo məlumat yaradıldı:", counts);
  console.log("  Admin girişi: admin@solo.az / parol123  (digərləri: aysel@solo.az, murad@solo.az ... eyni şifrə)");
  void [nigar, tural, leyla, murad];
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
