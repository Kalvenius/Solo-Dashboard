"use client";

import { createContext, useCallback, useContext, useMemo, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { LOCALE_COOKIE, type Locale } from "./config";
import { formatMessage } from "./format";
import { makeFormatters } from "./fmt";
import type { Dict, Namespace, Translator } from "./types";

const I18nContext = createContext<{ locale: Locale; dict: Dict } | null>(null);

export function I18nProvider({ locale, dict, children }: { locale: Locale; dict: Dict; children: ReactNode }) {
  const value = useMemo(() => ({ locale, dict }), [locale, dict]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("I18nProvider tapılmadı");
  return ctx;
}

export function useLocale(): Locale {
  return useI18n().locale;
}

/** Client komponentlərdə: const t = useT("board"); t("quickCreate"); t("daysLeft", { n: 3 }) */
export function useT<NS extends Namespace>(ns: NS): Translator<NS> {
  const { locale, dict } = useI18n();
  return useMemo<Translator<NS>>(() => {
    const d = dict[ns] ?? {};
    return (key, params) => formatMessage(locale, d[key] ?? key, params);
  }, [locale, dict, ns]);
}

/** Client-də tarix/rəqəm formatları: const f = useFormat(); f.relative(date) */
export function useFormat() {
  const locale = useLocale();
  return useMemo(() => makeFormatters(locale), [locale]);
}

/** Dili dəyişir: cookie yazır və server komponentlərini yenidən render edir */
export function useSetLocale() {
  const router = useRouter();
  return useCallback(
    (locale: Locale) => {
      document.cookie = `${LOCALE_COOKIE}=${locale}; path=/; max-age=31536000; samesite=lax`;
      router.refresh();
    },
    [router],
  );
}
