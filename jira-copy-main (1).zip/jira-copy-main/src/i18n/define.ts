/**
 * Namespace mesajlarını təyin edir. az — əsas dil (açarlar buradan götürülür);
 * en və ru eyni açarlara malik olmalıdır — çatışmayan və ya artıq açar TypeScript xətası verir.
 */
export function defineMessages<const T extends Record<string, string>>(m: {
  az: T;
  en: { [K in keyof T]: string };
  ru: { [K in keyof T]: string };
}) {
  return m;
}
