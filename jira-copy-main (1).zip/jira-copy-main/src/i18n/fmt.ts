// Dilə görə tarix, vaxt və rəqəm formatları. Server və client eyni nəticə versin deyə Intl istifadə olunmur.
import { format, formatDistanceToNowStrict, isValid } from "date-fns";
import { az, enUS, ru } from "date-fns/locale";
import type { Locale } from "./config";

const DF = { az, en: enUS, ru };

type DateIn = Date | string | number | null | undefined;
const toDate = (d: DateIn) => (d == null ? null : d instanceof Date ? d : new Date(d));

const UNITS: Record<Locale, { h: string; m: string; justNow: string }> = {
  az: { h: "s", m: "dəq", justNow: "indicə" },
  en: { h: "h", m: "m", justNow: "just now" },
  ru: { h: "ч", m: "м", justNow: "только что" },
};

const SEP: Record<Locale, { dec: string; thou: string }> = {
  az: { dec: ",", thou: "." },
  en: { dec: ".", thou: "," },
  ru: { dec: ",", thou: " " },
};

export function makeFormatters(locale: Locale) {
  const opts = { locale: DF[locale] };
  const u = UNITS[locale];
  const fmt = (d: DateIn, pattern: string) => {
    const date = toDate(d);
    return date && isValid(date) ? format(date, pattern, opts) : "—";
  };
  return {
    locale,
    /** 3 noy 2026 / Nov 3, 2026 / 3 нояб. 2026 */
    date: (d: DateIn) => fmt(d, locale === "en" ? "MMM d, yyyy" : "d MMM yyyy"),
    /** 3 noy / Nov 3 */
    dateShort: (d: DateIn) => fmt(d, locale === "en" ? "MMM d" : "d MMM"),
    /** 3 noy 2026, 14:05 */
    dateTime: (d: DateIn) => fmt(d, locale === "en" ? "MMM d, yyyy, HH:mm" : "d MMM yyyy, HH:mm"),
    /** İxtiyari date-fns şablonu (ay/gün adları dilə uyğun) */
    pattern: (d: DateIn, p: string) => fmt(d, p),
    /** "5 dəqiqə əvvəl" / "5 minutes ago" / "5 минут назад". Client-də suppressHydrationWarning ilə işlədin. */
    relative: (d: DateIn) => {
      const date = toDate(d);
      if (!date || !isValid(date)) return "—";
      if (Math.abs(Date.now() - date.getTime()) < 45_000) return u.justNow;
      return formatDistanceToNowStrict(date, { ...opts, addSuffix: true });
    },
    /** 150 -> "2s 30dəq" / "2h 30m" / "2ч 30м" */
    minutes: (min: number | null | undefined) => {
      if (!min) return `0${u.h}`;
      const h = Math.floor(min / 60);
      const m = min % 60;
      if (h && m) return `${h}${u.h} ${m}${u.m}`;
      return h ? `${h}${u.h}` : `${m}${u.m}`;
    },
    /** 1234.5 -> "1.234,5" (az) / "1,234.5" (en) / "1 234,5" (ru) */
    num: (n: number | null | undefined, digits = 0) => {
      if (n == null || !Number.isFinite(n)) return "—";
      const [int, frac] = Math.abs(n).toFixed(digits).split(".");
      const grouped = int!.replace(/\B(?=(\d{3})+(?!\d))/g, SEP[locale].thou);
      return `${n < 0 ? "−" : ""}${grouped}${frac && Number(frac) !== 0 ? SEP[locale].dec + frac : ""}`;
    },
  };
}

export type Formatters = ReturnType<typeof makeFormatters>;
