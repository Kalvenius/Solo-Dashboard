import { defineMessages } from "../define";

// Bildiriş zəngi. "notif.<k>" açarları bazadakı notifMessage(k, p) yükünü göstərir: {actor}, {key}, {status}
export default defineMessages({
  az: {
    title: "Bildirişlər",
    unreadAria: "Bildirişlər ({n} oxunmamış)",
    markAllRead: "Hamısını oxunmuş et",
    empty: "Yeni bildiriş yoxdur",
    unread: "Oxunmamış",
    someone: "Kimsə",
    "notif.assigned": "{actor} sizə {key} tapşırığını təyin etdi",
    "notif.status": "{actor} {key} statusunu “{status}” etdi",
    "notif.commented": "{actor} {key} tapşırığına şərh yazdı",
    "notif.mentioned": "{actor} sizi {key} tapşırığında qeyd etdi",
  },
  en: {
    title: "Notifications",
    unreadAria: "Notifications ({n} unread)",
    markAllRead: "Mark all as read",
    empty: "No new notifications",
    unread: "Unread",
    someone: "Someone",
    "notif.assigned": "{actor} assigned {key} to you",
    "notif.status": "{actor} moved {key} to {status}",
    "notif.commented": "{actor} commented on {key}",
    "notif.mentioned": "{actor} mentioned you in {key}",
  },
  ru: {
    title: "Уведомления",
    unreadAria: "Уведомления (непрочитанных: {n})",
    markAllRead: "Отметить все как прочитанные",
    empty: "Новых уведомлений нет",
    unread: "Непрочитано",
    someone: "Кто-то",
    "notif.assigned": "{actor} назначил(а) вам задачу {key}",
    "notif.status": "{actor} перевёл(а) {key} в статус «{status}»",
    "notif.commented": "{actor} прокомментировал(а) {key}",
    "notif.mentioned": "{actor} упомянул(а) вас в {key}",
  },
});
