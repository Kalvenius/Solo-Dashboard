import { defineMessages } from "../define";

// Yuxarı paneldəki qlobal axtarış
export default defineMessages({
  az: {
    placeholder: "Axtar",
    nothingFound: "“{q}” üzrə heç nə tapılmadı",
    searchAll: "Bütün tapşırıqlarda axtar: “{q}”",
  },
  en: {
    placeholder: "Search",
    nothingFound: "Nothing found for “{q}”",
    searchAll: "Search all issues for “{q}”",
  },
  ru: {
    placeholder: "Поиск",
    nothingFound: "По запросу «{q}» ничего не найдено",
    searchAll: "Искать во всех задачах: «{q}»",
  },
});
