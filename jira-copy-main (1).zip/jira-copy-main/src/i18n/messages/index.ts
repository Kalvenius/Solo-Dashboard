import "server-only";
// Bütün tərcümələr. Client komponentləri bunu birbaşa import etməməlidir — useT() istifadə edin.
import admin from "./admin";
import auth from "./auth";
import backlog from "./backlog";
import board from "./board";
import charts from "./charts";
import common from "./common";
import createIssue from "./createIssue";
import enums from "./enums";
import errors from "./errors";
import issue from "./issue";
import issueTable from "./issueTable";
import nav from "./nav";
import notifications from "./notifications";
import people from "./people";
import profile from "./profile";
import projects from "./projects";
import reports from "./reports";
import search from "./search";
import timeline from "./timeline";
import yourWork from "./yourWork";

export const messages = {
  admin, auth, backlog, board, charts, common, createIssue, enums, errors, issue,
  issueTable, nav, notifications, people, profile, projects, reports, search, timeline, yourWork,
};
