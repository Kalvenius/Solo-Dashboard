import "server-only";
import { cache } from "react";
import { cookies, headers } from "next/headers";
import { LOCALE_COOKIE, isLocale, matchLocale, type Locale } from "./config";
import { formatMessage, type Params } from "./format";
import { makeFormatters } from "./fmt";
import { messages } from "./messages";
import type { Dict, MessageKey, Namespace, Translator } from "./types";

/** Cari dil: cookie → brauzerin dili (Accept-Language) → az */
export const getLocale = cache(async (): Promise<Locale> => {
  const c = (await cookies()).get(LOCALE_COOKIE)?.value;
  if (isLocale(c)) return c;
  return matchLocale((await headers()).get("accept-language"));
});

export function makeT<NS extends Namespace>(locale: Locale, ns: NS): Translator<NS> {
  const dict = messages[ns][locale] as Record<string, string>;
  const fallback = messages[ns].az as Record<string, string>;
  return (key, params) => formatMessage(locale, dict[key] ?? fallback[key] ?? key, params);
}

/** Server komponentlərdə və server action-larda: const t = await getT("board") */
export async function getT<NS extends Namespace>(ns: NS): Promise<Translator<NS>> {
  return makeT(await getLocale(), ns);
}

/** Server tərəfdə tarix/rəqəm formatları: const f = await getFormat(); f.date(issue.createdAt) */
export async function getFormat() {
  return makeFormatters(await getLocale());
}

export function dictFor(locale: Locale): Dict {
  return Object.fromEntries(Object.entries(messages).map(([ns, m]) => [ns, (m as Record<Locale, Record<string, string>>)[locale]])) as Dict;
}

/**
 * Xəta mesajını tərcümə edir. Qəbul edir: "titleRequired" (errors namespace) və ya "backlog.errSprintEmpty".
 * Açar tapılmazsa, mesajı olduğu kimi qaytarır.
 */
export async function translateError(message: string, params?: Params): Promise<string> {
  const locale = await getLocale();
  const errs = messages.errors[locale] as Record<string, string>;
  if (errs[message]) return formatMessage(locale, errs[message], params);
  const dot = message.indexOf(".");
  if (dot > 0) {
    const ns = message.slice(0, dot) as Namespace;
    const key = message.slice(dot + 1);
    const dict = (messages[ns] as Record<Locale, Record<string, string>> | undefined)?.[locale];
    if (dict?.[key]) return formatMessage(locale, dict[key]!, params);
  }
  return message;
}

export type { MessageKey, Namespace };
