// Kiçik ICU-uyğun mesaj formatlayıcısı:
//   "Salam, {name}"                                       -> parametr
//   "{n, plural, one {# day left} other {# days left}}"   -> cəm formaları (# = rəqəm)
//   "{n, plural, =0 {none} one {# item} other {# items}}" -> dəqiq dəyər
// Rus dili: one (1, 21), few (2-4, 22-24), many (5-20, 25...). Azərbaycan dili: one/other.
import type { Locale } from "./config";

export type Params = Record<string, string | number | null | undefined>;

export function pluralCategory(locale: Locale, n: number): "one" | "few" | "many" | "other" {
  if (!Number.isInteger(n)) return "other";
  const i = Math.abs(n);
  if (locale === "ru") {
    const m10 = i % 10;
    const m100 = i % 100;
    if (m10 === 1 && m100 !== 11) return "one";
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return "few";
    return "many";
  }
  return i === 1 ? "one" : "other";
}

function matchBrace(s: string, start: number) {
  let depth = 0;
  for (let j = start; j < s.length; j++) {
    if (s[j] === "{") depth++;
    else if (s[j] === "}") {
      depth--;
      if (depth === 0) return j;
    }
  }
  return -1;
}

function renderArg(locale: Locale, body: string, params: Params): string {
  const m = body.match(/^\s*(\w+)\s*(?:,\s*plural\s*,([\s\S]*))?$/);
  if (!m) return `{${body}}`;
  const name = m[1]!;
  const pluralBody = m[2];
  const value = params[name];
  if (pluralBody === undefined) return value == null ? `{${name}}` : String(value);

  const n = Number(value ?? 0);
  const opts: Record<string, string> = {};
  let k = 0;
  while (k < pluralBody.length) {
    const sel = pluralBody.slice(k).match(/^\s*(=\d+|zero|one|two|few|many|other)\s*\{/);
    if (!sel) break;
    const open = k + sel[0].length - 1;
    const close = matchBrace(pluralBody, open);
    if (close === -1) break;
    opts[sel[1]!] = pluralBody.slice(open + 1, close);
    k = close + 1;
  }
  const cat = pluralCategory(locale, n);
  const chosen = opts[`=${n}`] ?? opts[cat] ?? (cat === "many" ? opts.other : undefined) ?? opts.other ?? "";
  return formatMessage(locale, chosen.replace(/#/g, String(value ?? n)), params);
}

export function formatMessage(locale: Locale, msg: string, params: Params = {}): string {
  if (!msg.includes("{")) return msg;
  let out = "";
  let i = 0;
  while (i < msg.length) {
    if (msg[i] === "{") {
      const end = matchBrace(msg, i);
      if (end === -1) return out + msg.slice(i);
      out += renderArg(locale, msg.slice(i + 1, end), params);
      i = end + 1;
    } else {
      out += msg[i];
      i++;
    }
  }
  return out;
}
