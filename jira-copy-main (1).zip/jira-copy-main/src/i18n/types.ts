import type { messages } from "./messages";
import type { Params } from "./format";

export type Messages = typeof messages;
export type Namespace = keyof Messages;
export type MessageKey<NS extends Namespace> = keyof Messages[NS]["az"] & string;
/** Bir dil üçün bütün namespace-lər (client provider-ə ötürülür) */
export type Dict = { [NS in Namespace]: Record<string, string> };
export type Translator<NS extends Namespace> = (key: MessageKey<NS>, params?: Params) => string;
