import "server-only";
import { cache } from "react";
import { notFound } from "next/navigation";
import { requireUser } from "./auth";
import { getProjectForUser } from "./access";

/** Layihə səhifələri üçün: istifadəçi + layihə (giriş yoxdursa 404). Layout və page arasında keşlənir. */
export const loadProjectPage = cache(async (key: string) => {
  const user = await requireUser();
  const project = await getProjectForUser(decodeURIComponent(key), user);
  if (!project) notFound();
  const myRole = user.role === "ADMIN" ? "ADMIN" : (project.members.find((m) => m.userId === user.id)?.role ?? "MEMBER");
  return { user, project, canManage: myRole === "ADMIN" };
});
