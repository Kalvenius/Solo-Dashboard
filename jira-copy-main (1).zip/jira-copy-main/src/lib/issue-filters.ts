import "server-only";
import type { Prisma } from "@prisma/client";
import { startOfDay, subDays } from "date-fns";
import { db, textContains } from "./db";
import { issueScope } from "./access";
import type { CurrentUser } from "./auth";
import { PRIORITY_META, STATUSES, type Priority } from "./constants";
import { issueCardSelect } from "./issue-select";

export type SearchParams = Record<string, string | string[] | undefined>;

export const SORT_KEYS = ["key", "title", "status", "priority", "assignee", "due", "created", "updated"] as const;
export type SortKey = (typeof SORT_KEYS)[number];

export type IssueFilters = {
  q: string;
  status: string[];
  type: string[];
  assignee: string[]; // "me" | "unassigned" | userId
  priority: string[];
  sprint: string[]; // sprintId | "backlog" | "active"
  label: string[];
  project: string[]; // layihə açarları (yalnız qlobal səhifədə)
  reporter: string | null; // "me" | userId
  created: number | null; // son N gün
  resolved: number | null; // son N gün
  overdue: boolean;
  watching: boolean;
  sort: SortKey;
  dir: "asc" | "desc";
  page: number;
};

/** Filtr açarları — "Təmizlə" bunları silir */
export const FILTER_PARAM_KEYS = ["q", "status", "type", "assignee", "priority", "sprint", "label", "project", "reporter", "created", "resolved", "overdue", "watching", "page"];

const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
const list = (v: string | string[] | undefined) =>
  (first(v) ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
const posInt = (v: string | string[] | undefined) => {
  const n = parseInt(first(v) ?? "", 10);
  return Number.isFinite(n) && n > 0 ? n : null;
};

export function parseIssueFilters(sp: SearchParams): IssueFilters {
  const sort = first(sp.sort);
  const dir = first(sp.dir);
  return {
    q: (first(sp.q) ?? "").trim(),
    status: list(sp.status),
    type: list(sp.type),
    assignee: list(sp.assignee),
    priority: list(sp.priority),
    sprint: list(sp.sprint),
    label: list(sp.label),
    project: list(sp.project).map((k) => k.toUpperCase()),
    reporter: first(sp.reporter) || null,
    created: posInt(sp.created),
    resolved: posInt(sp.resolved),
    overdue: first(sp.overdue) === "1",
    watching: first(sp.watching) === "1",
    sort: (SORT_KEYS as readonly string[]).includes(sort ?? "") ? (sort as SortKey) : "updated",
    dir: dir === "asc" ? "asc" : "desc",
    page: posInt(sp.page) ?? 1,
  };
}

export async function buildIssueWhere(f: IssueFilters, user: CurrentUser, projectId?: string): Promise<Prisma.IssueWhereInput> {
  const and: Prisma.IssueWhereInput[] = [];

  if (projectId) and.push({ projectId });
  else {
    and.push(await issueScope(user));
    if (f.project.length) and.push({ project: { key: { in: f.project } } });
  }

  if (f.q) {
    const or: Prisma.IssueWhereInput[] = [{ title: textContains(f.q) }, { description: textContains(f.q) }, { key: f.q.toUpperCase() }];
    if (/^[a-z][a-z0-9]*-\d*$/i.test(f.q)) or.push({ key: { startsWith: f.q.toUpperCase() } });
    and.push({ OR: or });
  }
  if (f.status.length) and.push({ status: { in: f.status } });
  if (f.type.length) and.push({ type: { in: f.type } });
  if (f.priority.length) and.push({ priority: { in: f.priority } });

  if (f.assignee.length) {
    const ids = f.assignee.filter((a) => a !== "unassigned").map((a) => (a === "me" ? user.id : a));
    const or: Prisma.IssueWhereInput[] = [];
    if (ids.length) or.push({ assigneeId: { in: ids } });
    if (f.assignee.includes("unassigned")) or.push({ assigneeId: null });
    and.push({ OR: or });
  }

  if (f.sprint.length) {
    const ids = f.sprint.filter((s) => s !== "backlog" && s !== "active");
    const or: Prisma.IssueWhereInput[] = [];
    if (ids.length) or.push({ sprintId: { in: ids } });
    if (f.sprint.includes("backlog")) or.push({ sprintId: null, type: { not: "EPIC" } });
    if (f.sprint.includes("active")) or.push({ sprint: { state: "ACTIVE" } });
    and.push({ OR: or });
  }

  if (f.label.length) {
    // etiketlər "a,b,c" kimi saxlanılır — tam uyğunluq üçün 4 variant
    and.push({
      OR: f.label.flatMap((l) => [{ labels: l }, { labels: { startsWith: `${l},` } }, { labels: { endsWith: `,${l}` } }, { labels: { contains: `,${l},` } }]),
    });
  }

  if (f.reporter) and.push({ reporterId: f.reporter === "me" ? user.id : f.reporter });
  if (f.created) and.push({ createdAt: { gte: startOfDay(subDays(new Date(), f.created - 1)) } });
  if (f.resolved) and.push({ resolvedAt: { gte: startOfDay(subDays(new Date(), f.resolved - 1)) }, status: "DONE" });
  if (f.overdue) and.push({ dueDate: { lt: startOfDay(new Date()) }, status: { not: "DONE" } });
  if (f.watching) and.push({ watchers: { some: { userId: user.id } } });

  return { AND: and };
}

export const issueListSelect = {
  ...issueCardSelect,
  sprint: { select: { id: true, name: true, state: true } },
  project: { select: { key: true, name: true, color: true } },
  reporter: { select: { id: true, name: true } },
} satisfies Prisma.IssueSelect;

export type IssueListRow = Prisma.IssueGetPayload<{ select: typeof issueListSelect }>;

const STATUS_ORDER: Record<string, number> = Object.fromEntries(STATUSES.map((s, i) => [s, i]));

type Lite = {
  id: string;
  number: number;
  title: string;
  status: string;
  priority: string;
  dueDate: Date | null;
  createdAt: Date;
  updatedAt: Date;
  assignee: { name: string } | null;
  project: { key: string };
};

function compare(a: Lite, b: Lite, sort: SortKey): number | null {
  switch (sort) {
    case "key":
      return a.project.key.localeCompare(b.project.key) || a.number - b.number;
    case "title":
      return a.title.localeCompare(b.title, "az");
    case "status":
      return (STATUS_ORDER[a.status] ?? 0) - (STATUS_ORDER[b.status] ?? 0);
    case "priority":
      return (PRIORITY_META[a.priority as Priority]?.weight ?? 0) - (PRIORITY_META[b.priority as Priority]?.weight ?? 0);
    case "assignee":
      if (!a.assignee || !b.assignee) return null;
      return a.assignee.name.localeCompare(b.assignee.name, "az");
    case "due":
      if (!a.dueDate || !b.dueDate) return null;
      return a.dueDate.getTime() - b.dueDate.getTime();
    case "created":
      return a.createdAt.getTime() - b.createdAt.getTime();
    case "updated":
      return a.updatedAt.getTime() - b.updatedAt.getTime();
  }
}

/**
 * Tapşırıqları filtr + sıralama + səhifələmə ilə qaytarır.
 * Status/prioritet kimi sahələr məna sırası ilə sıralanmalı olduğu üçün sıralama JS-də edilir
 * (komanda miqyasında — bir neçə min tapşırıq — bu kifayət qədər sürətlidir).
 */
export async function queryIssues(where: Prisma.IssueWhereInput, f: IssueFilters, opts: { pageSize?: number; all?: boolean } = {}) {
  const lite: Lite[] = await db.issue.findMany({
    where,
    select: {
      id: true,
      number: true,
      title: true,
      status: true,
      priority: true,
      dueDate: true,
      createdAt: true,
      updatedAt: true,
      assignee: { select: { name: true } },
      project: { select: { key: true } },
    },
  });

  const sign = f.dir === "asc" ? 1 : -1;
  lite.sort((a, b) => {
    const c = compare(a, b, f.sort);
    if (c === null) {
      // boş dəyərlər həmişə sonda
      const aEmpty = f.sort === "due" ? !a.dueDate : !a.assignee;
      const bEmpty = f.sort === "due" ? !b.dueDate : !b.assignee;
      if (aEmpty !== bEmpty) return aEmpty ? 1 : -1;
    } else if (c !== 0) return c * sign;
    return b.updatedAt.getTime() - a.updatedAt.getTime() || b.number - a.number;
  });

  const total = lite.length;
  const pageSize = opts.all ? Math.max(total, 1) : (opts.pageSize ?? 50);
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  const page = Math.min(Math.max(1, f.page), pageCount);
  const ids = lite.slice((page - 1) * pageSize, page * pageSize).map((r) => r.id);
  const rows = ids.length ? await db.issue.findMany({ where: { id: { in: ids } }, select: issueListSelect }) : [];
  const byId = new Map(rows.map((r) => [r.id, r]));
  return { rows: ids.map((id) => byId.get(id)).filter((r): r is IssueListRow => !!r), total, page, pageSize, pageCount };
}

/** Görünən tapşırıqlardakı bütün etiketlər (filtr seçimi üçün) */
export async function distinctLabels(where: Prisma.IssueWhereInput) {
  const rows = await db.issue.findMany({ where: { ...where, labels: { not: "" } }, select: { labels: true } });
  const set = new Set<string>();
  for (const r of rows) for (const l of r.labels.split(",")) if (l.trim()) set.add(l.trim());
  return Array.from(set).sort((a, b) => a.localeCompare(b, "az"));
}
