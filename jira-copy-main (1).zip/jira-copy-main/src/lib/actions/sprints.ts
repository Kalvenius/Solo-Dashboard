"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { assertProjectAccess } from "@/lib/access";
import { applyIssueUpdate } from "@/lib/issue-service";
import { safe, type ActionResult } from "@/lib/action-result";
import { AppError } from "@/lib/errors";

/** "yyyy-MM-dd" → Date. Bu gündürsə cari vaxt, deyilsə günün əvvəli (və ya sonu). */
function parseDay(s: string | null | undefined, edge: "start" | "end"): Date | null {
  if (!s) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) throw new Error("backlog.errDateFormat");
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  if (edge === "end") {
    d.setHours(23, 59, 59, 0);
    return d;
  }
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return today;
  return d;
}

async function loadSprint(sprintId: string) {
  const user = await requireUser();
  const sprint = await db.sprint.findUnique({ where: { id: sprintId } });
  if (!sprint) throw new Error("sprintNotFound");
  await assertProjectAccess(sprint.projectId, user);
  return { user, sprint };
}

async function nextSprintName(projectId: string) {
  const [project, count] = await Promise.all([
    db.project.findUnique({ where: { id: projectId }, select: { key: true } }),
    db.sprint.count({ where: { projectId } }),
  ]);
  const base = `${project?.key ?? "Sprint"} Sprint`;
  let n = count + 1;
  // eyni adda sprint varsa növbəti nömrəni seç
  while (await db.sprint.findFirst({ where: { projectId, name: `${base} ${n}` }, select: { id: true } })) n++;
  return `${base} ${n}`;
}

const sumPoints = (rows: { storyPoints: number | null }[]) => rows.reduce((a, r) => a + (r.storyPoints ?? 0), 0);

export async function createSprint(projectId: string, input?: { name?: string; goal?: string }): Promise<ActionResult<{ id: string }>> {
  return safe(async () => {
    const user = await requireUser();
    await assertProjectAccess(projectId, user);
    const project = await db.project.findUnique({ where: { id: projectId }, select: { type: true } });
    if (!project) throw new Error("projectNotFound");
    if (project.type !== "SCRUM") throw new Error("backlog.errOnlyScrum");
    const sprint = await db.sprint.create({
      data: { projectId, name: input?.name?.trim() || (await nextSprintName(projectId)), goal: input?.goal?.trim() || null },
    });
    revalidatePath("/", "layout");
    return { id: sprint.id };
  });
}

export type SprintFormInput = { name: string; goal?: string | null; startDate?: string | null; endDate?: string | null };

export async function updateSprint(sprintId: string, input: SprintFormInput): Promise<ActionResult> {
  return safe(async () => {
    const { sprint } = await loadSprint(sprintId);
    const name = input.name.trim();
    if (!name) throw new Error("backlog.errNameEmpty");
    const startDate = input.startDate !== undefined ? parseDay(input.startDate, "start") : sprint.startDate;
    const endDate = input.endDate !== undefined ? parseDay(input.endDate, "end") : sprint.endDate;
    if (startDate && endDate && endDate < startDate) throw new Error("backlog.errEndBeforeStart");
    if (sprint.state === "ACTIVE" && (!startDate || !endDate)) throw new Error("backlog.errActiveNeedsDates");
    await db.sprint.update({ where: { id: sprintId }, data: { name, goal: input.goal?.trim() || null, startDate, endDate } });
    revalidatePath("/", "layout");
    return undefined;
  });
}

export async function startSprint(sprintId: string, input: SprintFormInput): Promise<ActionResult> {
  return safe(async () => {
    const { sprint } = await loadSprint(sprintId);
    if (sprint.state !== "PLANNED") throw new Error("backlog.errAlreadyStarted");
    const active = await db.sprint.findFirst({ where: { projectId: sprint.projectId, state: "ACTIVE" }, select: { name: true } });
    if (active) throw new AppError("backlog.errOtherActive", { name: active.name });

    const name = input.name.trim();
    if (!name) throw new Error("backlog.errNameEmpty");
    const startDate = parseDay(input.startDate, "start") ?? new Date();
    const endDate = parseDay(input.endDate, "end");
    if (!endDate) throw new Error("backlog.errPickEndDate");
    if (endDate < startDate) throw new Error("backlog.errEndBeforeStart");

    const issues = await db.issue.findMany({
      where: { sprintId, type: { notIn: ["EPIC", "SUBTASK"] } },
      select: { storyPoints: true },
    });
    if (issues.length === 0) throw new Error("backlog.errEmptySprint");

    await db.sprint.update({
      where: { id: sprintId },
      data: { name, goal: input.goal?.trim() || null, state: "ACTIVE", startDate, endDate, committedPoints: sumPoints(issues) },
    });
    revalidatePath("/", "layout");
    return undefined;
  });
}

/**
 * Sprinti tamamlayır. Bitməmiş tapşırıqlar target-ə köçür:
 * "backlog" — backlog-a, "new" — yeni sprintə, digər halda — həmin planlaşdırılmış sprintə.
 */
export async function completeSprint(sprintId: string, target: string): Promise<ActionResult<{ moved: number }>> {
  return safe(async () => {
    const { user, sprint } = await loadSprint(sprintId);
    if (sprint.state !== "ACTIVE") throw new Error("backlog.errOnlyActiveComplete");

    let targetSprintId: string | null = null;
    if (target === "new") {
      const created = await db.sprint.create({ data: { projectId: sprint.projectId, name: await nextSprintName(sprint.projectId) } });
      targetSprintId = created.id;
    } else if (target !== "backlog") {
      const t = await db.sprint.findUnique({ where: { id: target }, select: { projectId: true, state: true } });
      if (!t || t.projectId !== sprint.projectId || t.state !== "PLANNED") throw new Error("backlog.errTargetNotFound");
      targetSprintId = target;
    }

    const issues = await db.issue.findMany({
      where: { sprintId, type: { notIn: ["EPIC", "SUBTASK"] } },
      select: { id: true, status: true, storyPoints: true },
    });
    const done = issues.filter((i) => i.status === "DONE");
    const open = issues.filter((i) => i.status !== "DONE");

    await db.sprint.update({
      where: { id: sprintId },
      data: {
        state: "COMPLETED",
        completedAt: new Date(),
        completedPoints: sumPoints(done),
        committedPoints: sprint.committedPoints ?? sumPoints(issues),
      },
    });
    // alt tapşırıqlar applyIssueUpdate daxilində valideynlə birlikdə köçür
    for (const issue of open) {
      await applyIssueUpdate(user.id, issue.id, { sprintId: targetSprintId });
    }
    // valideyni sprintdə olmayan bitməmiş alt tapşırıqlar da köçsün
    await db.issue.updateMany({ where: { sprintId, type: "SUBTASK", status: { not: "DONE" } }, data: { sprintId: targetSprintId } });

    revalidatePath("/", "layout");
    return { moved: open.length };
  });
}

export async function deleteSprint(sprintId: string): Promise<ActionResult> {
  return safe(async () => {
    const { user, sprint } = await loadSprint(sprintId);
    if (sprint.state !== "PLANNED") throw new Error("backlog.errOnlyPlannedDelete");
    const issues = await db.issue.findMany({ where: { sprintId, type: { not: "SUBTASK" } }, select: { id: true } });
    for (const issue of issues) await applyIssueUpdate(user.id, issue.id, { sprintId: null });
    await db.issue.updateMany({ where: { sprintId }, data: { sprintId: null } });
    await db.sprint.delete({ where: { id: sprintId } });
    revalidatePath("/", "layout");
    return undefined;
  });
}
