"use server";

import { db, textContains } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { accessibleProjectIds } from "@/lib/access";

export type QuickSearchResult = {
  issues: { key: string; title: string; type: string; status: string; projectName: string }[];
  projects: { key: string; name: string; color: string; type: string }[];
};

/** Yuxarı paneldəki axtarış: tapşırıqlar (açar və ya başlıq) + layihələr */
export async function quickSearch(raw: string): Promise<QuickSearchResult> {
  const user = await getCurrentUser();
  const q = raw.trim().slice(0, 100);
  if (!user || !q) return { issues: [], projects: [] };

  const ids = await accessibleProjectIds(user);
  const scope = ids === null ? {} : { projectId: { in: ids } };
  const upper = q.toUpperCase();
  const select = { id: true, key: true, title: true, type: true, status: true, project: { select: { name: true } } } as const;

  const [exact, byText, projects] = await Promise.all([
    db.issue.findUnique({ where: { key: upper }, select: { ...select, projectId: true } }),
    db.issue.findMany({
      where: { ...scope, OR: [{ title: textContains(q) }, { key: { startsWith: upper } }] },
      select,
      orderBy: { updatedAt: "desc" },
      take: 8,
    }),
    db.project.findMany({
      where: { ...(ids === null ? {} : { id: { in: ids } }), OR: [{ name: textContains(q) }, { key: { startsWith: upper } }] },
      select: { key: true, name: true, color: true, type: true },
      take: 3,
    }),
  ]);

  const list = [...byText];
  if (exact && (ids === null || ids.includes(exact.projectId))) {
    const i = list.findIndex((x) => x.id === exact.id);
    if (i >= 0) list.splice(i, 1);
    list.unshift(exact);
  }

  return {
    issues: list.slice(0, 8).map((i) => ({ key: i.key, title: i.title, type: i.type, status: i.status, projectName: i.project.name })),
    projects,
  };
}
