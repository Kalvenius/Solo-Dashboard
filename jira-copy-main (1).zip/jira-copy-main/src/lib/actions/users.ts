"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashPassword, requireAdmin, requireUser, verifyPassword } from "@/lib/auth";
import { fail, safe } from "@/lib/action-result";
import { translateError } from "@/i18n/server";

const hex = /^#[0-9A-Fa-f]{6}$/;
// Validasiya mesajları tərcümə açarlarıdır (src/i18n/messages/admin.ts)
const optText = z.string().trim().max(80, "admin.errTextLong").nullish();

const userSchema = z.object({
  name: z.string().trim().min(2, "admin.errNameMin").max(80, "admin.errNameLong"),
  email: z.string().trim().toLowerCase().email("admin.errEmail"),
  title: optText,
  department: optText,
  role: z.enum(["ADMIN", "MEMBER"], { message: "admin.errRole" }),
  avatarColor: z.string().regex(hex, "admin.errColor"),
});

const password = z.string().min(6, "admin.errPasswordMin").max(100, "admin.errPasswordLong");

const createSchema = userSchema.extend({ password, projectIds: z.array(z.string()).default([]) });

export type UserInput = z.input<typeof userSchema>;
export type CreateUserInput = z.input<typeof createSchema>;

const first = (e: z.ZodError) => e.issues[0]?.message ?? "admin.errInvalid";
const failKey = async (key: string) => fail(await translateError(key));

async function otherActiveAdmins(exceptId: string) {
  return db.user.count({ where: { role: "ADMIN", active: true, id: { not: exceptId } } });
}

export async function createUser(input: CreateUserInput) {
  const parsed = createSchema.safeParse(input);
  if (!parsed.success) return failKey(first(parsed.error));
  const { projectIds, password: pw, title, department, ...rest } = parsed.data;

  return safe(async () => {
    await requireAdmin();
    if (await db.user.findUnique({ where: { email: rest.email } })) throw new Error("admin.errEmailTaken");
    const user = await db.user.create({
      data: {
        ...rest,
        title: title || null,
        department: department || null,
        passwordHash: await hashPassword(pw),
        memberships: { create: projectIds.map((projectId) => ({ projectId, role: "MEMBER" })) },
      },
      select: { id: true },
    });
    revalidatePath("/", "layout");
    return { id: user.id };
  });
}

export async function updateUser(userId: string, input: UserInput) {
  const parsed = userSchema.safeParse(input);
  if (!parsed.success) return failKey(first(parsed.error));
  const { title, department, ...rest } = parsed.data;

  return safe(async () => {
    const me = await requireAdmin();
    const target = await db.user.findUnique({ where: { id: userId }, select: { role: true, active: true } });
    if (!target) throw new Error("userNotFound");
    if (target.role === "ADMIN" && rest.role !== "ADMIN") {
      if (userId === me.id) throw new Error("admin.errOwnAdminRole");
      if (target.active && (await otherActiveAdmins(userId)) === 0) throw new Error("admin.errLastAdmin");
    }
    const dupe = await db.user.findFirst({ where: { email: rest.email, id: { not: userId } }, select: { id: true } });
    if (dupe) throw new Error("admin.errEmailTaken");
    await db.user.update({ where: { id: userId }, data: { ...rest, title: title || null, department: department || null } });
    revalidatePath("/", "layout");
  });
}

export async function setUserActive(userId: string, active: boolean) {
  return safe(async () => {
    const me = await requireAdmin();
    if (userId === me.id && !active) throw new Error("admin.errSelfDeactivate");
    const target = await db.user.findUnique({ where: { id: userId }, select: { role: true } });
    if (!target) throw new Error("userNotFound");
    if (!active && target.role === "ADMIN" && (await otherActiveAdmins(userId)) === 0) {
      throw new Error("admin.errLastAdmin");
    }
    await db.user.update({ where: { id: userId }, data: { active } });
    revalidatePath("/", "layout");
  });
}

export async function resetUserPassword(userId: string, newPassword: string) {
  const parsed = password.safeParse(newPassword);
  if (!parsed.success) return failKey(first(parsed.error));
  return safe(async () => {
    await requireAdmin();
    await db.user.update({ where: { id: userId }, data: { passwordHash: await hashPassword(parsed.data) } });
  });
}

const profileSchema = z.object({
  name: z.string().trim().min(2, "admin.errNameMin").max(80, "admin.errNameLong"),
  title: optText,
  department: optText,
  avatarColor: z.string().regex(hex, "admin.errColor"),
});

export type ProfileInput = z.input<typeof profileSchema>;

export async function updateProfile(input: ProfileInput) {
  const parsed = profileSchema.safeParse(input);
  if (!parsed.success) return failKey(first(parsed.error));
  return safe(async () => {
    const me = await requireUser();
    const { title, department, ...rest } = parsed.data;
    await db.user.update({ where: { id: me.id }, data: { ...rest, title: title || null, department: department || null } });
    revalidatePath("/", "layout");
  });
}

export async function changePassword(input: { current: string; next: string }) {
  const parsed = password.safeParse(input.next);
  if (!parsed.success) return failKey(first(parsed.error));
  return safe(async () => {
    const me = await requireUser();
    const u = await db.user.findUnique({ where: { id: me.id }, select: { passwordHash: true } });
    if (!u || !(await verifyPassword(input.current, u.passwordHash))) throw new Error("admin.errWrongCurrentPassword");
    await db.user.update({ where: { id: me.id }, data: { passwordHash: await hashPassword(parsed.data) } });
  });
}
