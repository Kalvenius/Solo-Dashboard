"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { assertProjectAccess } from "@/lib/access";
import { applyIssueUpdate, createIssueRecord, type IssuePatch } from "@/lib/issue-service";
import { safe, type ActionResult } from "@/lib/action-result";

const RANK_STEP = 1000;
const MIN_GAP = 1e-6;

/** Layihədəki bütün tapşırıqların sırasını bərabər aralıqlarla yenidən nömrələyir */
async function rebalanceRanks(projectId: string) {
  const all = await db.issue.findMany({ where: { projectId }, orderBy: [{ rank: "asc" }, { createdAt: "asc" }], select: { id: true } });
  await db.$transaction(all.map((it, i) => db.issue.update({ where: { id: it.id }, data: { rank: (i + 1) * RANK_STEP } })));
}

async function computeRank(projectId: string, beforeId?: string | null, afterId?: string | null): Promise<number> {
  const load = async () => {
    const ids = [beforeId, afterId].filter((x): x is string => !!x);
    const rows = ids.length ? await db.issue.findMany({ where: { id: { in: ids }, projectId }, select: { id: true, rank: true } }) : [];
    return {
      before: rows.find((r) => r.id === beforeId)?.rank,
      after: rows.find((r) => r.id === afterId)?.rank,
    };
  };
  let { before, after } = await load();
  if (before !== undefined && after !== undefined && Math.abs(after - before) < MIN_GAP) {
    await rebalanceRanks(projectId);
    ({ before, after } = await load());
  }
  if (before !== undefined && after !== undefined) return (before + after) / 2;
  if (before !== undefined) return before + RANK_STEP;
  if (after !== undefined) return after - RANK_STEP;
  const last = await db.issue.findFirst({ where: { projectId }, orderBy: { rank: "desc" }, select: { rank: true } });
  return (last?.rank ?? 0) + RANK_STEP;
}

export type MoveIssueInput = {
  status?: string;
  /** null = backlog-a köçür; undefined = dəyişmə */
  sprintId?: string | null;
  /** lövhədə icraçı üzrə qruplaşdırmada başqa sətrə sürüşdürəndə */
  assigneeId?: string | null;
  /** lövhədə epic üzrə qruplaşdırmada başqa sətrə sürüşdürəndə */
  parentId?: string | null;
  /** yeni yerdə yuxarıdakı qonşu */
  beforeId?: string | null;
  /** yeni yerdə aşağıdakı qonşu */
  afterId?: string | null;
};

/** Lövhədə / backlog-da tapşırığı köçürür: status, sprint və sıra */
export async function moveIssue(issueId: string, input: MoveIssueInput): Promise<ActionResult<{ rank: number }>> {
  return safe(async () => {
    const user = await requireUser();
    const issue = await db.issue.findUnique({ where: { id: issueId }, select: { projectId: true } });
    if (!issue) throw new Error("issueNotFound");
    await assertProjectAccess(issue.projectId, user);

    const patch: IssuePatch = {};
    if (input.status !== undefined) patch.status = input.status;
    if (input.sprintId !== undefined) patch.sprintId = input.sprintId;
    if (input.assigneeId !== undefined) patch.assigneeId = input.assigneeId;
    if (input.parentId !== undefined) patch.parentId = input.parentId;
    if (input.beforeId !== undefined || input.afterId !== undefined) {
      patch.rank = await computeRank(issue.projectId, input.beforeId, input.afterId);
    }
    const updated = await applyIssueUpdate(user.id, issueId, patch);
    revalidatePath("/", "layout");
    return { rank: updated.rank };
  });
}

export type QuickCreateInput = {
  title: string;
  type?: string;
  sprintId?: string | null;
  status?: string;
  assigneeId?: string | null;
  parentId?: string | null;
};

/** Lövhə və backlog-dakı sürətli yaratma sətri üçün */
export async function quickCreateIssue(projectId: string, input: QuickCreateInput): Promise<ActionResult<{ id: string; key: string }>> {
  return safe(async () => {
    const user = await requireUser();
    await assertProjectAccess(projectId, user);
    if (input.sprintId) {
      const s = await db.sprint.findUnique({ where: { id: input.sprintId }, select: { projectId: true, state: true } });
      if (!s || s.projectId !== projectId) throw new Error("sprintNotFound");
      if (s.state === "COMPLETED") throw new Error("board.errCompletedSprint");
    }
    const issue = await createIssueRecord({
      projectId,
      reporterId: user.id,
      title: input.title,
      type: input.type,
      status: input.status,
      sprintId: input.sprintId ?? null,
      assigneeId: input.assigneeId ?? null,
      parentId: input.parentId ?? null,
    });
    revalidatePath("/", "layout");
    return { id: issue.id, key: issue.key };
  });
}
