"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { isProjectAdmin } from "@/lib/access";
import { fail, safe } from "@/lib/action-result";
import { PROJECT_TYPES } from "@/lib/constants";
import { AppError } from "@/lib/errors";
import { translateError } from "@/i18n/server";

// Validasiya mesajları tərcümə açarlarıdır (src/i18n/messages/projects.ts)
const failKey = async (key: string | undefined) => fail(await translateError(key ?? "projects.errInvalid"));

const hex = /^#[0-9A-Fa-f]{6}$/;

const baseSchema = z.object({
  name: z.string().trim().min(2, "projects.errNameMin").max(80, "projects.errNameLong"),
  description: z.string().trim().max(2000, "projects.errDescLong").nullish(),
  type: z.enum(PROJECT_TYPES, { message: "projects.errType" }),
  color: z.string().regex(hex, "projects.errColor"),
  leadId: z.string().nullish(),
});

const createSchema = baseSchema.extend({
  key: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z][A-Z0-9]{1,9}$/, "projects.errKeyFormat"),
});

export type ProjectInput = z.input<typeof baseSchema>;
export type CreateProjectInput = z.input<typeof createSchema>;

export async function createProject(input: CreateProjectInput) {
  const parsed = createSchema.safeParse(input);
  if (!parsed.success) return failKey(parsed.error.issues[0]?.message);
  const { name, key, type, color, description, leadId } = parsed.data;

  return safe(async () => {
    const user = await requireUser();
    if (user.role !== "ADMIN") throw new Error("projects.errAdminOnly");
    if (await db.project.findUnique({ where: { key } })) throw new AppError("projects.errKeyTaken", { key });
    const lead = leadId ? await db.user.findUnique({ where: { id: leadId }, select: { id: true, active: true } }) : null;
    if (leadId && (!lead || !lead.active)) throw new Error("projects.errLeadNotFound");
    const leadUserId = lead?.id ?? user.id;

    const memberIds = Array.from(new Set([user.id, leadUserId]));
    const project = await db.project.create({
      data: {
        name,
        key,
        type,
        color,
        description: description || null,
        leadId: leadUserId,
        members: { create: memberIds.map((userId) => ({ userId, role: "ADMIN" })) },
        ...(type === "SCRUM" ? { sprints: { create: { name: `${key} Sprint 1`, state: "PLANNED" } } } : {}),
      },
      select: { key: true },
    });
    revalidatePath("/", "layout");
    return { key: project.key };
  });
}

async function assertManage(projectId: string) {
  const user = await requireUser();
  if (!(await isProjectAdmin(projectId, user))) throw new Error("projects.errNeedProjectAdmin");
  return user;
}

export async function updateProject(projectId: string, input: ProjectInput) {
  const parsed = baseSchema.safeParse(input);
  if (!parsed.success) return failKey(parsed.error.issues[0]?.message);
  const { name, type, color, description, leadId } = parsed.data;

  return safe(async () => {
    await assertManage(projectId);
    if (leadId) {
      const lead = await db.user.findUnique({ where: { id: leadId }, select: { active: true } });
      if (!lead?.active) throw new Error("projects.errLeadNotFound");
      // rəhbər layihə üzvü olmalıdır
      await db.projectMember.upsert({
        where: { projectId_userId: { projectId, userId: leadId } },
        create: { projectId, userId: leadId, role: "ADMIN" },
        update: {},
      });
    }
    await db.project.update({
      where: { id: projectId },
      data: { name, type, color, description: description || null, leadId: leadId || null },
    });
    revalidatePath("/", "layout");
  });
}

export async function deleteProject(projectId: string, confirmKey: string) {
  return safe(async () => {
    await assertManage(projectId);
    const project = await db.project.findUnique({ where: { id: projectId }, select: { key: true } });
    if (!project) throw new Error("projectNotFound");
    if (confirmKey.trim().toUpperCase() !== project.key) throw new Error("projects.errConfirmKey");
    await db.project.delete({ where: { id: projectId } });
    revalidatePath("/", "layout");
    redirect("/projects");
  });
}

const roleSchema = z.enum(["ADMIN", "MEMBER"]);

export async function addProjectMember(projectId: string, userId: string, role: string = "MEMBER") {
  const r = roleSchema.safeParse(role);
  if (!r.success) return failKey("projects.errBadRole");
  return safe(async () => {
    await assertManage(projectId);
    const u = await db.user.findUnique({ where: { id: userId }, select: { active: true } });
    if (!u?.active) throw new Error("userNotFound");
    await db.projectMember.upsert({
      where: { projectId_userId: { projectId, userId } },
      create: { projectId, userId, role: r.data },
      update: { role: r.data },
    });
    revalidatePath("/", "layout");
  });
}

async function adminCount(projectId: string) {
  return db.projectMember.count({ where: { projectId, role: "ADMIN" } });
}

export async function updateProjectMemberRole(projectId: string, userId: string, role: string) {
  const r = roleSchema.safeParse(role);
  if (!r.success) return failKey("projects.errBadRole");
  return safe(async () => {
    await assertManage(projectId);
    const m = await db.projectMember.findUnique({ where: { projectId_userId: { projectId, userId } } });
    if (!m) throw new Error("projects.errMemberNotFound");
    if (m.role === "ADMIN" && r.data !== "ADMIN" && (await adminCount(projectId)) <= 1) {
      throw new Error("projects.errLastAdmin");
    }
    await db.projectMember.update({ where: { projectId_userId: { projectId, userId } }, data: { role: r.data } });
    revalidatePath("/", "layout");
  });
}

export async function removeProjectMember(projectId: string, userId: string) {
  return safe(async () => {
    await assertManage(projectId);
    const m = await db.projectMember.findUnique({ where: { projectId_userId: { projectId, userId } } });
    if (!m) throw new Error("projects.errMemberNotFound");
    if (m.role === "ADMIN" && (await adminCount(projectId)) <= 1) throw new Error("projects.errLastAdminRemove");
    await db.$transaction([
      db.projectMember.delete({ where: { projectId_userId: { projectId, userId } } }),
      db.project.updateMany({ where: { id: projectId, leadId: userId }, data: { leadId: null } }),
    ]);
    revalidatePath("/", "layout");
  });
}
