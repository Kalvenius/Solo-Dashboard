"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/lib/db";
import { endSession, hashPassword, startSession, verifyPassword } from "@/lib/auth";
import { getT } from "@/i18n/server";

export type AuthState = { error?: string } | undefined;

// Zod mesajları auth namespace açarlarıdır — qaytarmazdan əvvəl tərcümə olunur
const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("errInvalidEmail"),
  password: z.string().min(1, "errPasswordRequired"),
  next: z.string().optional(),
});

type AuthKey = Parameters<Awaited<ReturnType<typeof getT<"auth">>>>[0];

async function err(key: string | undefined): Promise<AuthState> {
  const t = await getT("auth");
  return { error: t((key ?? "errBadCredentials") as AuthKey) };
}

export async function loginAction(_: AuthState, form: FormData): Promise<AuthState> {
  const parsed = loginSchema.safeParse(Object.fromEntries(form));
  if (!parsed.success) return err(parsed.error.issues[0]?.message);
  const { email, password, next } = parsed.data;

  const user = await db.user.findUnique({ where: { email } });
  if (!user || !(await verifyPassword(password, user.passwordHash))) return err("errBadCredentials");
  if (!user.active) return err("errDeactivated");

  await startSession(user.id);
  redirect(next && next.startsWith("/") && !next.startsWith("//") ? next : "/your-work");
}

const setupSchema = z.object({
  name: z.string().trim().min(2, "errNameMin"),
  email: z.string().trim().toLowerCase().email("errInvalidEmail"),
  password: z.string().min(6, "errPasswordMin"),
  title: z.string().trim().optional(),
});

/** İlk quraşdırma: yalnız sistemdə heç bir istifadəçi olmayanda işləyir */
export async function setupAction(_: AuthState, form: FormData): Promise<AuthState> {
  if ((await db.user.count()) > 0) return err("errAlreadySetup");
  const parsed = setupSchema.safeParse(Object.fromEntries(form));
  if (!parsed.success) return err(parsed.error.issues[0]?.message);
  const { name, email, password, title } = parsed.data;
  const t = await getT("auth");

  const user = await db.user.create({
    data: { name, email, passwordHash: await hashPassword(password), role: "ADMIN", title: title || t("defaultLeadTitle") },
  });
  await startSession(user.id);
  redirect("/projects");
}

export async function logoutAction() {
  await endSession();
  redirect("/login");
}
