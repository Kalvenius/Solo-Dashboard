"use server";

import { revalidatePath } from "next/cache";
import { unlink } from "node:fs/promises";
import path from "node:path";
import { db, textContains } from "@/lib/db";
import { requireUser, type CurrentUser } from "@/lib/auth";
import { assertProjectAccess, isProjectAdmin, issueScope } from "@/lib/access";
import { applyIssueUpdate, createIssueRecord, type IssuePatch } from "@/lib/issue-service";
import { issueAudience, logActivity, notifMessage, notify } from "@/lib/activity";
import { safe } from "@/lib/action-result";
import { LINK_TYPES, isIssueType, type LinkType } from "@/lib/constants";
import { userMiniSelect } from "@/lib/issue-select";
import { parseDuration, parseLabels } from "@/lib/utils";

// ---------- köməkçilər ----------

const refresh = () => revalidatePath("/", "layout");

/** "yyyy-MM-dd" → yerli günorta (saat qurşağı sürüşməsin deyə) */
function toDate(s: string | null | undefined): Date | null {
  if (!s) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) throw new Error("issue.errInvalidDate");
  const d = new Date(`${s}T12:00:00`);
  if (Number.isNaN(d.getTime())) throw new Error("issue.errInvalidDate");
  return d;
}

function toPoints(v: number | null | undefined): number | null {
  if (v == null || Number.isNaN(v)) return null;
  if (v < 0 || v > 999) throw new Error("issue.errPointsRange");
  return Math.round(v);
}

async function loadIssueChecked(issueId: string, user: CurrentUser) {
  const issue = await db.issue.findUnique({
    where: { id: issueId },
    select: { id: true, key: true, projectId: true, reporterId: true, type: true, project: { select: { key: true } } },
  });
  if (!issue) throw new Error("issueNotFound");
  await assertProjectAccess(issue.projectId, user);
  return issue;
}

async function assertMemberOf(projectId: string, userId: string) {
  const u = await db.user.findUnique({ where: { id: userId }, select: { role: true, active: true } });
  if (!u || !u.active) throw new Error("issue.errUserInactive");
  if (u.role === "ADMIN") return;
  const m = await db.projectMember.findUnique({ where: { projectId_userId: { projectId, userId } } });
  if (!m) throw new Error("issue.errNotMember");
}

// ---------- yaratma ----------

export type CreateIssueForm = {
  projectId: string;
  type: string;
  title: string;
  description?: string | null;
  assigneeId?: string | null;
  priority?: string;
  labels?: string;
  sprintId?: string | null;
  parentId?: string | null;
  storyPoints?: number | null;
  dueDate?: string | null;
  status?: string;
};

export async function createIssue(input: CreateIssueForm) {
  return safe(async () => {
    const user = await requireUser();
    await assertProjectAccess(input.projectId, user);
    if (!isIssueType(input.type)) throw new Error("invalidType");
    if (input.assigneeId) await assertMemberOf(input.projectId, input.assigneeId);
    // alt tapşırıq sprinti valideyndən alır (createIssueRecord), ona görə burada yoxlanmır
    if (input.type === "SUBTASK") input = { ...input, sprintId: null };
    if (input.sprintId) {
      const s = await db.sprint.findUnique({ where: { id: input.sprintId }, select: { projectId: true, state: true } });
      if (!s || s.projectId !== input.projectId) throw new Error("sprintNotFound");
      if (s.state === "COMPLETED") throw new Error("issue.errSprintCompleted");
    }
    if (input.parentId) {
      const p = await db.issue.findUnique({ where: { id: input.parentId }, select: { projectId: true, type: true } });
      if (!p || p.projectId !== input.projectId) throw new Error("parentNotFound");
      if (input.type === "SUBTASK" && p.type === "SUBTASK") throw new Error("issue.errSubtaskOfSubtask");
      if (input.type !== "SUBTASK" && p.type !== "EPIC") throw new Error("issue.errParentMustBeEpic");
    }
    if (input.type === "EPIC" && input.parentId) throw new Error("issue.errEpicNoParent");

    const issue = await createIssueRecord({
      projectId: input.projectId,
      reporterId: user.id,
      title: input.title,
      type: input.type,
      status: input.status,
      priority: input.priority,
      description: input.description,
      assigneeId: input.assigneeId,
      parentId: input.parentId,
      sprintId: input.sprintId,
      storyPoints: toPoints(input.storyPoints),
      dueDate: toDate(input.dueDate),
      labels: parseLabels(input.labels),
    });
    refresh();
    return { id: issue.id, key: issue.key };
  });
}

/** Yaratma modalı üçün layihə seçimləri */
export async function getCreateIssueOptions(projectId: string) {
  return safe(async () => {
    const user = await requireUser();
    await assertProjectAccess(projectId, user);
    const [members, sprints, epics, labelRows] = await Promise.all([
      db.projectMember.findMany({
        where: { projectId, user: { active: true } },
        select: { user: { select: userMiniSelect } },
        orderBy: { user: { name: "asc" } },
      }),
      db.sprint.findMany({
        where: { projectId, state: { not: "COMPLETED" } },
        select: { id: true, name: true, state: true },
        orderBy: [{ state: "asc" }, { createdAt: "asc" }],
      }),
      db.issue.findMany({ where: { projectId, type: "EPIC" }, select: { id: true, key: true, title: true }, orderBy: { number: "asc" } }),
      db.issue.findMany({ where: { projectId, labels: { not: "" } }, select: { labels: true } }),
    ]);
    return {
      members: members.map((m) => m.user),
      sprints,
      epics,
      labels: Array.from(new Set(labelRows.flatMap((r) => parseLabels(r.labels)))).sort(),
    };
  });
}

// ---------- yeniləmə ----------

export type IssuePatchInput = Omit<IssuePatch, "startDate" | "dueDate"> & {
  startDate?: string | null;
  dueDate?: string | null;
  reporterId?: string;
};

export async function updateIssue(issueId: string, patch: IssuePatchInput) {
  return safe(async () => {
    const user = await requireUser();
    const issue = await loadIssueChecked(issueId, user);
    const { startDate, dueDate, reporterId, ...rest } = patch;
    const p: IssuePatch = { ...rest };
    if (startDate !== undefined) p.startDate = toDate(startDate);
    if (dueDate !== undefined) p.dueDate = toDate(dueDate);
    if (patch.storyPoints !== undefined) p.storyPoints = toPoints(patch.storyPoints);
    if (patch.estimateMinutes !== undefined && patch.estimateMinutes !== null && patch.estimateMinutes < 0) throw new Error("issue.errNegativeTime");
    if (patch.assigneeId) await assertMemberOf(issue.projectId, patch.assigneeId);
    if (patch.parentId) {
      const parent = await db.issue.findUnique({ where: { id: patch.parentId }, select: { type: true } });
      if (issue.type !== "SUBTASK" && parent?.type !== "EPIC") throw new Error("issue.errParentMustBeEpic");
    }

    await applyIssueUpdate(user.id, issueId, p);

    if (reporterId && reporterId !== issue.reporterId) {
      await assertMemberOf(issue.projectId, reporterId);
      const [from, to] = await Promise.all([
        db.user.findUnique({ where: { id: issue.reporterId }, select: { name: true } }),
        db.user.findUnique({ where: { id: reporterId }, select: { name: true } }),
      ]);
      await db.issue.update({ where: { id: issueId }, data: { reporterId } });
      await logActivity({ issueId, actorId: user.id, action: "UPDATED", field: "reporter", fromValue: from?.name, toValue: to?.name });
    }
    refresh();
  });
}

export async function deleteIssue(issueId: string) {
  return safe(async () => {
    const user = await requireUser();
    const issue = await loadIssueChecked(issueId, user);
    const allowed = issue.reporterId === user.id || (await isProjectAdmin(issue.projectId, user));
    if (!allowed) throw new Error("issue.errCantDelete");

    const subtaskIds = (await db.issue.findMany({ where: { parentId: issueId, type: "SUBTASK" }, select: { id: true } })).map((s) => s.id);
    const ids = [issueId, ...subtaskIds];
    const files = await db.attachment.findMany({ where: { issueId: { in: ids } }, select: { storedName: true } });

    await db.$transaction([
      db.issue.deleteMany({ where: { id: { in: subtaskIds } } }),
      db.issue.delete({ where: { id: issueId } }),
    ]);
    await Promise.all(files.map((f) => unlink(attachmentPath(f.storedName)).catch(() => undefined)));
    refresh();
    return { projectKey: issue.project.key };
  });
}

// ---------- şərhlər ----------

export async function addComment(issueId: string, body: string) {
  return safe(async () => {
    const user = await requireUser();
    const issue = await loadIssueChecked(issueId, user);
    const text = body.trim();
    if (!text) throw new Error("issue.errCommentEmpty");
    if (text.length > 20000) throw new Error("issue.errCommentTooLong");

    // @Ad Soyad və ya @Ad ilə qeyd olunan layihə üzvləri
    const members = await db.projectMember.findMany({ where: { projectId: issue.projectId }, select: { user: { select: { id: true, name: true } } } });
    const lower = text.toLocaleLowerCase("az");
    const mentioned = members
      .map((m) => m.user)
      .filter((u) => {
        const full = `@${u.name}`.toLocaleLowerCase("az");
        const first = `@${u.name.split(/\s+/)[0]}`.toLocaleLowerCase("az");
        return lower.includes(full) || new RegExp(`${escapeRe(first)}(?![\\p{L}])`, "u").test(lower);
      })
      .map((u) => u.id);

    await db.$transaction(async (tx) => {
      await tx.comment.create({ data: { issueId, authorId: user.id, body: text } });
      await logActivity({ issueId, actorId: user.id, action: "COMMENTED" }, tx);
      await tx.watcher.upsert({ where: { issueId_userId: { issueId, userId: user.id } }, create: { issueId, userId: user.id }, update: {} });
      await tx.issue.update({ where: { id: issueId }, data: { updatedAt: new Date() } });
      if (mentioned.length) {
        await notify({ userIds: mentioned, actorId: user.id, issueId, type: "MENTIONED", message: notifMessage("mentioned", { key: issue.key }) }, tx);
      }
      const audience = (await issueAudience(issueId, tx)).filter((id) => id && !mentioned.includes(id));
      await notify({ userIds: audience, actorId: user.id, issueId, type: "COMMENTED", message: notifMessage("commented", { key: issue.key }) }, tx);
    });
    refresh();
  });
}

function escapeRe(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export async function updateComment(commentId: string, body: string) {
  return safe(async () => {
    const user = await requireUser();
    const c = await db.comment.findUnique({ where: { id: commentId }, select: { authorId: true, issueId: true } });
    if (!c) throw new Error("issue.errCommentNotFound");
    if (c.authorId !== user.id) throw new Error("issue.errEditOwnComment");
    const text = body.trim();
    if (!text) throw new Error("issue.errCommentEmpty");
    await db.comment.update({ where: { id: commentId }, data: { body: text } });
    refresh();
  });
}

export async function deleteComment(commentId: string) {
  return safe(async () => {
    const user = await requireUser();
    const c = await db.comment.findUnique({ where: { id: commentId }, select: { authorId: true, issue: { select: { projectId: true } } } });
    if (!c) throw new Error("issue.errCommentNotFound");
    if (c.authorId !== user.id && !(await isProjectAdmin(c.issue.projectId, user))) throw new Error("issue.errCantDeleteComment");
    await db.comment.delete({ where: { id: commentId } });
    refresh();
  });
}

// ---------- iş vaxtı ----------

export async function logWork(issueId: string, input: { duration: string; date: string; note?: string }) {
  return safe(async () => {
    const user = await requireUser();
    await loadIssueChecked(issueId, user);
    const minutes = parseDuration(input.duration);
    if (!minutes) throw new Error("issue.errBadDuration");
    if (minutes > 24 * 60) throw new Error("issue.errMax24h");
    const day = toDate(input.date) ?? new Date();
    const today = new Date();
    const startedAt = day.toDateString() === today.toDateString() ? today : day;
    if (startedAt.getTime() > Date.now() + 60_000) throw new Error("issue.errFutureDate");

    await db.$transaction(async (tx) => {
      await tx.workLog.create({ data: { issueId, userId: user.id, minutes, startedAt, note: input.note?.trim() || null } });
      await logActivity({ issueId, actorId: user.id, action: "LOGGED_WORK", toValue: String(minutes) }, tx);
    });
    refresh();
  });
}

export async function deleteWorklog(worklogId: string) {
  return safe(async () => {
    const user = await requireUser();
    const w = await db.workLog.findUnique({ where: { id: worklogId }, select: { userId: true, issue: { select: { projectId: true } } } });
    if (!w) throw new Error("issue.errWorklogNotFound");
    if (w.userId !== user.id && !(await isProjectAdmin(w.issue.projectId, user))) throw new Error("issue.errCantDeleteWorklog");
    await db.workLog.delete({ where: { id: worklogId } });
    refresh();
  });
}

// ---------- izləmə ----------

export async function toggleWatch(issueId: string) {
  return safe(async () => {
    const user = await requireUser();
    await loadIssueChecked(issueId, user);
    const key = { issueId_userId: { issueId, userId: user.id } };
    const existing = await db.watcher.findUnique({ where: key });
    if (existing) await db.watcher.delete({ where: key });
    else await db.watcher.create({ data: { issueId, userId: user.id } });
    refresh();
    return !existing;
  });
}

// ---------- əlaqələr ----------

export async function addLink(issueId: string, targetId: string, type: string, direction: "out" | "in") {
  return safe(async () => {
    const user = await requireUser();
    const issue = await loadIssueChecked(issueId, user);
    if (!(LINK_TYPES as readonly string[]).includes(type)) throw new Error("issue.errInvalidLinkType");
    if (targetId === issueId) throw new Error("issue.errSelfLink");
    const target = await loadIssueChecked(targetId, user);
    const [fromId, toId] = direction === "out" ? [issueId, targetId] : [targetId, issueId];

    const dup = await db.issueLink.findFirst({
      where: {
        type: type as LinkType,
        OR: [
          { fromId, toId },
          ...(type === "RELATES" ? [{ fromId: toId, toId: fromId }] : []),
        ],
      },
    });
    if (dup) throw new Error("issue.errLinkExists");

    await db.issueLink.create({ data: { type, fromId, toId } });
    await logActivity({ issueId, actorId: user.id, action: "UPDATED", field: "link", toValue: target.key });
    await logActivity({ issueId: targetId, actorId: user.id, action: "UPDATED", field: "link", toValue: issue.key });
    refresh();
  });
}

export async function removeLink(linkId: string) {
  return safe(async () => {
    const user = await requireUser();
    const link = await db.issueLink.findUnique({
      where: { id: linkId },
      include: { from: { select: { id: true, key: true, projectId: true } }, to: { select: { id: true, key: true, projectId: true } } },
    });
    if (!link) throw new Error("issue.errLinkNotFound");
    await assertProjectAccess(link.from.projectId, user);
    await db.issueLink.delete({ where: { id: linkId } });
    await logActivity({ issueId: link.from.id, actorId: user.id, action: "UPDATED", field: "link", fromValue: link.to.key });
    await logActivity({ issueId: link.to.id, actorId: user.id, action: "UPDATED", field: "link", fromValue: link.from.key });
    refresh();
  });
}

/** Əlaqə üçün tapşırıq axtarışı (açar və ya başlıq üzrə) */
export async function searchIssuesForLink(q: string, excludeId?: string) {
  return safe(async () => {
    const user = await requireUser();
    const term = q.trim();
    const scope = await issueScope(user);
    return db.issue.findMany({
      where: {
        ...scope,
        ...(excludeId ? { id: { not: excludeId } } : {}),
        ...(term ? { OR: [{ key: { contains: term.toUpperCase() } }, { title: textContains(term) }] } : {}),
      },
      select: { id: true, key: true, title: true, type: true, status: true, project: { select: { name: true } } },
      orderBy: { updatedAt: "desc" },
      take: 10,
    });
  });
}

// ---------- fayllar ----------

function attachmentPath(storedName: string) {
  return path.join(process.cwd(), "uploads", path.basename(storedName));
}

export async function deleteAttachment(attachmentId: string) {
  return safe(async () => {
    const user = await requireUser();
    const a = await db.attachment.findUnique({ where: { id: attachmentId }, include: { issue: { select: { projectId: true } } } });
    if (!a) throw new Error("issue.errAttachmentNotFound");
    if (a.uploaderId !== user.id && !(await isProjectAdmin(a.issue.projectId, user))) throw new Error("issue.errCantDeleteAttachment");
    await db.attachment.delete({ where: { id: attachmentId } });
    await unlink(attachmentPath(a.storedName)).catch(() => undefined);
    refresh();
  });
}

/** Fayl yükləndikdən sonra (API route vasitəsilə) səhifəni yeniləmək üçün */
export async function refreshAfterUpload() {
  await requireUser();
  refresh();
}
