"use server";

import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { safe } from "@/lib/action-result";

export async function listNotifications() {
  return safe(async () => {
    const user = await requireUser();
    return db.notification.findMany({
      where: { userId: user.id },
      include: {
        actor: { select: { id: true, name: true, avatarColor: true } },
        issue: { select: { key: true, title: true, type: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 20,
    });
  });
}

export async function unreadCount() {
  return safe(async () => {
    const user = await requireUser();
    return db.notification.count({ where: { userId: user.id, read: false } });
  });
}

export async function markNotificationRead(id: string) {
  return safe(async () => {
    const user = await requireUser();
    await db.notification.updateMany({ where: { id, userId: user.id }, data: { read: true } });
  });
}

export async function markAllRead() {
  return safe(async () => {
    const user = await requireUser();
    await db.notification.updateMany({ where: { userId: user.id, read: false }, data: { read: true } });
  });
}
