import "server-only";
import { db } from "./db";
import type { CurrentUser } from "./auth";

/** Layihəni açar ilə tapır; istifadəçinin girişi yoxdursa null qaytarır. Admin hər layihəni görür. */
export async function getProjectForUser(key: string, user: CurrentUser) {
  const project = await db.project.findUnique({
    where: { key: key.toUpperCase() },
    include: {
      lead: { select: { id: true, name: true, avatarColor: true } },
      members: {
        include: { user: { select: { id: true, name: true, email: true, avatarColor: true, title: true, active: true } } },
        orderBy: { joinedAt: "asc" },
      },
    },
  });
  if (!project) return null;
  if (user.role !== "ADMIN" && !project.members.some((m) => m.userId === user.id)) return null;
  return project;
}

export type ProjectWithMembers = NonNullable<Awaited<ReturnType<typeof getProjectForUser>>>;

/** Server action-larda: layihəyə giriş yoxdursa xəta atır */
export async function assertProjectAccess(projectId: string, user: CurrentUser) {
  if (user.role === "ADMIN") return;
  const m = await db.projectMember.findUnique({ where: { projectId_userId: { projectId, userId: user.id } } });
  if (!m) throw new Error("noProjectAccess");
}

/** Layihə admini (və ya sistem admini) olub-olmadığını yoxlayır */
export async function isProjectAdmin(projectId: string, user: CurrentUser) {
  if (user.role === "ADMIN") return true;
  const m = await db.projectMember.findUnique({ where: { projectId_userId: { projectId, userId: user.id } } });
  return m?.role === "ADMIN";
}

/** İstifadəçinin görə bildiyi layihə id-ləri. Admin üçün null (= hamısı). */
export async function accessibleProjectIds(user: CurrentUser): Promise<string[] | null> {
  if (user.role === "ADMIN") return null;
  const rows = await db.projectMember.findMany({ where: { userId: user.id }, select: { projectId: true } });
  return rows.map((r) => r.projectId);
}

/** Prisma where filtri: istifadəçinin görə bildiyi tapşırıqlar */
export async function issueScope(user: CurrentUser) {
  const ids = await accessibleProjectIds(user);
  return ids === null ? {} : { projectId: { in: ids } };
}

/** Tapşırığı açar ilə tapır və giriş hüququnu yoxlayır */
export async function getIssueForUser(issueKey: string, user: CurrentUser) {
  const issue = await db.issue.findUnique({ where: { key: issueKey.toUpperCase() }, select: { id: true, projectId: true } });
  if (!issue) return null;
  try {
    await assertProjectAccess(issue.projectId, user);
  } catch {
    return null;
  }
  return issue;
}
