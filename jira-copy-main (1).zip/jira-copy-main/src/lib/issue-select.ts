import type { Prisma } from "@prisma/client";

/** Lövhə kartı, backlog sətri və siyahı üçün ortaq tapşırıq seçimi */
export const issueCardSelect = {
  id: true,
  key: true,
  number: true,
  title: true,
  type: true,
  status: true,
  priority: true,
  storyPoints: true,
  dueDate: true,
  labels: true,
  rank: true,
  sprintId: true,
  parentId: true,
  projectId: true,
  createdAt: true,
  updatedAt: true,
  resolvedAt: true,
  assignee: { select: { id: true, name: true, avatarColor: true } },
  parent: { select: { id: true, key: true, title: true, type: true } },
  _count: { select: { children: true } },
} satisfies Prisma.IssueSelect;

export type IssueCardData = Prisma.IssueGetPayload<{ select: typeof issueCardSelect }>;

export const userMiniSelect = { id: true, name: true, avatarColor: true } satisfies Prisma.UserSelect;
export type UserMini = Prisma.UserGetPayload<{ select: typeof userMiniSelect }>;
