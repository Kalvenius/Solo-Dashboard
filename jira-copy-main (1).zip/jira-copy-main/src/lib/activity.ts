import "server-only";
import type { Prisma, PrismaClient } from "@prisma/client";
import { db } from "./db";

type Tx = PrismaClient | Prisma.TransactionClient;

export async function logActivity(
  input: { issueId: string; actorId: string; action: string; field?: string; fromValue?: string | null; toValue?: string | null },
  tx: Tx = db,
) {
  await tx.activity.create({
    data: {
      issueId: input.issueId,
      actorId: input.actorId,
      action: input.action,
      field: input.field ?? null,
      fromValue: input.fromValue ?? null,
      toValue: input.toValue ?? null,
    },
  });
}

/**
 * Bildiriş mətni bazada tərcümə açarı + parametrlər kimi (JSON) saxlanılır ki, hər istifadəçi öz dilində görsün.
 * Növlər və parametrlər (notifications namespace-də "notif.<k>" açarları ilə render olunur):
 *   assigned {key} · status {key, status: "IN_PROGRESS"} · commented {key} · mentioned {key}
 */
export function notifMessage(k: "assigned" | "status" | "commented" | "mentioned", p: Record<string, string>) {
  return JSON.stringify({ k, p });
}

/** Bildiriş göndərir (hərəkəti edən şəxsə göndərmir). message: notifMessage(...) */
export async function notify(
  input: { userIds: (string | null | undefined)[]; actorId: string; issueId?: string; type: string; message: string },
  tx: Tx = db,
) {
  const ids = Array.from(new Set(input.userIds.filter((u): u is string => !!u && u !== input.actorId)));
  if (!ids.length) return;
  await tx.notification.createMany({
    data: ids.map((userId) => ({
      userId,
      actorId: input.actorId,
      issueId: input.issueId ?? null,
      type: input.type,
      message: input.message,
    })),
  });
}

/** Tapşırığı izləyənlər + icraçı + müəllif */
export async function issueAudience(issueId: string, tx: Tx = db) {
  const issue = await tx.issue.findUnique({
    where: { id: issueId },
    select: { assigneeId: true, reporterId: true, watchers: { select: { userId: true } } },
  });
  if (!issue) return [];
  return [issue.assigneeId, issue.reporterId, ...issue.watchers.map((w) => w.userId)];
}
