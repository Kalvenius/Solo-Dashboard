// Tapşırıq növləri, statuslar, prioritetlər.
// Adlar (etiketlər) tərcümə olunur: src/i18n/messages/enums.ts → te(`status.${s}`), te(`priority.${p}`), te(`type.${t}`)

export const ISSUE_TYPES = ["EPIC", "STORY", "TASK", "BUG", "SUBTASK"] as const;
export type IssueType = (typeof ISSUE_TYPES)[number];

export const ISSUE_TYPE_META: Record<IssueType, { color: string }> = {
  EPIC: { color: "#6E5DC6" },
  STORY: { color: "#22A06B" },
  TASK: { color: "#1D7AFC" },
  BUG: { color: "#E2483D" },
  SUBTASK: { color: "#4BADE8" },
};

export const STATUSES = ["TODO", "IN_PROGRESS", "IN_REVIEW", "DONE"] as const;
export type Status = (typeof STATUSES)[number];

// category: Jira-dakı kimi rəng qrupu (boz / mavi / yaşıl)
export const STATUS_META: Record<Status, { category: "todo" | "progress" | "done" }> = {
  TODO: { category: "todo" },
  IN_PROGRESS: { category: "progress" },
  IN_REVIEW: { category: "progress" },
  DONE: { category: "done" },
};

export const PRIORITIES = ["HIGHEST", "HIGH", "MEDIUM", "LOW", "LOWEST"] as const;
export type Priority = (typeof PRIORITIES)[number];

export const PRIORITY_META: Record<Priority, { color: string; weight: number }> = {
  HIGHEST: { color: "#C9372C", weight: 5 },
  HIGH: { color: "#E2483D", weight: 4 },
  MEDIUM: { color: "#E2B203", weight: 3 },
  LOW: { color: "#1D7AFC", weight: 2 },
  LOWEST: { color: "#579DFF", weight: 1 },
};

export const LINK_TYPES = ["BLOCKS", "RELATES", "DUPLICATES"] as const;
export type LinkType = (typeof LINK_TYPES)[number];

export const SPRINT_STATES = ["PLANNED", "ACTIVE", "COMPLETED"] as const;
export type SprintState = (typeof SPRINT_STATES)[number];

export const PROJECT_TYPES = ["SCRUM", "KANBAN"] as const;
export type ProjectType = (typeof PROJECT_TYPES)[number];


export const AVATAR_COLORS = [
  "#0C66E4", "#6E5DC6", "#22A06B", "#E2483D", "#D97008", "#1D9AAA",
  "#AE4787", "#5B7F24", "#946F00", "#8270DB", "#C9372C", "#2898BD",
];

export const PROJECT_COLORS = ["#0C66E4", "#6E5DC6", "#22A06B", "#D97008", "#1D9AAA", "#AE4787", "#E2483D", "#5B7F24"];


export const isStatus = (v: string): v is Status => (STATUSES as readonly string[]).includes(v);
export const isIssueType = (v: string): v is IssueType => (ISSUE_TYPES as readonly string[]).includes(v);
export const isPriority = (v: string): v is Priority => (PRIORITIES as readonly string[]).includes(v);
