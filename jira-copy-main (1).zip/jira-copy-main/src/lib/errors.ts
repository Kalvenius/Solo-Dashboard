import type { Params } from "@/i18n/format";

/**
 * Tərcümə olunan istifadəçi xətası. message = tərcümə açarı ("titleRequired" və ya "backlog.errSprintEmpty").
 * safe() onu istifadəçinin dilinə çevirir. Parametrsiz xətalar üçün sadəcə throw new Error("açar") da olar.
 */
export class AppError extends Error {
  constructor(
    key: string,
    public params?: Params,
  ) {
    super(key);
    this.name = "AppError";
  }
}
