import "server-only";
import { db } from "./db";
import { issueAudience, logActivity, notifMessage, notify } from "./activity";
import { isIssueType, isPriority, isStatus } from "./constants";
import { serializeLabels } from "./utils";

export type CreateIssueInput = {
  projectId: string;
  reporterId: string;
  title: string;
  type?: string;
  status?: string;
  priority?: string;
  description?: string | null;
  assigneeId?: string | null;
  parentId?: string | null;
  sprintId?: string | null;
  storyPoints?: number | null;
  estimateMinutes?: number | null;
  startDate?: Date | null;
  dueDate?: Date | null;
  labels?: string[];
};

/**
 * Yeni tapşırıq yaradır: açar nömrəsini artırır (WEB-42), sıranı sona qoyur,
 * tarixçə yazır, müəllifi izləyici edir və icraçıya bildiriş göndərir.
 */
export async function createIssueRecord(input: CreateIssueInput) {
  const title = input.title.trim();
  if (!title) throw new Error("titleRequired");
  const type = input.type && isIssueType(input.type) ? input.type : "TASK";
  const status = input.status && isStatus(input.status) ? input.status : "TODO";
  const priority = input.priority && isPriority(input.priority) ? input.priority : "MEDIUM";
  if (type === "SUBTASK" && !input.parentId) throw new Error("subtaskNeedsParent");

  return db.$transaction(async (tx) => {
    const project = await tx.project.update({
      where: { id: input.projectId },
      data: { issueCounter: { increment: 1 } },
      select: { key: true, issueCounter: true },
    });
    const last = await tx.issue.findFirst({ where: { projectId: input.projectId }, orderBy: { rank: "desc" }, select: { rank: true } });

    let sprintId = input.sprintId ?? null;
    if (type === "SUBTASK" && input.parentId) {
      // alt tapşırıq valideynin sprintində olur
      const parent = await tx.issue.findUnique({ where: { id: input.parentId }, select: { sprintId: true } });
      sprintId = parent?.sprintId ?? null;
    }
    if (type === "EPIC") sprintId = null;

    const issue = await tx.issue.create({
      data: {
        projectId: input.projectId,
        number: project.issueCounter,
        key: `${project.key}-${project.issueCounter}`,
        title,
        type,
        status,
        priority,
        description: input.description?.trim() || null,
        assigneeId: input.assigneeId || null,
        reporterId: input.reporterId,
        parentId: input.parentId || null,
        sprintId,
        storyPoints: input.storyPoints ?? null,
        estimateMinutes: input.estimateMinutes ?? null,
        startDate: input.startDate ?? null,
        dueDate: input.dueDate ?? null,
        labels: serializeLabels(input.labels ?? []),
        rank: (last?.rank ?? 0) + 1000,
        resolvedAt: status === "DONE" ? new Date() : null,
      },
    });

    await logActivity({ issueId: issue.id, actorId: input.reporterId, action: "CREATED" }, tx);
    await tx.watcher.create({ data: { issueId: issue.id, userId: input.reporterId } });
    if (issue.assigneeId) {
      await notify(
        { userIds: [issue.assigneeId], actorId: input.reporterId, issueId: issue.id, type: "ASSIGNED", message: notifMessage("assigned", { key: issue.key }) },
        tx,
      );
    }
    return issue;
  });
}

export type IssuePatch = Partial<{
  title: string;
  description: string | null;
  type: string;
  status: string;
  priority: string;
  assigneeId: string | null;
  parentId: string | null;
  sprintId: string | null;
  storyPoints: number | null;
  estimateMinutes: number | null;
  startDate: Date | null;
  dueDate: Date | null;
  labels: string[];
  rank: number;
}>;

const dateKey = (d: Date | null | undefined) => (d ? d.toISOString().slice(0, 10) : null);

/**
 * Tapşırığı yeniləyir — bütün dəyişikliklər buradan keçməlidir ki:
 *  - tarixçə (Activity) yazılsın (dashboard metrikləri status keçidlərindən hesablanır)
 *  - DONE olanda resolvedAt qoyulsun, geri qayıdanda silinsin
 *  - icraçıya / izləyicilərə bildiriş getsin
 *  - sprint dəyişəndə alt tapşırıqlar da köçsün
 * Status, prioritet, növ üçün tarixçədə xam kod saxlanılır (məs. "IN_PROGRESS"); icraçı/sprint/valideyn üçün ad.
 */
export async function applyIssueUpdate(actorId: string, issueId: string, patch: IssuePatch) {
  const current = await db.issue.findUnique({
    where: { id: issueId },
    include: {
      assignee: { select: { name: true } },
      sprint: { select: { name: true } },
      parent: { select: { key: true } },
    },
  });
  if (!current) throw new Error("issueNotFound");

  if (patch.title !== undefined && !patch.title.trim()) throw new Error("titleRequired");
  if (patch.status !== undefined && !isStatus(patch.status)) throw new Error("invalidStatus");
  if (patch.priority !== undefined && !isPriority(patch.priority)) throw new Error("invalidPriority");
  if (patch.type !== undefined && !isIssueType(patch.type)) throw new Error("invalidType");
  if (patch.parentId && patch.parentId === issueId) throw new Error("selfParent");

  const data: Record<string, unknown> = {};
  const changes: { field: string; from: string | null; to: string | null }[] = [];
  const track = (field: string, from: string | null | undefined, to: string | null | undefined) => {
    if ((from ?? null) !== (to ?? null)) changes.push({ field, from: from ?? null, to: to ?? null });
  };

  if (patch.title !== undefined && patch.title.trim() !== current.title) {
    data.title = patch.title.trim();
    track("title", current.title, data.title as string);
  }
  if (patch.description !== undefined) {
    const d = patch.description?.trim() || null;
    if (d !== current.description) {
      data.description = d;
      changes.push({ field: "description", from: null, to: null });
    }
  }
  if (patch.type !== undefined && patch.type !== current.type) {
    data.type = patch.type;
    track("type", current.type, patch.type);
    if (patch.type === "EPIC") data.sprintId = null;
  }
  if (patch.status !== undefined && patch.status !== current.status) {
    data.status = patch.status;
    track("status", current.status, patch.status);
    if (patch.status === "DONE") data.resolvedAt = new Date();
    else if (current.status === "DONE") data.resolvedAt = null;
  }
  if (patch.priority !== undefined && patch.priority !== current.priority) {
    data.priority = patch.priority;
    track("priority", current.priority, patch.priority);
  }
  let newAssigneeName: string | null = null;
  if (patch.assigneeId !== undefined && (patch.assigneeId || null) !== current.assigneeId) {
    data.assigneeId = patch.assigneeId || null;
    if (patch.assigneeId) {
      const u = await db.user.findUnique({ where: { id: patch.assigneeId }, select: { name: true } });
      if (!u) throw new Error("userNotFound");
      newAssigneeName = u.name;
    }
    track("assignee", current.assignee?.name, newAssigneeName);
  }
  if (patch.sprintId !== undefined && (patch.sprintId || null) !== current.sprintId) {
    const type = (data.type as string) ?? current.type;
    if (type !== "EPIC") {
      data.sprintId = patch.sprintId || null;
      const s = patch.sprintId ? await db.sprint.findUnique({ where: { id: patch.sprintId }, select: { name: true, projectId: true } }) : null;
      if (patch.sprintId && (!s || s.projectId !== current.projectId)) throw new Error("sprintNotFound");
      track("sprint", current.sprint?.name, s?.name);
    }
  }
  if (patch.parentId !== undefined && (patch.parentId || null) !== current.parentId) {
    const p = patch.parentId ? await db.issue.findUnique({ where: { id: patch.parentId }, select: { key: true, projectId: true } }) : null;
    if (patch.parentId && (!p || p.projectId !== current.projectId)) throw new Error("parentNotFound");
    data.parentId = patch.parentId || null;
    track("parent", current.parent?.key, p?.key);
  }
  if (patch.storyPoints !== undefined && patch.storyPoints !== current.storyPoints) {
    data.storyPoints = patch.storyPoints;
    track("storyPoints", current.storyPoints?.toString(), patch.storyPoints?.toString());
  }
  if (patch.estimateMinutes !== undefined && patch.estimateMinutes !== current.estimateMinutes) {
    data.estimateMinutes = patch.estimateMinutes;
    track("estimate", current.estimateMinutes?.toString(), patch.estimateMinutes?.toString());
  }
  if (patch.startDate !== undefined && dateKey(patch.startDate) !== dateKey(current.startDate)) {
    data.startDate = patch.startDate;
    track("startDate", dateKey(current.startDate), dateKey(patch.startDate));
  }
  if (patch.dueDate !== undefined && dateKey(patch.dueDate) !== dateKey(current.dueDate)) {
    data.dueDate = patch.dueDate;
    track("dueDate", dateKey(current.dueDate), dateKey(patch.dueDate));
  }
  if (patch.labels !== undefined) {
    const l = serializeLabels(patch.labels);
    if (l !== current.labels) {
      data.labels = l;
      track("labels", current.labels || null, l || null);
    }
  }
  if (patch.rank !== undefined && patch.rank !== current.rank) data.rank = patch.rank;

  if (Object.keys(data).length === 0) return current;

  return db.$transaction(async (tx) => {
    const updated = await tx.issue.update({ where: { id: issueId }, data });
    for (const c of changes) {
      await logActivity({ issueId, actorId, action: "UPDATED", field: c.field, fromValue: c.from, toValue: c.to }, tx);
    }
    // sprint dəyişəndə alt tapşırıqlar da köçür
    if ("sprintId" in data) {
      await tx.issue.updateMany({ where: { parentId: issueId, type: "SUBTASK" }, data: { sprintId: data.sprintId as string | null } });
    }
    if ("assigneeId" in data && data.assigneeId) {
      await notify({ userIds: [data.assigneeId as string], actorId, issueId, type: "ASSIGNED", message: notifMessage("assigned", { key: current.key }) }, tx);
      await tx.watcher.upsert({
        where: { issueId_userId: { issueId, userId: data.assigneeId as string } },
        create: { issueId, userId: data.assigneeId as string },
        update: {},
      });
    }
    if ("status" in data) {
      await notify(
        { userIds: await issueAudience(issueId, tx), actorId, issueId, type: "STATUS", message: notifMessage("status", { key: current.key, status: data.status as string }) },
        tx,
      );
    }
    return updated;
  });
}
