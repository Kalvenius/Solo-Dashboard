import { clsx, type ClassValue } from "clsx";
import { format, isValid } from "date-fns";

// Tarix/vaxt/rəqəm formatları dilə bağlıdır: server-də getFormat(), client-də useFormat() (src/i18n).

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join("");
}

type DateIn = Date | string | number | null | undefined;

/** input[type=date] üçün yyyy-MM-dd */
export function toDateInput(d: DateIn) {
  const date = d == null ? null : d instanceof Date ? d : new Date(d);
  return date && isValid(date) ? format(date, "yyyy-MM-dd") : "";
}

/**
 * Vaxt mətnini dəqiqəyə çevirir (hər üç dildə). Qəbul edir:
 * "2s 30d" / "2s 30dəq" (az), "2h 30m" (en), "2ч 30м" (ru), "1.5" (saat), "1g" / "1day" / "1д" (gün = 8 saat)
 */
export function parseDuration(input: string): number | null {
  const s = input.trim().toLowerCase().replace(",", ".");
  if (!s) return null;
  let total = 0;
  for (const m of s.matchAll(/(\d+(?:\.\d+)?)\s*([a-zəüöğışça-яё]*)/g)) {
    const n = parseFloat(m[1]!);
    const unit = m[2] ?? "";
    if (["g", "gün", "day", "days", "д", "дн", "день", "дня", "дней"].includes(unit)) total += n * 8 * 60;
    else if (unit === "" || unit.startsWith("s") || unit.startsWith("h") || unit.startsWith("ч")) total += n * 60;
    else if (unit.startsWith("d") || unit.startsWith("m") || unit.startsWith("м")) total += n;
    else return null;
  }
  return total > 0 ? Math.round(total) : null;
}

export function parseLabels(s: string | null | undefined): string[] {
  return (s ?? "")
    .split(",")
    .map((l) => l.trim())
    .filter(Boolean);
}

export function serializeLabels(labels: string[]) {
  return Array.from(new Set(labels.map((l) => l.trim().replace(/,/g, "")).filter(Boolean))).join(",");
}

export function pct(part: number, whole: number) {
  return whole > 0 ? Math.round((part / whole) * 100) : 0;
}
