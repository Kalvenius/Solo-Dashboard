import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const db = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = db;

/**
 * Mətn axtarışı filtri. SQLite-da `contains` artıq ASCII üçün hərf registrindən asılı deyil;
 * PostgreSQL-də isə `mode: "insensitive"` lazımdır. Hər iki bazada işləsin deyə bunu istifadə edin:
 *   where: { title: textContains(q) }
 */
export function textContains(q: string): { contains: string } {
  return (process.env.DATABASE_URL?.startsWith("postgres") ? { contains: q, mode: "insensitive" } : { contains: q }) as { contains: string };
}
