import "server-only";
import { db } from "./db";
import type { CurrentUser } from "./auth";
import { getIssueForUser, isProjectAdmin } from "./access";
import { issueCardSelect, userMiniSelect } from "./issue-select";
import { parseLabels } from "./utils";

const linkedSelect = { id: true, key: true, title: true, type: true, status: true, priority: true } as const;

/** Tapşırıq detalları səhifəsi/modalı üçün bütün məlumat (giriş yoxdursa null) */
export async function loadIssueDetail(issueKey: string, user: CurrentUser) {
  const ref = await getIssueForUser(issueKey, user);
  if (!ref) return null;

  const issue = await db.issue.findUnique({
    where: { id: ref.id },
    include: {
      project: { select: { id: true, key: true, name: true, color: true, type: true } },
      assignee: { select: userMiniSelect },
      reporter: { select: userMiniSelect },
      parent: { select: { id: true, key: true, title: true, type: true, status: true, parent: { select: { id: true, key: true, title: true, type: true } } } },
      sprint: { select: { id: true, name: true, state: true } },
      children: { select: issueCardSelect, orderBy: [{ rank: "asc" }, { number: "asc" }] },
      comments: { include: { author: { select: userMiniSelect } }, orderBy: { createdAt: "desc" } },
      activities: {
        where: { action: { not: "COMMENTED" } },
        include: { actor: { select: userMiniSelect } },
        orderBy: { createdAt: "desc" },
        take: 300,
      },
      worklogs: { include: { user: { select: userMiniSelect } }, orderBy: { startedAt: "desc" } },
      attachments: { include: { uploader: { select: userMiniSelect } }, orderBy: { createdAt: "desc" } },
      watchers: { include: { user: { select: userMiniSelect } } },
      linksOut: { include: { to: { select: linkedSelect } }, orderBy: { createdAt: "asc" } },
      linksIn: { include: { from: { select: linkedSelect } }, orderBy: { createdAt: "asc" } },
    },
  });
  if (!issue) return null;

  const projectId = issue.projectId;
  const [memberRows, sprints, epics, labelRows, canManage] = await Promise.all([
    db.projectMember.findMany({
      where: { projectId, user: { active: true } },
      select: { user: { select: userMiniSelect } },
      orderBy: { user: { name: "asc" } },
    }),
    db.sprint.findMany({
      where: { projectId, state: { not: "COMPLETED" } },
      select: { id: true, name: true, state: true },
      orderBy: [{ state: "asc" }, { createdAt: "asc" }],
    }),
    db.issue.findMany({
      where: { projectId, type: "EPIC", id: { not: issue.id } },
      select: { id: true, key: true, title: true },
      orderBy: { number: "asc" },
    }),
    db.issue.findMany({ where: { projectId, labels: { not: "" } }, select: { labels: true } }),
    isProjectAdmin(projectId, user),
  ]);

  const members = memberRows.map((m) => m.user);
  // köhnə icraçı/müəllif artıq üzv deyilsə də seçimlərdə görünsün
  for (const u of [issue.assignee, issue.reporter]) {
    if (u && !members.some((m) => m.id === u.id)) members.push(u);
  }

  const labels = Array.from(new Set(labelRows.flatMap((r) => parseLabels(r.labels)))).sort((a, b) => a.localeCompare(b, "az"));

  const links = [
    ...issue.linksOut.map((l) => ({ id: l.id, type: l.type, direction: "out" as const, issue: l.to })),
    ...issue.linksIn.map((l) => ({ id: l.id, type: l.type, direction: "in" as const, issue: l.from })),
  ];

  const { linksOut: _o, linksIn: _i, ...rest } = issue;

  return {
    issue: { ...rest, links },
    options: { members, sprints, epics, labels },
    me: {
      id: user.id,
      user: { id: user.id, name: user.name, avatarColor: user.avatarColor },
      isAdmin: user.role === "ADMIN",
      canManage,
      canDelete: canManage || issue.reporterId === user.id,
      watching: issue.watchers.some((w) => w.userId === user.id),
    },
  };
}

export type IssueDetailData = NonNullable<Awaited<ReturnType<typeof loadIssueDetail>>>;
export type IssueDetailIssue = IssueDetailData["issue"];
