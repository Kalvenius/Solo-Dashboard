import "server-only";
import { addDays, endOfDay, format, startOfDay, startOfWeek, subDays, subWeeks, differenceInCalendarDays } from "date-fns";
import { getLocale, getT } from "@/i18n/server";
import { makeFormatters, type Formatters } from "@/i18n/fmt";
import { db } from "./db";
import type { CurrentUser } from "./auth";
import { accessibleProjectIds } from "./access";
import { ISSUE_TYPES, PRIORITIES, STATUSES, type IssueType, type Priority, type Status } from "./constants";
import { OTHER_COLOR, SERIES_COLORS } from "@/components/charts/theme";

/* =============================================================================
 * ƏMƏKDAŞ METRİKLƏRİ — TƏRİFLƏR
 * İstifadəçi U və dövr [from, to) üçün (həmçinin eyni uzunluqda əvvəlki dövr, ▲/▼ müqayisə üçün):
 *  - completed     : icraçısı U olan, status DONE, resolvedAt dövr daxilində, növü EPIC olmayan tapşırıqlar
 *  - points        : completed tapşırıqların storyPoints cəmi
 *  - minutes       : U-nun WorkLog qeydləri (startedAt dövr daxilində) — dəqiqə cəmi
 *  - open          : U-ya təyin edilmiş, status DONE olmayan, EPIC olmayan (cari vəziyyət; tarixi müqayisə yoxdur)
 *                    todo / inProgress / inReview — open-un statuslara bölgüsü
 *  - overdue       : open tapşırıqlardan dueDate < bu günün başlanğıcı
 *  - onTimeRate    : son tarixi olan completed tapşırıqlardan resolvedAt <= son tarix gününün sonu olanların faizi
 *  - avgCycleDays  : completed üçün (resolvedAt − ilk "status → IN_PROGRESS" anı; yoxdursa createdAt) orta gün
 *  - bugsFixed     : completed içində növü BUG olanlar
 *  - comments      : dövrdə U-nun yazdığı şərhlər
 *  - lastActive    : U-nun Activity / Comment / WorkLog qeydlərinin ən sonuncusu (yoxdursa lastSeenAt)
 * Komanda göstəriciləri = cədvəldəki şəxslərin cəmi (təyin edilməmiş tapşırıqlar daxil deyil);
 * komanda üzrə avgCycleDays və onTimeRate bütün tapşırıqlar üzrə hesablanır (ortaların ortası deyil).
 * Bütün sorğular izləyicinin görə bildiyi layihələrlə (və seçilmiş layihə filtri ilə) məhdudlaşır.
 * ========================================================================== */

export const PERIOD_OPTIONS = [7, 14, 30, 90] as const;
export const WEEKS = 12;
export const HEATMAP_WEEKS = 26;

export function parsePeriod(v: string | string[] | undefined): number {
  const n = Number(Array.isArray(v) ? v[0] : v);
  return (PERIOD_OPTIONS as readonly number[]).includes(n) ? n : 30;
}

export type DateRange = { from: Date; to: Date };

/** Cari dövr: bu gün daxil olmaqla son N gün. Əvvəlki dövr: ondan əvvəlki N gün. `to` daxil deyil. */
export function periodRanges(days: number, now = new Date()) {
  const from = startOfDay(subDays(now, days - 1));
  const current: DateRange = { from, to: endOfDay(now) };
  const previous: DateRange = { from: subDays(from, days), to: from };
  return { current, previous };
}

const inRange = (d: Date | null | undefined, r: DateRange) => !!d && d >= r.from && d < r.to;
const DAY_MS = 86_400_000;

/* ---------------------------- Əhatə dairəsi ---------------------------- */

export type ScopeProject = { id: string; key: string; name: string; color: string };
export type MetricsScope = {
  /** null = bütün layihələr (admin, filtr yoxdur) */
  projectIds: string[] | null;
  projects: ScopeProject[];
  selected: ScopeProject | null;
};

export async function resolveScope(viewer: CurrentUser, projectKey?: string | string[]): Promise<MetricsScope> {
  const ids = await accessibleProjectIds(viewer);
  const projects = await db.project.findMany({
    where: ids === null ? {} : { id: { in: ids } },
    select: { id: true, key: true, name: true, color: true },
    orderBy: { name: "asc" },
  });
  const key = (Array.isArray(projectKey) ? projectKey[0] : projectKey)?.toUpperCase();
  const selected = key ? (projects.find((p) => p.key === key) ?? null) : null;
  return { projectIds: selected ? [selected.id] : ids, projects, selected };
}

const projectWhere = (s: MetricsScope) => (s.projectIds === null ? {} : { projectId: { in: s.projectIds } });
const issueRel = (s: MetricsScope) => (s.projectIds === null ? {} : { issue: { projectId: { in: s.projectIds } } });

/* ----------------------------- Xam məlumat ----------------------------- */

type CompletedRow = {
  id: string;
  assigneeId: string;
  type: string;
  storyPoints: number | null;
  resolvedAt: Date;
  dueDate: Date | null;
  createdAt: Date;
  projectId: string;
  firstProgressAt: Date | null;
};
type OpenRow = { assigneeId: string; status: string; dueDate: Date | null };
type WorklogRow = { userId: string; minutes: number; startedAt: Date };
type CommentRow = { authorId: string; createdAt: Date };
type Raw = { completed: CompletedRow[]; open: OpenRow[]; worklogs: WorklogRow[]; comments: CommentRow[] };

async function fetchRaw(scope: MetricsScope, since: Date, userIds?: string[]): Promise<Raw> {
  const who = userIds ? { in: userIds } : { not: null };
  const [completedRaw, openRaw, worklogs, comments] = await Promise.all([
    db.issue.findMany({
      where: { ...projectWhere(scope), status: "DONE", type: { not: "EPIC" }, resolvedAt: { gte: since }, assigneeId: who },
      select: { id: true, assigneeId: true, type: true, storyPoints: true, resolvedAt: true, dueDate: true, createdAt: true, projectId: true },
    }),
    db.issue.findMany({
      where: { ...projectWhere(scope), status: { not: "DONE" }, type: { not: "EPIC" }, assigneeId: who },
      select: { assigneeId: true, status: true, dueDate: true },
    }),
    db.workLog.findMany({
      where: { ...issueRel(scope), startedAt: { gte: since }, ...(userIds ? { userId: { in: userIds } } : {}) },
      select: { userId: true, minutes: true, startedAt: true },
    }),
    db.comment.findMany({
      where: { ...issueRel(scope), createdAt: { gte: since }, ...(userIds ? { authorId: { in: userIds } } : {}) },
      select: { authorId: true, createdAt: true },
    }),
  ]);

  // Dövr müddəti üçün: hər tapşırığın ilk "İcrada" keçidi
  const firstProgress = new Map<string, Date>();
  const ids = completedRaw.map((i) => i.id);
  for (let i = 0; i < ids.length; i += 500) {
    const acts = await db.activity.findMany({
      where: { issueId: { in: ids.slice(i, i + 500) }, field: "status", toValue: "IN_PROGRESS" },
      select: { issueId: true, createdAt: true },
      orderBy: { createdAt: "asc" },
    });
    for (const a of acts) if (!firstProgress.has(a.issueId)) firstProgress.set(a.issueId, a.createdAt);
  }

  return {
    completed: completedRaw.map((i) => ({
      ...i,
      assigneeId: i.assigneeId!,
      resolvedAt: i.resolvedAt!,
      firstProgressAt: firstProgress.get(i.id) ?? null,
    })),
    open: openRaw.map((o) => ({ ...o, assigneeId: o.assigneeId! })),
    worklogs,
    comments,
  };
}

/* ------------------------------ Hesablama ------------------------------ */

export type PersonMetrics = {
  completed: number;
  points: number;
  minutes: number;
  open: number;
  todo: number;
  inProgress: number;
  inReview: number;
  overdue: number;
  onTimeRate: number | null;
  avgCycleDays: number | null;
  bugsFixed: number;
  comments: number;
  /** komanda üzrə orta hesablamaq üçün */
  cycleSumDays: number;
  cycleCount: number;
  dueCount: number;
  onTimeCount: number;
};

const cycleDays = (c: CompletedRow) => {
  const start = c.firstProgressAt && c.firstProgressAt <= c.resolvedAt ? c.firstProgressAt : c.createdAt;
  return Math.max(0, (c.resolvedAt.getTime() - start.getTime()) / DAY_MS);
};

function computeMetrics(raw: Raw, range: DateRange, opts: { includeSnapshot: boolean; now: Date }): PersonMetrics {
  const done = raw.completed.filter((c) => inRange(c.resolvedAt, range));
  const withDue = done.filter((c) => c.dueDate);
  const onTime = withDue.filter((c) => c.resolvedAt <= endOfDay(c.dueDate!)).length;
  const cycleSum = done.reduce((s, c) => s + cycleDays(c), 0);
  const today = startOfDay(opts.now);
  const open = opts.includeSnapshot ? raw.open : [];
  return {
    completed: done.length,
    points: done.reduce((s, c) => s + (c.storyPoints ?? 0), 0),
    minutes: raw.worklogs.filter((w) => inRange(w.startedAt, range)).reduce((s, w) => s + w.minutes, 0),
    open: open.length,
    todo: open.filter((o) => o.status === "TODO").length,
    inProgress: open.filter((o) => o.status === "IN_PROGRESS").length,
    inReview: open.filter((o) => o.status === "IN_REVIEW").length,
    overdue: open.filter((o) => o.dueDate && o.dueDate < today).length,
    onTimeRate: withDue.length ? Math.round((onTime / withDue.length) * 100) : null,
    avgCycleDays: done.length ? Math.round((cycleSum / done.length) * 10) / 10 : null,
    bugsFixed: done.filter((c) => c.type === "BUG").length,
    comments: raw.comments.filter((c) => inRange(c.createdAt, range)).length,
    cycleSumDays: cycleSum,
    cycleCount: done.length,
    dueCount: withDue.length,
    onTimeCount: onTime,
  };
}

function sumMetrics(list: PersonMetrics[]): PersonMetrics {
  const t = list.reduce(
    (a, m) => {
      a.completed += m.completed;
      a.points += m.points;
      a.minutes += m.minutes;
      a.open += m.open;
      a.todo += m.todo;
      a.inProgress += m.inProgress;
      a.inReview += m.inReview;
      a.overdue += m.overdue;
      a.bugsFixed += m.bugsFixed;
      a.comments += m.comments;
      a.cycleSumDays += m.cycleSumDays;
      a.cycleCount += m.cycleCount;
      a.dueCount += m.dueCount;
      a.onTimeCount += m.onTimeCount;
      return a;
    },
    { completed: 0, points: 0, minutes: 0, open: 0, todo: 0, inProgress: 0, inReview: 0, overdue: 0, bugsFixed: 0, comments: 0, cycleSumDays: 0, cycleCount: 0, dueCount: 0, onTimeCount: 0 },
  );
  return {
    ...t,
    onTimeRate: t.dueCount ? Math.round((t.onTimeCount / t.dueCount) * 100) : null,
    avgCycleDays: t.cycleCount ? Math.round((t.cycleSumDays / t.cycleCount) * 10) / 10 : null,
  };
}

function splitRaw(raw: Raw, userId: string): Raw {
  return {
    completed: raw.completed.filter((c) => c.assigneeId === userId),
    open: raw.open.filter((o) => o.assigneeId === userId),
    worklogs: raw.worklogs.filter((w) => w.userId === userId),
    comments: raw.comments.filter((c) => c.authorId === userId),
  };
}

/* ---------------------------- Həftəlik sıra ---------------------------- */

export type WeekBucket = { start: Date; label: string; range: DateRange };

/** Həftə etiketləri dilə uyğun formatlanır (f = makeFormatters(locale)) */
export function lastWeeks(f: Formatters, n = WEEKS, now = new Date()): WeekBucket[] {
  const thisWeek = startOfWeek(now, { weekStartsOn: 1 });
  return Array.from({ length: n }, (_, i) => {
    const start = subWeeks(thisWeek, n - 1 - i);
    return { start, label: f.dateShort(start), range: { from: start, to: addDays(start, 7) } };
  });
}

type WeeklyPoint = { completed: number; points: number; minutes: number };

function weekly(raw: Raw, weeks: WeekBucket[]): WeeklyPoint[] {
  return weeks.map((w) => {
    const done = raw.completed.filter((c) => inRange(c.resolvedAt, w.range));
    return {
      completed: done.length,
      points: done.reduce((s, c) => s + (c.storyPoints ?? 0), 0),
      minutes: raw.worklogs.filter((l) => inRange(l.startedAt, w.range)).reduce((s, l) => s + l.minutes, 0),
    };
  });
}

/* ------------------------------ Rəng xəritəsi ------------------------------ */

/**
 * Şəxslərin seriya rəngi: yoxlanılmış kateqorial palitra (charts/theme.ts). Rəng şəxsə bağlıdır (sabit sıra: createdAt),
 * reytinqə yox — filtr dəyişəndə rənglər dəyişmir. 8-dən çox şəxs olarsa 8-ci slot "Digərləri" (boz) olur.
 */
export const OTHER_KEY = "__other";

function colorMap(people: { id: string; createdAt: Date }[]) {
  const sorted = [...people].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime() || a.id.localeCompare(b.id));
  const map = new Map<string, string>();
  const limit = sorted.length > SERIES_COLORS.length ? SERIES_COLORS.length - 1 : SERIES_COLORS.length;
  sorted.forEach((p, i) => map.set(p.id, i < limit ? SERIES_COLORS[i]! : OTHER_COLOR));
  return map;
}

/* ============================ KOMANDA DASHBOARDU ============================ */

export type TeamPersonRow = {
  id: string;
  name: string;
  title: string | null;
  avatarColor: string;
  active: boolean;
  color: string;
  current: PersonMetrics;
  previous: PersonMetrics;
  weeklyCompleted: number[];
  lastActive: string | null;
};

export async function getTeamDashboard(viewer: CurrentUser, opts: { days: number; projectKey?: string | string[] }) {
  const now = new Date();
  const f = makeFormatters(await getLocale());
  const tp = await getT("people");
  const scope = await resolveScope(viewer, opts.projectKey);
  const { current, previous } = periodRanges(opts.days, now);
  const weeks = lastWeeks(f, WEEKS, now);
  const since = new Date(Math.min(previous.from.getTime(), weeks[0]!.start.getTime()));

  const raw = await fetchRaw(scope, since);

  // Komanda: əhatə edilən layihələrin üzvləri + məlumatı olan hər kəs
  const memberIds =
    scope.projectIds === null
      ? null
      : (await db.projectMember.findMany({ where: { projectId: { in: scope.projectIds } }, select: { userId: true } })).map((m) => m.userId);
  const dataIds = new Set<string>([
    ...raw.completed.map((c) => c.assigneeId),
    ...raw.open.map((o) => o.assigneeId),
    ...raw.worklogs.map((w) => w.userId),
  ]);
  const users = await db.user.findMany({
    where: memberIds === null ? {} : { id: { in: Array.from(new Set([...memberIds, ...dataIds])) } },
    select: { id: true, name: true, title: true, avatarColor: true, active: true, createdAt: true, lastSeenAt: true },
  });

  const lastActive = await lastActiveMap(scope, users.map((u) => u.id));
  const colors = colorMap(users);

  const rows: TeamPersonRow[] = users
    .map((u) => {
      const r = splitRaw(raw, u.id);
      return {
        id: u.id,
        name: u.name,
        title: u.title,
        avatarColor: u.avatarColor,
        active: u.active,
        color: colors.get(u.id)!,
        current: computeMetrics(r, current, { includeSnapshot: true, now }),
        previous: computeMetrics(r, previous, { includeSnapshot: false, now }),
        weeklyCompleted: weekly(r, weeks).map((w) => w.completed),
        lastActive: (lastActive.get(u.id) ?? u.lastSeenAt)?.toISOString() ?? null,
        _hasData: dataIds.has(u.id),
      };
    })
    .filter((r) => r.active || r._hasData)
    .map(({ _hasData: _h, ...r }) => r)
    .sort((a, b) => b.current.completed - a.current.completed || a.name.localeCompare(b.name, "az"));

  const team = { current: sumMetrics(rows.map((r) => r.current)), previous: sumMetrics(rows.map((r) => r.previous)) };
  const teamWeekly = weekly(raw, weeks).map((w) => w.completed);

  // Həftəlik tamamlanan — şəxslər üzrə yığılmış sütunlar
  const seriesPeople = rows.filter((r) => r.weeklyCompleted.some((v) => v > 0));
  const folded = seriesPeople.filter((r) => r.color === OTHER_COLOR);
  const weeklyStack = weeks.map((w, i) => {
    const point: Record<string, number | string> = { label: w.label };
    for (const p of seriesPeople) {
      const key = p.color === OTHER_COLOR ? OTHER_KEY : p.id;
      point[key] = ((point[key] as number | undefined) ?? 0) + p.weeklyCompleted[i]!;
    }
    return point;
  });
  const weeklySeries = [
    ...seriesPeople
      .filter((p) => p.color !== OTHER_COLOR)
      .sort((a, b) => SERIES_COLORS.indexOf(a.color) - SERIES_COLORS.indexOf(b.color))
      .map((p) => ({ key: p.id, name: p.name, color: p.color })),
    ...(folded.length ? [{ key: OTHER_KEY, name: tp("othersCount", { n: folded.length }), color: OTHER_COLOR }] : []),
  ];

  return {
    scope,
    days: opts.days,
    range: { from: current.from.toISOString(), to: now.toISOString() },
    rows,
    team,
    teamWeekly,
    weekLabels: weeks.map((w) => w.label),
    weeklyStack,
    weeklySeries,
  };
}

async function lastActiveMap(scope: MetricsScope, userIds: string[]) {
  if (!userIds.length) return new Map<string, Date>();
  const notFuture = { createdAt: { lte: new Date() } }; // gələcək tarixli qeydlər (məs. səhv idxal) nəzərə alınmır
  const [acts, logs, coms] = await Promise.all([
    db.activity.groupBy({ by: ["actorId"], where: { actorId: { in: userIds }, ...notFuture, ...issueRel(scope) }, _max: { createdAt: true } }),
    db.workLog.groupBy({ by: ["userId"], where: { userId: { in: userIds }, ...notFuture, ...issueRel(scope) }, _max: { createdAt: true } }),
    db.comment.groupBy({ by: ["authorId"], where: { authorId: { in: userIds }, ...notFuture, ...issueRel(scope) }, _max: { createdAt: true } }),
  ]);
  const map = new Map<string, Date>();
  const put = (id: string, d: Date | null) => {
    if (!d) return;
    const prev = map.get(id);
    if (!prev || d > prev) map.set(id, d);
  };
  acts.forEach((a) => put(a.actorId, a._max.createdAt));
  logs.forEach((a) => put(a.userId, a._max.createdAt));
  coms.forEach((a) => put(a.authorId, a._max.createdAt));
  return map;
}

/* ============================ ƏMƏKDAŞ DASHBOARDU ============================ */

export async function getEmployeeDashboard(viewer: CurrentUser, userId: string, opts: { days: number; projectKey?: string | string[] }) {
  const person = await db.user.findUnique({
    where: { id: userId },
    select: {
      id: true, name: true, email: true, title: true, department: true, role: true, avatarColor: true, active: true,
      createdAt: true, lastSeenAt: true,
      memberships: { select: { role: true, project: { select: { id: true, key: true, name: true, color: true } } } },
    },
  });
  if (!person) return null;

  const now = new Date();
  const scope = await resolveScope(viewer, opts.projectKey);
  const { current, previous } = periodRanges(opts.days, now);
  const weeks = lastWeeks(makeFormatters(await getLocale()), WEEKS, now);
  const since = new Date(Math.min(previous.from.getTime(), weeks[0]!.start.getTime()));
  const raw = await fetchRaw(scope, since, [userId]);

  const metrics = {
    current: computeMetrics(raw, current, { includeSnapshot: true, now }),
    previous: computeMetrics(raw, previous, { includeSnapshot: false, now }),
  };
  const weeklySeries = weekly(raw, weeks).map((w, i) => ({ label: weeks[i]!.label, completed: w.completed, points: w.points, hours: Math.round((w.minutes / 60) * 10) / 10 }));

  // Növ və layihə bölgüsü (cari dövrdə tamamlananlar)
  const doneNow = raw.completed.filter((c) => inRange(c.resolvedAt, current));
  const byType = ISSUE_TYPES.filter((t) => t !== "EPIC")
    .map((t) => ({ type: t as IssueType, count: doneNow.filter((c) => c.type === t).length }))
    .filter((x) => x.count > 0)
    .sort((a, b) => b.count - a.count);
  const projMap = new Map(scope.projects.map((p) => [p.id, p]));
  const byProjectCounts = new Map<string, number>();
  doneNow.forEach((c) => byProjectCounts.set(c.projectId, (byProjectCounts.get(c.projectId) ?? 0) + 1));
  const byProject = Array.from(byProjectCounts.entries())
    .map(([id, count]) => ({ project: projMap.get(id)!, count }))
    .filter((x) => x.project)
    .sort((a, b) => b.count - a.count);

  // Aktivlik xəritəsi: Activity (LOGGED_WORK xaric — onlar WorkLog kimi sayılır) + WorkLog, gün üzrə
  const heatStart = startOfWeek(subWeeks(now, HEATMAP_WEEKS - 1), { weekStartsOn: 1 });
  const [heatActs, heatLogs, openIssues, recentActivity, recentLogs] = await Promise.all([
    db.activity.findMany({ where: { actorId: userId, createdAt: { gte: heatStart }, action: { not: "LOGGED_WORK" }, ...issueRel(scope) }, select: { createdAt: true } }),
    db.workLog.findMany({ where: { userId, startedAt: { gte: heatStart }, ...issueRel(scope) }, select: { startedAt: true } }),
    db.issue.findMany({
      where: { ...projectWhere(scope), assigneeId: userId, status: { not: "DONE" }, type: { not: "EPIC" } },
      select: { id: true, key: true, title: true, type: true, status: true, priority: true, dueDate: true, project: { select: { key: true, name: true, color: true } } },
    }),
    db.activity.findMany({
      where: { actorId: userId, createdAt: { lte: now }, ...issueRel(scope) },
      orderBy: { createdAt: "desc" },
      take: 25,
      select: { id: true, action: true, field: true, fromValue: true, toValue: true, createdAt: true, issue: { select: { key: true, title: true } } },
    }),
    db.workLog.findMany({
      where: { userId, ...issueRel(scope) },
      orderBy: { startedAt: "desc" },
      take: 20,
      select: { id: true, minutes: true, startedAt: true, note: true, issue: { select: { key: true, title: true, type: true } } },
    }),
  ]);
  const heat: Record<string, number> = {};
  const dayKey = (d: Date) => format(d, "yyyy-MM-dd");
  heatActs.forEach((a) => (heat[dayKey(a.createdAt)] = (heat[dayKey(a.createdAt)] ?? 0) + 1));
  heatLogs.forEach((a) => (heat[dayKey(a.startedAt)] = (heat[dayKey(a.startedAt)] ?? 0) + 1));

  const priorityWeight = (p: string) => PRIORITIES.length - PRIORITIES.indexOf(p as Priority);
  const today = startOfDay(now);
  const open = openIssues
    .map((i) => ({ ...i, overdue: !!i.dueDate && i.dueDate < today }))
    .sort(
      (a, b) =>
        Number(b.overdue) - Number(a.overdue) ||
        priorityWeight(b.priority) - priorityWeight(a.priority) ||
        (a.dueDate?.getTime() ?? Infinity) - (b.dueDate?.getTime() ?? Infinity),
    );
  const openByStatus = STATUSES.filter((s) => s !== "DONE").map((s) => ({ status: s as Status, issues: open.filter((i) => i.status === s) }));

  const lastActive = (await lastActiveMap(scope, [userId])).get(userId) ?? person.lastSeenAt;

  return {
    person,
    scope,
    days: opts.days,
    metrics,
    weeklySeries,
    byType,
    byProject,
    heat,
    heatStart: heatStart.toISOString(),
    openByStatus,
    recentActivity,
    recentLogs,
    lastActive: lastActive?.toISOString() ?? null,
  };
}

/* ============================== LAYİHƏ HESABATLARI ============================== */

export async function getProjectReports(project: { id: string; type: string }, sprintParam?: string | string[]) {
  const now = new Date();
  const f = makeFormatters(await getLocale());
  const tc = await getT("common");
  const [issues, statusActs, sprints] = await Promise.all([
    db.issue.findMany({
      where: { projectId: project.id, type: { not: "EPIC" } },
      select: {
        id: true, type: true, status: true, priority: true, storyPoints: true, sprintId: true, createdAt: true, resolvedAt: true,
        assignee: { select: { id: true, name: true, avatarColor: true } },
      },
    }),
    db.activity.findMany({
      where: { issue: { projectId: project.id, type: { not: "EPIC" } }, field: "status" },
      select: { issueId: true, fromValue: true, toValue: true, createdAt: true },
      orderBy: { createdAt: "asc" },
    }),
    project.type === "SCRUM"
      ? db.sprint.findMany({ where: { projectId: project.id, state: { not: "PLANNED" } }, orderBy: [{ startDate: "desc" }, { createdAt: "desc" }] })
      : Promise.resolve([]),
  ]);

  // Son 30 gün
  const days30 = Array.from({ length: 30 }, (_, i) => startOfDay(subDays(now, 29 - i)));
  const dayLabel = (d: Date) => f.dateShort(d);

  const createdResolved = days30.map((d) => {
    const r = { from: d, to: addDays(d, 1) };
    return {
      label: dayLabel(d),
      created: issues.filter((i) => inRange(i.createdAt, r)).length,
      resolved: issues.filter((i) => i.status === "DONE" && inRange(i.resolvedAt, r)).length,
    };
  });

  // Kumulyativ axın: hər günün sonunda hər statusda neçə tapşırıq var
  const transitions = new Map<string, { at: Date; from: string | null; to: string | null }[]>();
  statusActs.forEach((a) => {
    const list = transitions.get(a.issueId) ?? [];
    list.push({ at: a.createdAt, from: a.fromValue, to: a.toValue });
    transitions.set(a.issueId, list);
  });
  const statusAt = (issue: (typeof issues)[number], at: Date): string | null => {
    if (issue.createdAt > at) return null;
    const t = transitions.get(issue.id);
    if (!t?.length) return issue.status;
    let s = t[0]!.from ?? "TODO";
    for (const x of t) {
      if (x.at <= at) s = x.to ?? s;
      else break;
    }
    return s;
  };
  const cfd =
    project.type === "KANBAN"
      ? days30.map((d) => {
          const end = endOfDay(d);
          const point: Record<string, number | string> = { label: dayLabel(d), TODO: 0, IN_PROGRESS: 0, IN_REVIEW: 0, DONE: 0 };
          for (const i of issues) {
            const s = statusAt(i, end > now ? now : end);
            if (s && s in point) (point[s] as number)++;
          }
          return point;
        })
      : null;

  // Bölgülər (cari vəziyyət)
  const byStatus = STATUSES.map((s) => ({ key: s as Status, count: issues.filter((i) => i.status === s).length }));
  const byType = ISSUE_TYPES.filter((t) => t !== "EPIC").map((t) => ({ key: t as IssueType, count: issues.filter((i) => i.type === t).length }));
  const byPriority = PRIORITIES.map((p) => ({ key: p as Priority, count: issues.filter((i) => i.priority === p).length }));

  // İcraçılar üzrə açıq iş yükü
  const loadMap = new Map<string, { id: string | null; name: string; avatarColor: string | null; todo: number; inProgress: number; inReview: number }>();
  for (const i of issues) {
    if (i.status === "DONE") continue;
    const k = i.assignee?.id ?? "__none__";
    const row = loadMap.get(k) ?? { id: i.assignee?.id ?? null, name: i.assignee?.name ?? tc("unassigned"), avatarColor: i.assignee?.avatarColor ?? null, todo: 0, inProgress: 0, inReview: 0 };
    if (i.status === "TODO") row.todo++;
    else if (i.status === "IN_PROGRESS") row.inProgress++;
    else if (i.status === "IN_REVIEW") row.inReview++;
    loadMap.set(k, row);
  }
  const workload = Array.from(loadMap.values()).sort((a, b) => b.todo + b.inProgress + b.inReview - (a.todo + a.inProgress + a.inReview));

  // Scrum: burndown + velocity
  let burndown: null | {
    sprint: { id: string; name: string; state: string; goal: string | null; startDate: string; endDate: string };
    unit: "points" | "count";
    total: number;
    done: number;
    daysLeft: number;
    points: { label: string; ideal: number; remaining: number | null }[];
  } = null;
  let velocity: { name: string; committed: number; completed: number }[] = [];

  if (project.type === "SCRUM") {
    const sprintId = Array.isArray(sprintParam) ? sprintParam[0] : sprintParam;
    const chosen = sprints.find((s) => s.id === sprintId) ?? sprints.find((s) => s.state === "ACTIVE") ?? sprints.find((s) => s.state === "COMPLETED");
    if (chosen?.startDate) {
      const start = startOfDay(chosen.startDate);
      const end = startOfDay(chosen.endDate ?? addDays(chosen.startDate, 14));
      // Sprintdə olan + sprint başlayandan sonra sprintdən çıxarılan tapşırıqlar (tarixçədə sprint adı ilə)
      const movedOut = await db.activity.findMany({
        where: { issue: { projectId: project.id }, field: "sprint", fromValue: chosen.name, createdAt: { gte: chosen.startDate } },
        select: { issueId: true },
      });
      const movedIds = new Set(movedOut.map((m) => m.issueId));
      const scopeIssues = issues.filter((i) => i.type !== "SUBTASK" && (i.sprintId === chosen.id || movedIds.has(i.id)));
      const totalPoints = scopeIssues.reduce((s, i) => s + (i.storyPoints ?? 0), 0);
      const unit: "points" | "count" = totalPoints > 0 ? "points" : "count";
      const weight = (i: (typeof scopeIssues)[number]) => (unit === "points" ? (i.storyPoints ?? 0) : 1);
      const total = scopeIssues.reduce((s, i) => s + weight(i), 0);
      const burned = scopeIssues.filter((i) => i.sprintId === chosen.id && i.status === "DONE" && i.resolvedAt);
      const nDays = Math.max(1, Math.round((end.getTime() - start.getTime()) / DAY_MS));
      const points = Array.from({ length: nDays + 1 }, (_, k) => {
        const d = addDays(start, k);
        const dEnd = endOfDay(d);
        const future = d > now;
        const doneBy = burned.filter((i) => i.resolvedAt! <= dEnd).reduce((s, i) => s + weight(i), 0);
        return { label: dayLabel(d), ideal: Math.round((total - (total * k) / nDays) * 10) / 10, remaining: future ? null : total - doneBy };
      });
      const doneTotal = burned.reduce((s, i) => s + weight(i), 0);
      burndown = {
        sprint: { id: chosen.id, name: chosen.name, state: chosen.state, goal: chosen.goal, startDate: start.toISOString(), endDate: end.toISOString() },
        unit,
        total,
        done: doneTotal,
        daysLeft: chosen.state === "ACTIVE" ? Math.max(0, differenceInCalendarDays(end, now)) : 0,
        points,
      };
    }

    const completedSprints = sprints
      .filter((s) => s.state === "COMPLETED")
      .sort((a, b) => (a.completedAt?.getTime() ?? 0) - (b.completedAt?.getTime() ?? 0))
      .slice(-6);
    velocity = completedSprints.map((s) => {
      const inSprint = issues.filter((i) => i.sprintId === s.id && i.type !== "SUBTASK");
      const completed = s.completedPoints ?? inSprint.filter((i) => i.status === "DONE").reduce((a, i) => a + (i.storyPoints ?? 0), 0);
      return { name: s.name, committed: s.committedPoints ?? inSprint.reduce((a, i) => a + (i.storyPoints ?? 0), 0), completed };
    });
  }

  return {
    totals: { all: issues.length, open: issues.filter((i) => i.status !== "DONE").length, done: issues.filter((i) => i.status === "DONE").length },
    createdResolved,
    cfd,
    byStatus,
    byType,
    byPriority,
    workload,
    sprints: sprints.map((s) => ({ id: s.id, name: s.name, state: s.state })),
    burndown,
    velocity,
  };
}

/* =================================== ZAMAN XƏTTİ =================================== */

export async function getTimeline(projectId: string) {
  const epics = await db.issue.findMany({
    where: { projectId, type: "EPIC" },
    orderBy: [{ startDate: "asc" }, { rank: "asc" }],
    select: {
      id: true, key: true, title: true, status: true, startDate: true, dueDate: true, createdAt: true,
      assignee: { select: { id: true, name: true, avatarColor: true } },
      children: {
        where: { type: { not: "SUBTASK" } },
        orderBy: { rank: "asc" },
        select: {
          id: true, key: true, title: true, type: true, status: true, startDate: true, dueDate: true, createdAt: true,
          assignee: { select: { id: true, name: true, avatarColor: true } },
        },
      },
    },
  });
  const iso = (d: Date | null) => d?.toISOString() ?? null;
  return epics.map((e) => ({
    id: e.id,
    key: e.key,
    title: e.title,
    status: e.status,
    startDate: iso(e.startDate),
    dueDate: iso(e.dueDate),
    createdAt: e.createdAt.toISOString(),
    assignee: e.assignee,
    progress: e.children.length ? Math.round((e.children.filter((c) => c.status === "DONE").length / e.children.length) * 100) : e.status === "DONE" ? 100 : 0,
    doneCount: e.children.filter((c) => c.status === "DONE").length,
    children: e.children.map((c) => ({
      id: c.id,
      key: c.key,
      title: c.title,
      type: c.type,
      status: c.status,
      startDate: iso(c.startDate),
      dueDate: iso(c.dueDate),
      createdAt: c.createdAt.toISOString(),
      assignee: c.assignee,
    })),
  }));
}

export type TimelineEpic = Awaited<ReturnType<typeof getTimeline>>[number];
