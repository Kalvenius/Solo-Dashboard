import { AppError } from "./errors";

export type ActionResult<T = undefined> = { ok: true; data?: T } | { ok: false; error: string };

export const ok = <T,>(data?: T): ActionResult<T> => ({ ok: true, data });
export const fail = (error: string): ActionResult<never> => ({ ok: false, error });

/**
 * Server action-ları try/catch ilə bükür ki, xəta istifadəçiyə mesaj kimi qayıtsın.
 * Xəta mesajı tərcümə açarıdırsa ("titleRequired", "backlog.errSprintEmpty"), istifadəçinin dilinə çevrilir.
 */
export async function safe<T>(fn: () => Promise<T>): Promise<ActionResult<T>> {
  try {
    return { ok: true, data: await fn() };
  } catch (e) {
    if ((e as { digest?: string })?.digest?.startsWith("NEXT_REDIRECT") || (e as Error)?.message === "NEXT_REDIRECT") throw e;
    const { translateError } = await import("@/i18n/server");
    if (e instanceof AppError) return { ok: false, error: await translateError(e.message, e.params) };
    if (e instanceof Error) {
      const translated = await translateError(e.message);
      if (translated === e.message) console.error(e);
      return { ok: false, error: translated };
    }
    console.error(e);
    return { ok: false, error: await translateError("unknown") };
  }
}
