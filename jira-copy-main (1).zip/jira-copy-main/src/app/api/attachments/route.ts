import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { assertProjectAccess } from "@/lib/access";
import { logActivity } from "@/lib/activity";
import { getT } from "@/i18n/server";

const MAX_BYTES = 10 * 1024 * 1024;

/** Fayl yükləmə: multipart/form-data { issueId, file } — server action 2MB limitinə görə route handler istifadə olunur */
export async function POST(req: Request) {
  const t = await getT("issue");
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: t("errUnauthorized") }, { status: 401 });

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: t("errBadRequest") }, { status: 400 });
  }
  const issueId = form.get("issueId");
  const file = form.get("file");
  if (typeof issueId !== "string" || !(file instanceof File)) return NextResponse.json({ error: t("errNoFile") }, { status: 400 });
  if (file.size === 0) return NextResponse.json({ error: t("errEmptyFile") }, { status: 400 });
  if (file.size > MAX_BYTES) return NextResponse.json({ error: t("errFileTooLarge", { max: MAX_BYTES / 1024 / 1024 }) }, { status: 413 });

  const issue = await db.issue.findUnique({ where: { id: issueId }, select: { id: true, projectId: true } });
  if (!issue) return NextResponse.json({ error: (await getT("errors"))("issueNotFound") }, { status: 404 });
  try {
    await assertProjectAccess(issue.projectId, user);
  } catch {
    return NextResponse.json({ error: (await getT("errors"))("issueNotFound") }, { status: 404 });
  }

  const original = (file.name || "fayl").slice(0, 200);
  const safeName = original.replace(/[^\p{L}\p{N}._-]+/gu, "_").replace(/^\.+/, "") || "fayl";
  const storedName = `${randomUUID()}-${safeName}`;
  const dir = path.join(process.cwd(), "uploads");
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, storedName), Buffer.from(await file.arrayBuffer()));

  const att = await db.attachment.create({
    data: {
      issueId: issue.id,
      uploaderId: user.id,
      filename: original,
      mimeType: file.type || "application/octet-stream",
      size: file.size,
      storedName,
    },
  });
  await logActivity({ issueId: issue.id, actorId: user.id, action: "ATTACHED", toValue: original });
  return NextResponse.json({ id: att.id });
}
