import { readFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { assertProjectAccess } from "@/lib/access";
import { getT } from "@/i18n/server";

// Brauzerdə birbaşa göstərilə bilən təhlükəsiz növlər; qalanları endirilir
const INLINE = new Set(["image/png", "image/jpeg", "image/gif", "image/webp", "image/avif", "application/pdf", "text/plain"]);

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const t = await getT("issue");
  const user = await getCurrentUser();
  if (!user) return new Response(t("errUnauthorized"), { status: 401 });
  const { id } = await params;

  const att = await db.attachment.findUnique({ where: { id }, include: { issue: { select: { projectId: true } } } });
  if (!att) return new Response(t("errAttachmentNotFound"), { status: 404 });
  try {
    await assertProjectAccess(att.issue.projectId, user);
  } catch {
    return new Response(t("errAttachmentNotFound"), { status: 404 });
  }

  let data: Buffer;
  try {
    data = await readFile(path.join(process.cwd(), "uploads", path.basename(att.storedName)));
  } catch {
    return new Response(t("errFileMissing"), { status: 404 });
  }

  const inline = INLINE.has(att.mimeType);
  const encoded = encodeURIComponent(att.filename);
  return new Response(new Uint8Array(data), {
    headers: {
      "Content-Type": inline ? att.mimeType : "application/octet-stream",
      "Content-Length": String(data.length),
      "Content-Disposition": `${inline ? "inline" : "attachment"}; filename*=UTF-8''${encoded}`,
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
      "Cache-Control": "private, max-age=3600",
    },
  });
}
