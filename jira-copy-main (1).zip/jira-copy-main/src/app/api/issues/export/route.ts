import { NextResponse, type NextRequest } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getProjectForUser } from "@/lib/access";
import { buildIssueWhere, parseIssueFilters, queryIssues, type SearchParams } from "@/lib/issue-filters";
import { ISSUE_TYPES, PRIORITIES, STATUSES } from "@/lib/constants";
import { getLocale, getT } from "@/i18n/server";

// Tarixlər ISO formatında (yyyy-MM-dd) — Excel/Sheets onları hər dildə tarix kimi tanıyır
const d = (x: Date | null) => (x ? x.toISOString().slice(0, 10) : "");

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [t, te, terr, locale] = await Promise.all([getT("issueTable"), getT("enums"), getT("errors"), getLocale()]);
  // Excel AZ/RU regional parametrlərində siyahı ayırıcısı ";" olur, EN-də ","
  const sep = locale === "en" ? "," : ";";
  const cell = (v: unknown) => {
    const s = v == null ? "" : String(v);
    return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };

  const sp: SearchParams = Object.fromEntries(req.nextUrl.searchParams.entries());
  const f = parseIssueFilters(sp);
  const where = await buildIssueWhere(f, user);
  // tək layihə ixracında giriş yoxlaması
  if (f.project.length === 1 && !(await getProjectForUser(f.project[0]!, user))) {
    return NextResponse.json({ error: terr("projectNotFound") }, { status: 404 });
  }
  const { rows } = await queryIssues(where, f, { all: true });

  const label = <T extends string>(list: readonly T[], prefix: "type" | "status" | "priority", v: string) =>
    (list as readonly string[]).includes(v) ? te(`${prefix}.${v}` as Parameters<typeof te>[0]) : v;

  const header = [
    t("csvKey"), t("csvType"), t("csvTitle"), t("csvStatus"), t("csvPriority"), t("csvAssignee"), t("csvReporter"), t("csvProject"),
    t("csvSprint"), t("csvParent"), t("csvPoints"), t("csvLabels"), t("csvDue"), t("csvCreated"), t("csvUpdated"), t("csvResolved"),
  ];
  const lines = rows.map((r) =>
    [
      r.key,
      label(ISSUE_TYPES, "type", r.type),
      r.title,
      label(STATUSES, "status", r.status),
      label(PRIORITIES, "priority", r.priority),
      r.assignee?.name ?? "",
      r.reporter.name,
      r.project.name,
      r.sprint?.name ?? "",
      r.parent?.key ?? "",
      r.storyPoints ?? "",
      r.labels,
      d(r.dueDate),
      d(r.createdAt),
      d(r.updatedAt),
      d(r.resolvedAt),
    ]
      .map(cell)
      .join(sep),
  );
  const csv = "﻿" + [header.map(cell).join(sep), ...lines].join("\r\n");
  const base = t("csvFileName");
  const name = f.project.length === 1 ? `${f.project[0]}-${base}` : base;
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
