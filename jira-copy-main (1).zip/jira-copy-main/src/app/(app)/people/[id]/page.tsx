import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { CalendarDays, Clock, Mail } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { getEmployeeDashboard, parsePeriod, HEATMAP_WEEKS } from "@/lib/metrics";
import { getFormat, getT } from "@/i18n/server";
import { Avatar } from "@/components/ui/avatar";
import { Lozenge } from "@/components/ui/lozenge";
import { ProjectAvatar } from "@/components/ui/misc";
import { IssueTypeIcon } from "@/components/issue/icons";
import { IssueModalSlot } from "@/components/issue/issue-modal";
import { DashboardFrame } from "@/components/people/dashboard-frame";
import { OpenIssues } from "@/components/people/open-issues";
import { ActivityFeed } from "@/components/people/activity-feed";
import { WorklogTable } from "@/components/people/worklog-table";
import { KpiTile } from "@/components/charts/kpi-tile";
import { ChartCard } from "@/components/charts/chart-card";
import { ColumnChart } from "@/components/charts/column-chart";
import { RankedBars } from "@/components/charts/bars";
import { ActivityHeatmap } from "@/components/charts/heatmap";
import { ACCENT, minutesToHours } from "@/components/charts/theme";
import { ChartVars } from "@/components/charts/chart-vars";

type SP = Promise<Record<string, string | string[] | undefined>>;

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("people"))("employeeMetaTitle") };
}

export default async function EmployeePage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: SP }) {
  const viewer = await requireUser();
  const { id } = await params;
  const sp = await searchParams;

  // Üzv yalnız öz dashboardunu görür
  if (viewer.role !== "ADMIN" && id !== viewer.id) redirect(`/people/${viewer.id}`);

  const [t, te, tc, f] = await Promise.all([getT("people"), getT("enums"), getT("common"), getFormat()]);
  const fmtNum = (n: number, digits = 0) => f.num(n, digits);
  const fmtHours = (minutes: number) => f.num(minutesToHours(minutes), 1);
  const days = parsePeriod(sp.period);
  const data = await getEmployeeDashboard(viewer, id, { days, projectKey: sp.project });
  if (!data) notFound();
  const { person, metrics } = data;
  const m = metrics.current;
  const p = metrics.previous;
  const projectKey = data.scope.selected?.key ?? null;
  const isSelf = viewer.id === person.id;
  const visibleProjectIds = new Set(data.scope.projects.map((x) => x.id));
  const memberProjects = person.memberships.map((mm) => mm.project).filter((pr) => visibleProjectIds.has(pr.id));
  const typeTotal = data.byType.reduce((s, t) => s + t.count, 0);

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[1400px] px-8 py-6">
        <ChartVars />
        {viewer.role === "ADMIN" && (
          <nav className="mb-3 text-sm text-ink-subtle">
            <Link href={`/people${projectKey ? `?project=${projectKey}` : ""}`} className="hover:text-brand-600 hover:underline">
              {t("title")}
            </Link>
            <span className="mx-1.5">/</span>
            <span className="text-ink">{person.name}</span>
          </nav>
        )}

        <section className="mb-5 flex flex-wrap items-center gap-5 rounded-[3px] border border-line bg-surface-raised p-5">
          <Avatar user={person} size="xl" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-semibold text-ink">{person.name}</h1>
              <Lozenge tone={person.role === "ADMIN" ? "purple" : "todo"}>{person.role === "ADMIN" || person.role === "MEMBER" ? te(`role.${person.role}`) : person.role}</Lozenge>
              {!person.active && <Lozenge tone="danger">{tc("inactive")}</Lozenge>}
              {isSelf && <Lozenge tone="progress">{t("you")}</Lozenge>}
            </div>
            <p className="mt-0.5 text-sm text-ink-muted">{[person.title, person.department].filter(Boolean).join(" · ") || t("noJobTitle")}</p>
            <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-xs text-ink-subtle">
              <span className="inline-flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5" /> {person.email}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <CalendarDays className="h-3.5 w-3.5" /> {t("memberSince", { date: f.date(person.createdAt) })}
              </span>
              <span className="inline-flex items-center gap-1.5" suppressHydrationWarning>
                <Clock className="h-3.5 w-3.5" /> {t("lastActivity", { time: data.lastActive ? f.relative(data.lastActive) : "—" })}
                {person.lastSeenAt && <span className="text-ink-faint">{t("lastLogin", { time: f.relative(person.lastSeenAt) })}</span>}
              </span>
            </div>
          </div>
          {memberProjects.length > 0 && (
            <div className="flex max-w-sm flex-wrap justify-end gap-1.5">
              {memberProjects.map((pr) => (
                <Link
                  key={pr.id}
                  href={`/projects/${pr.key}/board`}
                  className="inline-flex items-center gap-1.5 rounded-[3px] border border-line px-2 py-1 text-xs text-ink hover:bg-surface-hover"
                >
                  <ProjectAvatar project={pr} size="sm" />
                  {pr.name}
                </Link>
              ))}
            </div>
          )}
        </section>

        <DashboardFrame period={days} projects={data.scope.projects} projectKey={projectKey}>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <KpiTile label={t("kpiCompleted")} value={fmtNum(m.completed)} current={m.completed} previous={p.completed} trend={data.weeklySeries.map((w) => w.completed)} />
            <KpiTile label={t("kpiPoints")} value={fmtNum(m.points)} current={m.points} previous={p.points} trend={data.weeklySeries.map((w) => w.points)} />
            <KpiTile label={t("kpiHours")} value={fmtHours(m.minutes)} unit={t("hoursUnit")} current={m.minutes} previous={p.minutes} trend={data.weeklySeries.map((w) => w.hours)} />
            <KpiTile label={t("kpiOpen")} value={fmtNum(m.open)} sub={t("openSub", { t: m.todo, p: m.inProgress, r: m.inReview })} />
            <KpiTile label={t("kpiOverdue")} value={fmtNum(m.overdue)} tone={m.overdue > 0 ? "bad" : undefined} sub={t("kpiOverdueSub")} />
            <KpiTile
              label={t("kpiCycle")}
              value={m.avgCycleDays == null ? "—" : fmtNum(m.avgCycleDays, 1)}
              unit={m.avgCycleDays == null ? undefined : t("daysUnit")}
              current={m.avgCycleDays}
              previous={p.avgCycleDays}
              upIsGood={false}
            />
            <KpiTile label={t("kpiOnTime")} value={m.onTimeRate == null ? "—" : `${m.onTimeRate}%`} current={m.onTimeRate} previous={p.onTimeRate} />
            <KpiTile label={t("kpiBugs")} value={fmtNum(m.bugsFixed)} current={m.bugsFixed} previous={p.bugsFixed} sub={t("commentsSub", { n: m.comments })} />
          </div>

          <div className="mt-4 grid gap-4 xl:grid-cols-3">
              <ChartCard
              title={t("heatTitle")}
              subtitle={t("heatSub")}
              table={{
                columns: [t("colDay"), t("colActivity")],
                rows: Object.entries(data.heat)
                  .sort((a, b) => b[0].localeCompare(a[0]))
                  .map(([d, n]) => [f.date(`${d}T00:00:00`), n]),
              }}
            >
              <ActivityHeatmap start={data.heatStart} weeks={HEATMAP_WEEKS} counts={data.heat} />
            </ChartCard>
            <ChartCard
              title={t("weeklyTitle")}
              subtitle={t("last12Weeks")}
              table={{ columns: [t("colWeek"), t("colCompleted"), tc("storyPoints")], rows: data.weeklySeries.map((w) => [t("weekOf", { date: w.label }), w.completed, w.points]) }}
            >
              <ColumnChart data={data.weeklySeries} series={[{ key: "completed", name: t("colCompleted"), color: ACCENT }]} height={220} />
            </ChartCard>
            <ChartCard
              title={t("hoursWeeklyTitle")}
              subtitle={t("last12Weeks")}
              table={{ columns: [t("colWeek"), t("colHours")], rows: data.weeklySeries.map((w) => [t("weekOf", { date: w.label }), fmtNum(w.hours, 1)]) }}
            >
              <ColumnChart data={data.weeklySeries} series={[{ key: "hours", name: t("colHours"), color: ACCENT }]} height={220} digits={1} />
            </ChartCard>

          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <ChartCard
              title={t("byTypeTitle")}
              subtitle={t("lastDays", { n: days })}
              table={{ columns: [tc("type"), t("colCount")], rows: data.byType.map((x) => [te(`type.${x.type}`), x.count]) }}
            >
              <RankedBars
                total={typeTotal}
                empty={t("noDoneInPeriod")}
                rows={data.byType.map((x) => ({ key: x.type, label: te(`type.${x.type}`), icon: <IssueTypeIcon key={x.type} type={x.type} />, value: x.count }))}
              />
            </ChartCard>
            <ChartCard
              title={t("byProjectTitle")}
              subtitle={t("lastDays", { n: days })}
              table={{ columns: [tc("project"), t("colCount")], rows: data.byProject.map((x) => [x.project.name, x.count]) }}
            >
              <RankedBars
                empty={t("noDoneInPeriod")}
                rows={data.byProject.map((x) => ({
                  key: x.project.id,
                  label: x.project.name,
                  icon: <ProjectAvatar key={x.project.id} project={x.project} size="sm" />,
                  value: x.count,
                  href: `/projects/${x.project.key}/board`,
                }))}
              />
            </ChartCard>
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            <section className="rounded-[3px] border border-line bg-surface-raised lg:col-span-2">
              <header className="border-b border-line px-4 py-3">
                <h2 className="text-sm font-semibold text-ink">{t("currentWork")}</h2>
                <p className="text-xs text-ink-subtle">{t("currentWorkSub")}</p>
              </header>
              <div className="p-4">
                <OpenIssues groups={data.openByStatus} />
              </div>
            </section>
            <section className="rounded-[3px] border border-line bg-surface-raised">
              <header className="border-b border-line px-4 py-3">
                <h2 className="text-sm font-semibold text-ink">{t("recentActivity")}</h2>
              </header>
              <div className="max-h-[560px] overflow-y-auto p-4">
                <ActivityFeed items={data.recentActivity} person={person} />
              </div>
            </section>
          </div>

          <section className="mt-4 rounded-[3px] border border-line bg-surface-raised">
            <header className="flex items-center justify-between border-b border-line px-4 py-3">
              <h2 className="text-sm font-semibold text-ink">{t("worklogTitle")}</h2>
              <span className="text-xs text-ink-subtle">
                {t("worklogPeriod", { n: days })} <b className="font-semibold text-ink">{t("hoursValue", { h: fmtHours(m.minutes) })}</b>
              </span>
            </header>
            <div className="p-4">
              <WorklogTable items={data.recentLogs} />
            </div>
          </section>
        </DashboardFrame>
      </div>
      <IssueModalSlot issueKey={typeof sp.selectedIssue === "string" ? sp.selectedIssue : undefined} />
    </main>
  );
}
