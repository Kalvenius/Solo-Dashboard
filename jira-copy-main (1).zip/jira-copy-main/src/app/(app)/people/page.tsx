import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { getTeamDashboard, parsePeriod } from "@/lib/metrics";
import { getFormat, getT } from "@/i18n/server";
import { PageHeader } from "@/components/ui/misc";
import { Avatar } from "@/components/ui/avatar";
import { DashboardFrame } from "@/components/people/dashboard-frame";
import { EmployeesTable, type EmployeeRow } from "@/components/people/employees-table";
import { KpiTile } from "@/components/charts/kpi-tile";
import { ChartCard } from "@/components/charts/chart-card";
import { ColumnChart } from "@/components/charts/column-chart";
import { Legend } from "@/components/charts/legend";
import { RankedBars, StackedRows } from "@/components/charts/bars";
import { STATUS_RAMP, minutesToHours } from "@/components/charts/theme";
import { ChartVars } from "@/components/charts/chart-vars";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("people"))("metaTitle") };
}

type SP = Promise<Record<string, string | string[] | undefined>>;

export default async function PeoplePage({ searchParams }: { searchParams: SP }) {
  const viewer = await requireUser();
  const sp = await searchParams;

  // Komanda görünüşü yalnız admin üçündür; üzv öz dashboarduna yönləndirilir
  if (viewer.role !== "ADMIN") {
    const q = new URLSearchParams();
    if (typeof sp.period === "string") q.set("period", sp.period);
    if (typeof sp.project === "string") q.set("project", sp.project);
    const qs = q.toString();
    redirect(`/people/${viewer.id}${qs ? `?${qs}` : ""}`);
  }

  const [t, te, f] = await Promise.all([getT("people"), getT("enums"), getFormat()]);
  const fmtNum = (n: number, digits = 0) => f.num(n, digits);
  const fmtHours = (minutes: number) => f.num(minutesToHours(minutes), 1);
  const days = parsePeriod(sp.period);
  const data = await getTeamDashboard(viewer, { days, projectKey: sp.project });
  const { team, rows } = data;
  const projectKey = data.scope.selected?.key ?? null;

  const tableRows: EmployeeRow[] = rows.map((r) => ({
    id: r.id,
    name: r.name,
    title: r.title,
    avatarColor: r.avatarColor,
    active: r.active,
    open: r.current.open,
    inProgress: r.current.inProgress,
    inReview: r.current.inReview,
    completed: r.current.completed,
    points: r.current.points,
    minutes: r.current.minutes,
    overdue: r.current.overdue,
    onTimeRate: r.current.onTimeRate,
    avgCycleDays: r.current.avgCycleDays,
    lastActive: r.lastActive,
    weekly: r.weeklyCompleted,
  }));

  const workloadSeries = (["TODO", "IN_PROGRESS", "IN_REVIEW"] as const).map((s) => ({ name: te(`status.${s}`), color: STATUS_RAMP[s] }));
  const workloadRows = [...rows]
    .filter((r) => r.current.open > 0)
    .sort((a, b) => b.current.open - a.current.open)
    .map((r) => ({
      key: r.id,
      label: r.name,
      lead: <Avatar key={r.id} user={r} size="xs" />,
      values: [r.current.todo, r.current.inProgress, r.current.inReview],
      href: `/people/${r.id}${projectKey ? `?project=${projectKey}` : ""}`,
    }));

  const hoursRows = [...rows]
    .filter((r) => r.current.minutes > 0)
    .sort((a, b) => b.current.minutes - a.current.minutes)
    .map((r) => ({
      key: r.id,
      label: r.name,
      icon: <Avatar key={r.id} user={r} size="xs" />,
      value: r.current.minutes,
      valueLabel: `${fmtHours(r.current.minutes)} ${t("hoursUnit")}`,
      href: `/people/${r.id}${projectKey ? `?project=${projectKey}` : ""}`,
    }));

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[1400px] px-8 py-6">
        <ChartVars />
        <PageHeader title={t("title")}>
          <p className="mt-1 text-sm text-ink-subtle">{t("subtitle", { scope: data.scope.selected ? data.scope.selected.name : t("allProjectsLower") })}</p>
        </PageHeader>

        <DashboardFrame
          period={days}
          projects={data.scope.projects}
          projectKey={projectKey}
          rangeLabel={`${f.date(data.range.from)} – ${f.date(data.range.to)}`}
        >
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
            <KpiTile label={t("kpiCompleted")} value={fmtNum(team.current.completed)} current={team.current.completed} previous={team.previous.completed} trend={data.teamWeekly} />
            <KpiTile label={t("kpiPoints")} value={fmtNum(team.current.points)} current={team.current.points} previous={team.previous.points} />
            <KpiTile label={t("kpiHours")} value={fmtHours(team.current.minutes)} unit={t("hoursUnit")} current={team.current.minutes} previous={team.previous.minutes} />
            <KpiTile
              label={t("kpiOpen")}
              value={fmtNum(team.current.open)}
              sub={t("openSubTeam", { p: team.current.inProgress, r: team.current.inReview })}
            />
            <KpiTile label={t("kpiOverdue")} value={fmtNum(team.current.overdue)} tone={team.current.overdue > 0 ? "bad" : undefined} sub={t("kpiOverdueSub")} />
            <KpiTile
              label={t("kpiCycleTeam")}
              value={team.current.avgCycleDays == null ? "—" : fmtNum(team.current.avgCycleDays, 1)}
              unit={team.current.avgCycleDays == null ? undefined : t("daysUnit")}
              current={team.current.avgCycleDays}
              previous={team.previous.avgCycleDays}
              upIsGood={false}
            />
            <KpiTile
              label={t("kpiOnTime")}
              value={team.current.onTimeRate == null ? "—" : `${team.current.onTimeRate}%`}
              current={team.current.onTimeRate}
              previous={team.previous.onTimeRate}
            />
          </div>

          <h2 className="mb-2 mt-6 text-base font-semibold text-ink">{t("byEmployee")}</h2>
          <EmployeesTable rows={tableRows} projectKey={projectKey} />

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <ChartCard
              className="lg:col-span-2"
              title={t("weeklyTitle")}
              subtitle={t("weeklySubTeam")}
              legend={<Legend items={data.weeklySeries.map((s) => ({ name: s.name, color: s.color }))} />}
              table={{
                columns: [t("colWeek"), ...data.weeklySeries.map((s) => s.name), t("total")],
                rows: data.weeklyStack.map((w) => {
                  const vals = data.weeklySeries.map((s) => Number(w[s.key] ?? 0));
                  return [t("weekOf", { date: String(w.label) }), ...vals, vals.reduce((a, b) => a + b, 0)];
                }),
              }}
            >
              {data.weeklySeries.length ? (
                <ColumnChart data={data.weeklyStack} series={data.weeklySeries} stacked height={260} />
              ) : (
                <p className="py-10 text-center text-sm text-ink-subtle">{t("noWeeklyDone")}</p>
              )}
            </ChartCard>

            <ChartCard
              title={t("workloadTitle")}
              subtitle={t("workloadSub")}
              legend={<Legend items={workloadSeries} />}
              table={{
                columns: [t("colEmployee"), ...workloadSeries.map((s) => s.name), t("total")],
                rows: workloadRows.map((r) => [r.label, ...r.values, r.values.reduce((a, b) => a + b, 0)]),
              }}
            >
              <StackedRows rows={workloadRows} series={workloadSeries} empty={t("noOpenIssues")} />
            </ChartCard>

            <ChartCard
              title={t("hoursTitle")}
              subtitle={t("hoursSub", { n: days })}
              table={{ columns: [t("colEmployee"), t("colHours")], rows: hoursRows.map((r) => [r.label, fmtHours(r.value)]) }}
            >
              <RankedBars rows={hoursRows} empty={t("noHours")} labelWidth="w-40" />
            </ChartCard>
          </div>

          <p className="mt-6 text-xs text-ink-faint">{t("footnote")}</p>
        </DashboardFrame>
      </div>
    </main>
  );
}
