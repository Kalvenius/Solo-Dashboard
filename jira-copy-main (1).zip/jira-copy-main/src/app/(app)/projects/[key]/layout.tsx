import { loadProjectPage } from "@/lib/project-page";
import { ProjectSidebar } from "@/components/layout/project-sidebar";

export default async function ProjectLayout({ children, params }: { children: React.ReactNode; params: Promise<{ key: string }> }) {
  const { key } = await params;
  const { project } = await loadProjectPage(key);
  return (
    <>
      <ProjectSidebar project={{ key: project.key, name: project.name, color: project.color, type: project.type }} />
      <main className="flex min-w-0 flex-1 flex-col overflow-y-auto">{children}</main>
    </>
  );
}
