import Link from "next/link";
import { db } from "@/lib/db";
import { loadProjectPage } from "@/lib/project-page";
import { PageHeader } from "@/components/ui/misc";
import { ProjectDetailsForm } from "@/components/projects/project-details-form";
import { ProjectMembers } from "@/components/projects/project-members";
import { ProjectDangerZone } from "@/components/projects/project-danger-zone";
import { getT } from "@/i18n/server";

export async function generateMetadata() {
  return { title: (await getT("projects"))("settingsTitle") };
}

export default async function ProjectSettingsPage({ params }: { params: Promise<{ key: string }> }) {
  const { key } = await params;
  const { user, project, canManage } = await loadProjectPage(key);

  const [allUsers, issueCount] = await Promise.all([
    canManage
      ? db.user.findMany({ where: { active: true }, select: { id: true, name: true, email: true, avatarColor: true }, orderBy: { name: "asc" } })
      : Promise.resolve([]),
    db.issue.count({ where: { projectId: project.id } }),
  ]);

  const members = project.members.map((m) => ({ ...m.user, role: m.role }));
  const t = await getT("projects");

  return (
    <div className="px-8 py-6">
      <div className="max-w-[860px]">
        <PageHeader
          title={t("settingsTitle")}
          breadcrumbs={
            <>
              <Link href="/projects" className="hover:underline">
                {t("title")}
              </Link>
              <span className="mx-1.5">/</span>
              <Link href={`/projects/${project.key}/board`} className="hover:underline">
                {project.name}
              </Link>
            </>
          }
        />
        {!canManage && (
          <div className="mb-4 rounded-[3px] border border-brand-100 bg-brand-50 px-3 py-2 text-sm text-ink-muted">
            {t("readOnlyNotice")}
          </div>
        )}
        <div className="space-y-8">
          <ProjectDetailsForm
            canManage={canManage}
            project={{
              id: project.id,
              key: project.key,
              name: project.name,
              description: project.description,
              type: project.type,
              color: project.color,
              leadId: project.leadId,
            }}
            members={members}
          />
          <ProjectMembers projectId={project.id} canManage={canManage} members={members} allUsers={allUsers} meId={user.id} leadId={project.leadId} />
          {canManage && <ProjectDangerZone projectId={project.id} projectKey={project.key} projectName={project.name} issueCount={issueCount} />}
        </div>
      </div>
    </div>
  );
}
