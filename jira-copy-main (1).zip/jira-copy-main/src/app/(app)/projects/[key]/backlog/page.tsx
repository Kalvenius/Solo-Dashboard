import { Suspense } from "react";
import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { loadProjectPage } from "@/lib/project-page";
import { issueCardSelect } from "@/lib/issue-select";
import { PageHeader } from "@/components/ui/misc";
import { Backlog, type EpicProgress } from "@/components/backlog/backlog";
import { IssueModalSlot } from "@/components/issue/issue-modal";
import { getT } from "@/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("common"))("backlog") };
}

export default async function BacklogPage({
  params,
  searchParams,
}: {
  params: Promise<{ key: string }>;
  searchParams: Promise<{ selectedIssue?: string }>;
}) {
  const { key } = await params;
  const sp = await searchParams;
  const { user, project } = await loadProjectPage(key);
  if (project.type !== "SCRUM") redirect(`/projects/${project.key}/board`);
  const tc = await getT("common");

  const sprintRows = await db.sprint.findMany({
    where: { projectId: project.id, state: { in: ["ACTIVE", "PLANNED"] } },
    select: { id: true, name: true, goal: true, state: true, startDate: true, endDate: true, createdAt: true },
  });
  // aktiv sprint əvvəl, sonra planlaşdırılmışlar yaradılma sırası ilə
  const sprints = sprintRows
    .sort((a, b) => (a.state === b.state ? a.createdAt.getTime() - b.createdAt.getTime() : a.state === "ACTIVE" ? -1 : 1))
    .map(({ createdAt: _c, ...s }) => s);

  const [issues, epicRows] = await Promise.all([
    db.issue.findMany({
      where: {
        projectId: project.id,
        type: { notIn: ["EPIC", "SUBTASK"] },
        OR: [
          { sprintId: { in: sprints.map((s) => s.id) } },
          // backlog: sprintsiz (və ya tamamlanmış sprintdə qalmış) bitməmiş tapşırıqlar
          { sprintId: null, status: { not: "DONE" } },
          { sprint: { state: "COMPLETED" }, status: { not: "DONE" } },
        ],
      },
      select: issueCardSelect,
      orderBy: { rank: "asc" },
    }),
    db.issue.findMany({
      where: { projectId: project.id, type: "EPIC" },
      select: { id: true, key: true, title: true, status: true, children: { select: { status: true } } },
      orderBy: { rank: "asc" },
    }),
  ]);

  const epics: EpicProgress[] = epicRows.map((e) => ({
    id: e.id,
    key: e.key,
    title: e.title,
    status: e.status,
    total: e.children.length,
    done: e.children.filter((c) => c.status === "DONE").length,
  }));

  const members = project.members
    .filter((m) => m.user.active)
    .map((m) => ({ id: m.user.id, name: m.user.name, avatarColor: m.user.avatarColor }))
    .sort((a, b) => (a.id === user.id ? -1 : b.id === user.id ? 1 : a.name.localeCompare(b.name, "az")));

  return (
    <div className="flex min-h-full flex-col px-8 pt-6">
      <PageHeader
        title={tc("backlog")}
        breadcrumbs={
          <>
            <Link href="/projects" className="hover:underline">
              {tc("projects")}
            </Link>
            <span className="mx-1.5">/</span>
            <span>{project.name}</span>
          </>
        }
      />
      <Suspense>
        <Backlog projectId={project.id} sprints={sprints} issues={issues} epics={epics} members={members} currentUserId={user.id} />
      </Suspense>
      <IssueModalSlot issueKey={sp.selectedIssue} />
    </div>
  );
}
