import type { Metadata } from "next";
import Link from "next/link";
import { loadProjectPage } from "@/lib/project-page";
import { getProjectReports } from "@/lib/metrics";
import type { Status } from "@/lib/constants";
import { pct } from "@/lib/utils";
import { getFormat, getT } from "@/i18n/server";
import { PageHeader } from "@/components/ui/misc";
import { Avatar } from "@/components/ui/avatar";
import { IssueTypeIcon, PriorityIcon } from "@/components/issue/icons";
import { KpiTile } from "@/components/charts/kpi-tile";
import { ChartCard } from "@/components/charts/chart-card";
import { LineChartView } from "@/components/charts/line-chart";
import { ColumnChart } from "@/components/charts/column-chart";
import { StackedArea } from "@/components/charts/stacked-area";
import { Legend } from "@/components/charts/legend";
import { RankedBars, StackedRows } from "@/components/charts/bars";
import { ACCENT, MUTED_SERIES, SERIES_COLORS, STATUS_RAMP } from "@/components/charts/theme";
import { ChartVars } from "@/components/charts/chart-vars";
import { SprintSelect } from "@/components/reports/sprint-select";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("reports"))("title") };
}

type SP = Promise<Record<string, string | string[] | undefined>>;

export default async function ReportsPage({ params, searchParams }: { params: Promise<{ key: string }>; searchParams: SP }) {
  const { key } = await params;
  const sp = await searchParams;
  const { project } = await loadProjectPage(key);
  const r = await getProjectReports(project, sp.sprint);
  const isScrum = project.type === "SCRUM";
  const [t, te, tc, f] = await Promise.all([getT("reports"), getT("enums"), getT("common"), getFormat()]);
  const fmtNum = (n: number, digits = 0) => f.num(n, digits);

  const createdSeries = [
    { key: "created", name: t("created"), color: SERIES_COLORS[1]! },
    { key: "resolved", name: t("resolved"), color: ACCENT },
  ];
  const createdTotal = r.createdResolved.reduce((s, d) => s + d.created, 0);
  const resolvedTotal = r.createdResolved.reduce((s, d) => s + d.resolved, 0);

  const flowOrder: Status[] = ["DONE", "IN_REVIEW", "IN_PROGRESS", "TODO"]; // aşağıdan yuxarıya
  const cfdSeries = flowOrder.map((s) => ({ key: s, name: te(`status.${s}`), color: STATUS_RAMP[s] }));

  const loadSeries = (["TODO", "IN_PROGRESS", "IN_REVIEW"] as const).map((s) => ({ name: te(`status.${s}`), color: STATUS_RAMP[s] }));
  const loadRows = r.workload.map((w) => ({
    key: w.id ?? "none",
    label: w.name,
    lead: <Avatar key={w.id ?? "none"} user={w.id ? { name: w.name, avatarColor: w.avatarColor } : null} size="xs" />,
    values: [w.todo, w.inProgress, w.inReview],
    href: w.id ? `/people/${w.id}?project=${project.key}` : undefined,
  }));

  const velocityAvg = r.velocity.length ? Math.round(r.velocity.reduce((s, v) => s + v.completed, 0) / r.velocity.length) : null;
  const bd = r.burndown;
  const unitLabel = bd?.unit === "points" ? t("unitPoints") : t("unitIssues");

  return (
    <div className="px-8 py-6">
      <ChartVars />
      <PageHeader
        title={t("title")}
        breadcrumbs={
          <>
            <Link href="/projects" className="hover:text-brand-600 hover:underline">
              {tc("projects")}
            </Link>
            <span className="mx-1.5">/</span>
            <Link href={`/projects/${project.key}/board`} className="hover:text-brand-600 hover:underline">
              {project.name}
            </Link>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiTile label={t("kpiAll")} value={fmtNum(r.totals.all)} sub={t("kpiAllSub")} />
        <KpiTile label={t("kpiOpen")} value={fmtNum(r.totals.open)} sub={t("shareOfTotal", { p: pct(r.totals.open, r.totals.all) })} />
        <KpiTile label={t("kpiDone")} value={fmtNum(r.totals.done)} sub={t("shareOfTotal", { p: pct(r.totals.done, r.totals.all) })} />
        <KpiTile label={t("kpiResolved30")} value={fmtNum(resolvedTotal)} sub={t("createdNew", { n: createdTotal })} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        {isScrum ? (
          <>
            <ChartCard
              className="lg:col-span-2"
              title={t("burndown")}
              subtitle={
                bd
                  ? `${bd.sprint.name} · ${f.date(bd.sprint.startDate)} – ${f.date(bd.sprint.endDate)}${bd.sprint.goal ? t("goalSuffix", { goal: bd.sprint.goal }) : ""}`
                  : t("noStartedSprint")
              }
              actions={<SprintSelect sprints={r.sprints} value={bd?.sprint.id ?? null} />}
              legend={
                bd ? (
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <Legend
                      items={[
                        { name: t("remainingUnit", { unit: unitLabel }), color: ACCENT, shape: "line" },
                        { name: t("ideal"), color: MUTED_SERIES, shape: "line" },
                      ]}
                    />
                    <span className="text-xs text-ink-subtle">
                      {t("total")} <b className="font-semibold text-ink">{fmtNum(bd.total)}</b> · {t("done")} <b className="font-semibold text-ink">{fmtNum(bd.done)}</b> · {t("remaining")}{" "}
                      <b className="font-semibold text-ink">{fmtNum(bd.total - bd.done)}</b>
                      {bd.sprint.state === "ACTIVE" && (
                        <>
                          {" "}
                          · <b className="font-semibold text-ink">{t("daysLeft", { n: bd.daysLeft })}</b>
                        </>
                      )}
                    </span>
                  </div>
                ) : undefined
              }
              table={
                bd
                  ? { columns: [t("colDay"), t("remaining"), t("ideal")], rows: bd.points.map((p) => [p.label, p.remaining ?? "—", fmtNum(p.ideal, 1)]) }
                  : undefined
              }
            >
              {bd ? (
                <LineChartView
                  data={bd.points}
                  series={[
                    { key: "ideal", name: t("ideal"), color: MUTED_SERIES },
                    { key: "remaining", name: t("remaining"), color: ACCENT },
                  ]}
                  height={280}
                  digits={1}
                />
              ) : (
                <p className="py-12 text-center text-sm text-ink-subtle">
                  {t("startSprintHint")}{" "}
                  <Link href={`/projects/${project.key}/backlog`} className="text-brand-600 hover:underline">
                    {t("goToBacklog")}
                  </Link>
                </p>
              )}
            </ChartCard>

            <ChartCard
              title={t("velocity")}
              subtitle={velocityAvg != null ? t("velocitySub", { n: r.velocity.length, avg: velocityAvg }) : t("velocitySubEmpty")}
              legend={
                r.velocity.length ? (
                  <Legend
                    items={[
                      { name: t("committed"), color: MUTED_SERIES },
                      { name: t("completed"), color: ACCENT },
                    ]}
                  />
                ) : undefined
              }
              table={{ columns: [tc("sprint"), t("committed"), t("completed")], rows: r.velocity.map((v) => [v.name, v.committed, v.completed]) }}
            >
              {r.velocity.length ? (
                <ColumnChart
                  data={r.velocity}
                  xKey="name"
                  series={[
                    { key: "committed", name: t("committed"), color: MUTED_SERIES },
                    { key: "completed", name: t("completed"), color: ACCENT },
                  ]}
                  height={240}
                />
              ) : (
                <p className="py-12 text-center text-sm text-ink-subtle">{t("noCompletedSprints")}</p>
              )}
            </ChartCard>
          </>
        ) : (
          <ChartCard
            className="lg:col-span-2"
            title={t("cfd")}
            subtitle={t("cfdSub")}
            legend={<Legend items={[...cfdSeries].reverse()} />}
            table={{
              columns: [t("colDay"), ...[...cfdSeries].reverse().map((s) => s.name)],
              rows: (r.cfd ?? []).map((d) => [String(d.label), ...[...cfdSeries].reverse().map((s) => Number(d[s.key] ?? 0))]),
            }}
          >
            <StackedArea data={r.cfd ?? []} series={cfdSeries} height={280} />
          </ChartCard>
        )}

        <ChartCard
          className={isScrum ? undefined : "lg:col-span-2"}
          title={t("createdResolved")}
          subtitle={t("createdResolvedSub", { c: createdTotal, r: resolvedTotal })}
          legend={<Legend items={createdSeries.map((s) => ({ name: s.name, color: s.color, shape: "line" as const }))} />}
          table={{ columns: [t("colDay"), t("created"), t("resolved")], rows: r.createdResolved.map((d) => [d.label, d.created, d.resolved]) }}
        >
          <LineChartView data={r.createdResolved} series={createdSeries} height={240} />
        </ChartCard>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <ChartCard title={t("byStatus")} subtitle={t("currentState")} table={{ columns: [tc("status"), t("count")], rows: r.byStatus.map((x) => [te(`status.${x.key}`), x.count]) }}>
          <RankedBars rows={r.byStatus.map((x) => ({ key: x.key, label: te(`status.${x.key}`), value: x.count }))} labelWidth="w-32" />
        </ChartCard>
        <ChartCard title={t("byType")} subtitle={t("kpiAllSub")} table={{ columns: [tc("type"), t("count")], rows: r.byType.map((x) => [te(`type.${x.key}`), x.count]) }}>
          <RankedBars
            rows={r.byType.map((x) => ({ key: x.key, label: te(`type.${x.key}`), icon: <IssueTypeIcon key={x.key} type={x.key} />, value: x.count }))}
            labelWidth="w-32"
          />
        </ChartCard>
        <ChartCard title={t("byPriority")} subtitle={t("allIssues")} table={{ columns: [tc("priority"), t("count")], rows: r.byPriority.map((x) => [te(`priority.${x.key}`), x.count]) }}>
          <RankedBars
            rows={r.byPriority.map((x) => ({ key: x.key, label: te(`priority.${x.key}`), icon: <PriorityIcon key={x.key} priority={x.key} />, value: x.count }))}
            labelWidth="w-32"
          />
        </ChartCard>
      </div>

      <ChartCard
        className="mt-4"
        title={t("workload")}
        subtitle={t("workloadSub")}
        legend={<Legend items={loadSeries} />}
        table={{ columns: [tc("assignee"), ...loadSeries.map((s) => s.name), t("total")], rows: loadRows.map((x) => [x.label, ...x.values, x.values.reduce((a, b) => a + b, 0)]) }}
      >
        <StackedRows rows={loadRows} series={loadSeries} empty={t("noOpenIssues")} />
      </ChartCard>
    </div>
  );
}
