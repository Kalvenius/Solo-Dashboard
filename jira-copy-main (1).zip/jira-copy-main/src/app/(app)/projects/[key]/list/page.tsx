import Link from "next/link";
import { loadProjectPage } from "@/lib/project-page";
import type { SearchParams } from "@/lib/issue-filters";
import { PageHeader } from "@/components/ui/misc";
import { IssueNavigator } from "@/components/issues/issue-navigator";
import { IssueModalSlot } from "@/components/issue/issue-modal";
import { getT } from "@/i18n/server";

export async function generateMetadata() {
  return { title: (await getT("nav"))("list") };
}

export default async function ProjectListPage({ params, searchParams }: { params: Promise<{ key: string }>; searchParams: Promise<SearchParams> }) {
  const { key } = await params;
  const sp = await searchParams;
  const { user, project } = await loadProjectPage(key);
  const selected = Array.isArray(sp.selectedIssue) ? sp.selectedIssue[0] : sp.selectedIssue;
  const t = await getT("nav");

  return (
    <div className="px-8 py-6">
      <PageHeader
        title={t("list")}
        breadcrumbs={
          <>
            <Link href="/projects" className="hover:underline">
              {t("projects")}
            </Link>
            <span className="mx-1.5">/</span>
            <Link href={`/projects/${project.key}/board`} className="hover:underline">
              {project.name}
            </Link>
          </>
        }
      />
      <IssueNavigator user={user} searchParams={sp} project={{ id: project.id, key: project.key, members: project.members }} />
      <IssueModalSlot issueKey={selected} />
    </div>
  );
}
