import { Suspense } from "react";
import type { Metadata } from "next";
import Link from "next/link";
import { differenceInCalendarDays, subDays } from "date-fns";
import { Clock, Target } from "lucide-react";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { loadProjectPage } from "@/lib/project-page";
import { issueCardSelect } from "@/lib/issue-select";
import { getFormat, getT } from "@/i18n/server";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { Board } from "@/components/board/board";
import { CompleteSprintButton } from "@/components/board/sprint-header";
import { IssueModalSlot } from "@/components/issue/issue-modal";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("common"))("board") };
}

export default async function BoardPage({
  params,
  searchParams,
}: {
  params: Promise<{ key: string }>;
  searchParams: Promise<{ selectedIssue?: string }>;
}) {
  const { key } = await params;
  const sp = await searchParams;
  const { user, project } = await loadProjectPage(key);
  const isKanban = project.type === "KANBAN";
  const [t, tc, f] = await Promise.all([getT("board"), getT("common"), getFormat()]);

  const breadcrumbs = (
    <>
      <Link href="/projects" className="hover:underline">
        {tc("projects")}
      </Link>
      <span className="mx-1.5">/</span>
      <span>{project.name}</span>
    </>
  );

  const sprint = isKanban
    ? null
    : await db.sprint.findFirst({ where: { projectId: project.id, state: "ACTIVE" }, orderBy: { startDate: "desc" } });

  if (!isKanban && !sprint) {
    return (
      <div className="px-8 py-6">
        <PageHeader title={t("boardTitle", { key: project.key })} breadcrumbs={breadcrumbs} />
        <EmptyState
          icon={<Clock className="h-12 w-12" />}
          title={t("noActiveSprint")}
          description={t("noActiveSprintText")}
          action={
            <Link href={`/projects/${project.key}/backlog`} className="rounded-[3px] bg-brand-600 px-3 py-1.5 text-sm font-medium text-on-brand hover:bg-brand-700">
              {t("goToBacklog")}
            </Link>
          }
        />
        <IssueModalSlot issueKey={sp.selectedIssue} />
      </div>
    );
  }

  const where: Prisma.IssueWhereInput = isKanban
    ? {
        projectId: project.id,
        type: { not: "EPIC" },
        OR: [{ status: { not: "DONE" } }, { resolvedAt: { gte: subDays(new Date(), 14) } }],
      }
    : { projectId: project.id, sprintId: sprint!.id, type: { not: "EPIC" } };

  const [issues, epics, planned] = await Promise.all([
    db.issue.findMany({ where, select: issueCardSelect, orderBy: { rank: "asc" } }),
    db.issue.findMany({ where: { projectId: project.id, type: "EPIC" }, select: { id: true, key: true, title: true }, orderBy: { rank: "asc" } }),
    sprint
      ? db.sprint.findMany({ where: { projectId: project.id, state: "PLANNED" }, select: { id: true, name: true }, orderBy: { createdAt: "asc" } })
      : Promise.resolve([]),
  ]);

  const members = project.members
    .filter((m) => m.user.active)
    .map((m) => ({ id: m.user.id, name: m.user.name, avatarColor: m.user.avatarColor }))
    .sort((a, b) => (a.id === user.id ? -1 : b.id === user.id ? 1 : a.name.localeCompare(b.name, "az")));

  const parents = issues.filter((i) => i.type !== "SUBTASK");
  const doneCount = parents.filter((i) => i.status === "DONE").length;
  const openCount = parents.length - doneCount;

  let daysLabel: string | null = null;
  let sprintOverdue = false;
  if (sprint?.endDate) {
    const d = differenceInCalendarDays(sprint.endDate, new Date());
    sprintOverdue = d < 0;
    daysLabel = d > 0 ? t("daysLeft", { n: d }) : d === 0 ? t("endsToday") : t("overdueBy", { n: -d });
  }

  return (
    <div className="flex min-h-full flex-col px-8 pt-6">
      <PageHeader
        title={sprint ? sprint.name : t("boardTitle", { key: project.key })}
        breadcrumbs={breadcrumbs}
        actions={
          sprint ? (
            <>
              {daysLabel && (
                <span
                  className={`mr-1 inline-flex items-center gap-1 text-sm ${sprintOverdue ? "text-danger" : "text-ink-subtle"}`}
                  title={`${f.date(sprint.startDate)} – ${f.date(sprint.endDate)}`}
                >
                  <Clock className="h-4 w-4" />
                  {daysLabel}
                </span>
              )}
              <CompleteSprintButton
                projectKey={project.key}
                sprint={{ id: sprint.id, name: sprint.name }}
                doneCount={doneCount}
                openCount={openCount}
                plannedSprints={planned}
              />
            </>
          ) : null
        }
      >
        {sprint?.goal && (
          <p className="mt-1 flex items-center gap-1.5 text-sm text-ink-muted">
            <Target className="h-4 w-4 text-ink-subtle" />
            <span className="font-medium">{t("goal")}</span> {sprint.goal}
          </p>
        )}
      </PageHeader>

      <Suspense>
        <Board
          projectId={project.id}
          issues={issues}
          members={members}
          epics={epics}
          currentUserId={user.id}
          sprintId={sprint?.id ?? null}
          isKanban={isKanban}
        />
      </Suspense>
      <IssueModalSlot issueKey={sp.selectedIssue} />
    </div>
  );
}
