import type { Metadata } from "next";
import Link from "next/link";
import { GanttChartSquare } from "lucide-react";
import { loadProjectPage } from "@/lib/project-page";
import { getTimeline } from "@/lib/metrics";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { IssueModalSlot } from "@/components/issue/issue-modal";
import { TimelineView } from "@/components/timeline/timeline-view";
import { ChartVars } from "@/components/charts/chart-vars";
import { getT } from "@/i18n/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("timeline"))("title") };
}

type SP = Promise<Record<string, string | string[] | undefined>>;

export default async function TimelinePage({ params, searchParams }: { params: Promise<{ key: string }>; searchParams: SP }) {
  const { key } = await params;
  const sp = await searchParams;
  const { project } = await loadProjectPage(key);
  const epics = await getTimeline(project.id);
  const undated = epics.filter((e) => !e.dueDate).length;
  const [t, tc] = await Promise.all([getT("timeline"), getT("common")]);

  return (
    <div className="px-8 py-6">
      <ChartVars />
      <PageHeader
        title={t("title")}
        breadcrumbs={
          <>
            <Link href="/projects" className="hover:text-brand-600 hover:underline">
              {tc("projects")}
            </Link>
            <span className="mx-1.5">/</span>
            <Link href={`/projects/${project.key}/board`} className="hover:text-brand-600 hover:underline">
              {project.name}
            </Link>
          </>
        }
      >
        <p className="mt-1 text-sm text-ink-subtle">
          {t("intro")}
          {undated > 0 && ` ${t("undated", { n: undated })}`}
        </p>
      </PageHeader>

      {epics.length === 0 ? (
        <EmptyState
          icon={<GanttChartSquare className="h-10 w-10" />}
          title={t("emptyTitle")}
          description={t("emptyText")}
        />
      ) : (
        <TimelineView epics={epics} color={project.color} />
      )}
      <IssueModalSlot issueKey={typeof sp.selectedIssue === "string" ? sp.selectedIssue : undefined} />
    </div>
  );
}
