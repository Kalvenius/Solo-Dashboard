import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { accessibleProjectIds } from "@/lib/access";
import { ProjectsTable } from "@/components/projects/projects-table";
import { getT } from "@/i18n/server";

export async function generateMetadata() {
  return { title: (await getT("projects"))("title") };
}

export default async function ProjectsPage() {
  const user = await requireUser();
  const ids = await accessibleProjectIds(user);

  const [projects, openCounts, users] = await Promise.all([
    db.project.findMany({
      where: ids === null ? {} : { id: { in: ids } },
      select: {
        id: true,
        key: true,
        name: true,
        type: true,
        color: true,
        description: true,
        lead: { select: { id: true, name: true, avatarColor: true } },
        members: { select: { user: { select: { id: true, name: true, avatarColor: true } } }, orderBy: { joinedAt: "asc" } },
        _count: { select: { issues: true } },
      },
      orderBy: { name: "asc" },
    }),
    db.issue.groupBy({
      by: ["projectId"],
      where: { status: { not: "DONE" }, type: { not: "EPIC" }, ...(ids === null ? {} : { projectId: { in: ids } }) },
      _count: { _all: true },
    }),
    user.role === "ADMIN"
      ? db.user.findMany({ where: { active: true }, select: { id: true, name: true, avatarColor: true }, orderBy: { name: "asc" } })
      : Promise.resolve([]),
  ]);

  const open = new Map(openCounts.map((c) => [c.projectId, c._count._all]));
  const rows = projects.map((p) => ({
    id: p.id,
    key: p.key,
    name: p.name,
    type: p.type,
    color: p.color,
    description: p.description,
    lead: p.lead,
    members: p.members.map((m) => m.user),
    total: p._count.issues,
    open: open.get(p.id) ?? 0,
  }));

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[1400px] px-8 py-6">
        <ProjectsTable projects={rows} canCreate={user.role === "ADMIN"} users={users} me={user.id} />
      </div>
    </main>
  );
}
