import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { accessibleProjectIds } from "@/lib/access";
import { TopNav } from "@/components/layout/top-nav";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const ids = await accessibleProjectIds(user);
  const [projects, unread] = await Promise.all([
    db.project.findMany({
      where: ids === null ? {} : { id: { in: ids } },
      select: { id: true, key: true, name: true, color: true, type: true },
      orderBy: { name: "asc" },
    }),
    db.notification.count({ where: { userId: user.id, read: false } }),
  ]);

  return (
    <div className="flex h-full flex-col">
      <TopNav user={user} projects={projects} unread={unread} />
      <div className="flex min-h-0 flex-1">{children}</div>
    </div>
  );
}
