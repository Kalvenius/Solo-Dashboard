import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { UsersAdmin } from "@/components/admin/users-admin";
import { getT } from "@/i18n/server";

export async function generateMetadata() {
  return { title: (await getT("nav"))("users") };
}

export default async function AdminUsersPage() {
  const me = await requireAdmin();
  const [users, projects] = await Promise.all([
    db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        title: true,
        department: true,
        role: true,
        active: true,
        avatarColor: true,
        lastSeenAt: true,
        createdAt: true,
        _count: { select: { memberships: true } },
      },
      orderBy: [{ active: "desc" }, { name: "asc" }],
    }),
    db.project.findMany({ select: { id: true, key: true, name: true, color: true }, orderBy: { name: "asc" } }),
  ]);

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[1400px] px-8 py-6">
        <UsersAdmin users={users.map(({ _count, ...u }) => ({ ...u, projects: _count.memberships }))} projects={projects} meId={me.id} />
      </div>
    </main>
  );
}
