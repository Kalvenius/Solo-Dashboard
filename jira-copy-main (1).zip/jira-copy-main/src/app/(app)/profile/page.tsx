import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { getFormat, getT } from "@/i18n/server";
import { PageHeader } from "@/components/ui/misc";
import { PasswordForm, PreferencesSection, ProfileForm } from "@/components/profile/profile-forms";

export async function generateMetadata() {
  return { title: (await getT("nav"))("profileSettings") };
}

export default async function ProfilePage() {
  const me = await requireUser();
  const extra = await db.user.findUnique({ where: { id: me.id }, select: { createdAt: true } });
  const [t, tn, te, f] = await Promise.all([getT("profile"), getT("nav"), getT("enums"), getFormat()]);

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[760px] px-8 py-6">
        <PageHeader title={tn("profileSettings")}>
          <p className="mt-1 text-sm text-ink-subtle">
            {me.email} · {te(me.role === "ADMIN" ? "role.ADMIN" : "role.MEMBER")} · {t("memberSince", { date: f.date(extra?.createdAt) })}
          </p>
        </PageHeader>
        <div className="space-y-8">
          <ProfileForm user={{ name: me.name, title: me.title, department: me.department, avatarColor: me.avatarColor }} />
          <PreferencesSection />
          <PasswordForm />
        </div>
      </div>
    </main>
  );
}
