import Link from "next/link";
import { startOfDay, startOfWeek, subDays } from "date-fns";
import { ArrowRight, CalendarClock, CheckCircle2, CircleDot } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { accessibleProjectIds } from "@/lib/access";
import { ProjectAvatar } from "@/components/ui/misc";
import { IssueModalSlot } from "@/components/issue/issue-modal";
import { WorkTabs, type WorkRow } from "@/components/your-work/work-tabs";
import { getT } from "@/i18n/server";

export async function generateMetadata() {
  return { title: (await getT("nav"))("yourWork") };
}

const rowSelect = {
  id: true,
  key: true,
  title: true,
  type: true,
  status: true,
  updatedAt: true,
  project: { select: { key: true, name: true, color: true } },
} as const;

function greetingKey() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return "greetingMorning" as const;
  if (h >= 12 && h < 18) return "greetingAfternoon" as const;
  return "greetingEvening" as const;
}

export default async function YourWorkPage({ searchParams }: { searchParams: Promise<{ selectedIssue?: string }> }) {
  const user = await requireUser();
  const { selectedIssue } = await searchParams;
  const ids = await accessibleProjectIds(user);
  const scope = ids === null ? {} : { projectId: { in: ids } };
  const since = subDays(new Date(), 30);
  const today = startOfDay(new Date());

  const [activities, worklogs, assignedRaw, watchingRaw, projects, openByProject, openCount, doneWeek, overdue] = await Promise.all([
    db.activity.findMany({ where: { actorId: user.id, createdAt: { gte: since } }, select: { issueId: true, createdAt: true }, orderBy: { createdAt: "desc" }, take: 1000 }),
    db.workLog.findMany({ where: { userId: user.id, createdAt: { gte: since } }, select: { issueId: true, createdAt: true }, take: 1000 }),
    db.issue.findMany({ where: { ...scope, assigneeId: user.id, status: { not: "DONE" } }, select: rowSelect, orderBy: { updatedAt: "desc" }, take: 200 }),
    db.issue.findMany({
      where: { ...scope, status: { not: "DONE" }, watchers: { some: { userId: user.id } } },
      select: rowSelect,
      orderBy: { updatedAt: "desc" },
      take: 200,
    }),
    db.project.findMany({ where: ids === null ? {} : { id: { in: ids } }, select: { id: true, key: true, name: true, color: true, type: true } }),
    db.issue.groupBy({ by: ["projectId"], where: { ...scope, assigneeId: user.id, status: { not: "DONE" } }, _count: { _all: true } }),
    db.issue.count({ where: { ...scope, assigneeId: user.id, status: { not: "DONE" }, type: { not: "EPIC" } } }),
    db.issue.count({ where: { ...scope, assigneeId: user.id, status: "DONE", resolvedAt: { gte: startOfWeek(new Date(), { weekStartsOn: 1 }) } } }),
    db.issue.count({ where: { ...scope, assigneeId: user.id, status: { not: "DONE" }, dueDate: { lt: today } } }),
  ]);

  // Üzərində işlədiklərim: son 30 gündə toxunduğum tapşırıqlar
  const touched = new Map<string, Date>();
  for (const a of [...activities, ...worklogs]) {
    const prev = touched.get(a.issueId);
    if (!prev || prev < a.createdAt) touched.set(a.issueId, a.createdAt);
  }
  const workedRaw = touched.size
    ? await db.issue.findMany({ where: { ...scope, id: { in: Array.from(touched.keys()) } }, select: { ...rowSelect, projectId: true } })
    : [];

  const toRow = (i: (typeof assignedRaw)[number], at?: Date): WorkRow => ({
    id: i.id,
    key: i.key,
    title: i.title,
    type: i.type,
    status: i.status,
    updatedAt: i.updatedAt,
    at: at ?? i.updatedAt,
    project: i.project,
  });

  const worked = workedRaw.map((i) => toRow(i, touched.get(i.id))).sort((a, b) => +b.at - +a.at);

  // Son layihələr: ən son toxunduğum layihələr birinci
  const lastTouch = new Map<string, number>();
  for (const i of workedRaw) {
    const t = touched.get(i.id)!.getTime();
    if ((lastTouch.get(i.projectId) ?? 0) < t) lastTouch.set(i.projectId, t);
  }
  const myOpen = new Map(openByProject.map((p) => [p.projectId, p._count._all]));
  const recentProjects = projects
    .slice()
    .sort((a, b) => (lastTouch.get(b.id) ?? 0) - (lastTouch.get(a.id) ?? 0) || a.name.localeCompare(b.name, "az"))
    .slice(0, 4);

  const firstName = user.name.split(/\s+/)[0] ?? user.name;
  const [t, tn, tc] = await Promise.all([getT("yourWork"), getT("nav"), getT("common")]);

  return (
    <main className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[1400px] px-8 py-6">
        <h1 className="text-2xl font-semibold text-ink">{t(greetingKey(), { name: firstName })}</h1>
        <p className="mt-1 text-sm text-ink-subtle">{t("subtitle")}</p>

        <section className="mt-6">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink-muted">{t("recentProjects")}</h2>
            <Link href="/projects" className="text-sm text-brand-600 hover:underline">
              {t("allProjects")}
            </Link>
          </div>
          {recentProjects.length === 0 ? (
            <div className="rounded-[3px] border border-dashed border-line px-4 py-6 text-center text-sm text-ink-subtle">
              {t("noProjects")}
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {recentProjects.map((p) => (
                <div key={p.id} className="relative overflow-hidden rounded-[3px] border border-line bg-surface-raised shadow-card">
                  <div className="absolute inset-y-0 left-0 w-6" style={{ backgroundColor: p.color, opacity: 0.18 }} />
                  <div className="relative py-3 pl-9 pr-4">
                    <div className="flex items-center gap-2">
                      <ProjectAvatar project={p} size="md" />
                      <div className="min-w-0">
                        <Link href={`/projects/${p.key}/board`} className="block truncate font-semibold text-ink hover:text-brand-600">
                          {p.name}
                        </Link>
                        <div className="text-xs text-ink-subtle">{p.type === "KANBAN" ? tn("kanbanProject") : tn("scrumProject")}</div>
                      </div>
                    </div>
                    <div className="mt-3 text-xs font-semibold uppercase text-ink-subtle">{t("quickLinks")}</div>
                    <div className="mt-1 flex items-center justify-between text-sm">
                      <Link href={`/projects/${p.key}/list?assignee=me&status=TODO,IN_PROGRESS,IN_REVIEW`} className="text-ink-muted hover:text-brand-600">
                        {t("myOpenIssues")}
                      </Link>
                      <span className="rounded-full bg-neutral px-2 text-xs font-semibold text-ink-muted">{myOpen.get(p.id) ?? 0}</span>
                    </div>
                    <div className="mt-2 flex gap-3 border-t border-line pt-2 text-sm">
                      <Link href={`/projects/${p.key}/board`} className="text-brand-600 hover:underline">
                        {tc("board")}
                      </Link>
                      {p.type === "SCRUM" && (
                        <Link href={`/projects/${p.key}/backlog`} className="text-brand-600 hover:underline">
                          {tc("backlog")}
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-[1fr_280px]">
          <WorkTabs worked={worked} assigned={assignedRaw.map((i) => toRow(i))} watching={watchingRaw.map((i) => toRow(i))} />

          <aside className="space-y-3">
            <div className="rounded-[3px] border border-line bg-surface-raised p-4">
              <h3 className="mb-3 text-sm font-semibold text-ink">{t("summary")}</h3>
              <ul className="space-y-2.5 text-sm">
                <li className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-ink-muted">
                    <CircleDot className="h-4 w-4 text-brand-600" /> {t("openIssues")}
                  </span>
                  <Link href="/issues?assignee=me&status=TODO,IN_PROGRESS,IN_REVIEW" className="font-semibold tabular-nums text-ink hover:text-brand-600">
                    {openCount}
                  </Link>
                </li>
                <li className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-ink-muted">
                    <CheckCircle2 className="h-4 w-4 text-success-bold" /> {t("doneThisWeek")}
                  </span>
                  <span className="font-semibold tabular-nums text-ink">{doneWeek}</span>
                </li>
                <li className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-ink-muted">
                    <CalendarClock className="h-4 w-4 text-danger-bold" /> {t("overdue")}
                  </span>
                  <Link
                    href="/issues?assignee=me&overdue=1"
                    className={`font-semibold tabular-nums hover:text-brand-600 ${overdue > 0 ? "text-danger" : "text-ink"}`}
                  >
                    {overdue}
                  </Link>
                </li>
              </ul>
              <Link
                href={`/people/${user.id}`}
                className="mt-4 flex items-center justify-center gap-1 rounded-[3px] bg-tint-1 py-1.5 text-sm font-medium text-ink hover:bg-tint-2"
              >
                {t("detailedDashboard")} <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </aside>
        </div>
      </div>
      <IssueModalSlot issueKey={selectedIssue} />
    </main>
  );
}
