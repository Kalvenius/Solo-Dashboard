import Link from "next/link";
import { requireUser } from "@/lib/auth";
import type { SearchParams } from "@/lib/issue-filters";
import { cn } from "@/lib/utils";
import { PageHeader } from "@/components/ui/misc";
import { IssueNavigator } from "@/components/issues/issue-navigator";
import { IssueModalSlot } from "@/components/issue/issue-modal";
import { getT } from "@/i18n/server";

export async function generateMetadata() {
  return { title: (await getT("nav"))("filters") };
}

const OPEN = "TODO,IN_PROGRESS,IN_REVIEW";

type PresetLabel = "presetMyOpen" | "presetReported" | "presetAll" | "presetOpen" | "presetCreated" | "presetResolved" | "presetOverdue" | "presetWatching";

const PRESETS: { id: string; label: PresetLabel; params: Record<string, string> }[] = [
  { id: "my-open", label: "presetMyOpen", params: { assignee: "me", status: OPEN } },
  { id: "reported", label: "presetReported", params: { reporter: "me" } },
  { id: "all", label: "presetAll", params: {} },
  { id: "open", label: "presetOpen", params: { status: OPEN } },
  { id: "created", label: "presetCreated", params: { created: "7" } },
  { id: "resolved", label: "presetResolved", params: { resolved: "7" } },
  { id: "overdue", label: "presetOverdue", params: { overdue: "1" } },
  { id: "watching", label: "presetWatching", params: { watching: "1" } },
];

const FILTER_KEYS = ["q", "status", "type", "assignee", "priority", "sprint", "label", "project", "reporter", "created", "resolved", "overdue", "watching"];

export default async function IssuesPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const user = await requireUser();
  const sp = await searchParams;
  const selected = Array.isArray(sp.selectedIssue) ? sp.selectedIssue[0] : sp.selectedIssue;
  const t = await getT("issueTable");
  const tn = await getT("nav");

  const current: Record<string, string> = {};
  for (const k of FILTER_KEYS) {
    const v = Array.isArray(sp[k]) ? sp[k]![0] : sp[k];
    if (v) current[k] = v as string;
  }
  const active = PRESETS.find((p) => {
    const keys = Object.keys(p.params);
    return keys.length === Object.keys(current).length && keys.every((k) => current[k] === p.params[k]);
  });

  return (
    <main className="flex min-w-0 flex-1 overflow-hidden">
      <aside className="hidden w-60 shrink-0 overflow-y-auto border-r border-line bg-surface-sunken px-2 py-5 lg:block">
        <div className="px-2 pb-2 text-[11px] font-bold uppercase text-ink-subtle">{t("presetsTitle")}</div>
        <nav className="flex flex-col gap-0.5">
          {PRESETS.map((p) => {
            const q = new URLSearchParams(p.params).toString();
            return (
              <Link
                key={p.id}
                href={q ? `/issues?${q}` : "/issues"}
                className={cn(
                  "flex h-9 items-center rounded-[3px] px-2 text-sm text-ink-muted hover:bg-tint-1",
                  active?.id === p.id && "bg-brand-50 font-medium text-brand-700 hover:bg-brand-50",
                )}
              >
                {t(p.label)}
              </Link>
            );
          })}
        </nav>
      </aside>
      <div className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-[1400px] px-8 py-6">
          <PageHeader title={active ? t(active.label) : t("searchTitle")} breadcrumbs={tn("filters")} />
          <IssueNavigator user={user} searchParams={sp} />
        </div>
      </div>
      <IssueModalSlot issueKey={selected} />
    </main>
  );
}
