import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { getIssueForUser } from "@/lib/access";
import { db } from "@/lib/db";
import { loadIssueDetail } from "@/lib/issue-detail-query";
import { IssueDetail } from "@/components/issue/issue-detail";
import { getT } from "@/i18n/server";

type Props = { params: Promise<{ issueKey: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { issueKey } = await params;
  const user = await getCurrentUser();
  const ref = user ? await getIssueForUser(decodeURIComponent(issueKey), user) : null;
  const t = await getT("issue");
  if (!ref) return { title: t("notFoundTitle") };
  const issue = await db.issue.findUnique({ where: { id: ref.id }, select: { key: true, title: true } });
  return { title: issue ? `[${issue.key}] ${issue.title}` : t("notFoundTitle") };
}

export default async function BrowseIssuePage({ params }: Props) {
  const { issueKey } = await params;
  const user = await requireUser();
  const data = await loadIssueDetail(decodeURIComponent(issueKey), user);
  if (!data) notFound();
  return (
    <main className="min-w-0 flex-1 overflow-y-auto">
      <div className="mx-auto max-w-[1200px] px-8 py-6">
        <IssueDetail key={data.issue.id} data={data} variant="page" />
      </div>
    </main>
  );
}
