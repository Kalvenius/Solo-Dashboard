import { getT } from "@/i18n/server";
import { LanguageSwitch, ThemeSwitch } from "@/components/layout/preferences";

export default async function AuthLayout({ children }: { children: React.ReactNode }) {
  const t = await getT("nav");
  return (
    <div className="relative flex min-h-full flex-col items-center justify-center bg-surface-sunken px-4 py-12">
      <div className="absolute right-4 top-4 flex items-center gap-2">
        <LanguageSwitch className="w-32" />
        <ThemeSwitch />
      </div>
      <div className="mb-6 flex items-center gap-2">
        <img src="/icon.svg" alt="" className="h-9 w-9" />
        <span className="text-2xl font-bold text-ink">Solo</span>
      </div>
      <div className="w-full max-w-[400px] rounded-[3px] bg-surface-raised px-10 py-8 shadow-overlay">{children}</div>
      <p className="mt-6 text-xs text-ink-subtle">{t("tagline")}</p>
    </div>
  );
}
