import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getT } from "@/i18n/server";
import { SetupForm } from "./setup-form";

// Bazadakı istifadəçi sayına görə yönləndirir — build zamanı statik yığılmamalıdır
export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("auth"))("setupTitle") };
}

export default async function SetupPage() {
  if ((await db.user.count()) > 0) redirect("/login");
  const t = await getT("auth");
  return (
    <>
      <h1 className="mb-1 text-center text-lg font-semibold text-ink">{t("welcome")}</h1>
      <p className="mb-6 text-center text-sm text-ink-subtle">{t("setupIntro")}</p>
      <SetupForm />
    </>
  );
}
