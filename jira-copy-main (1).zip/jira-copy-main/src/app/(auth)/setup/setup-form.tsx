"use client";

import { useActionState } from "react";
import { setupAction } from "@/lib/actions/auth";
import { useT } from "@/i18n/client";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input } from "@/components/ui/input";

export function SetupForm() {
  const [state, action, pending] = useActionState(setupAction, undefined);
  const t = useT("auth");
  return (
    <form action={action} className="space-y-4">
      <FormError message={state?.error} />
      <Field label={t("fullName")} htmlFor="name" required>
        <Input id="name" name="name" required autoFocus />
      </Field>
      <Field label={t("jobTitle")} htmlFor="title">
        <Input id="title" name="title" placeholder={t("jobTitlePlaceholder")} />
      </Field>
      <Field label={t("email")} htmlFor="email" required>
        <Input id="email" name="email" type="email" required />
      </Field>
      <Field label={t("password")} htmlFor="password" required hint={t("passwordHint")}>
        <Input id="password" name="password" type="password" required minLength={6} />
      </Field>
      <Button type="submit" variant="primary" className="h-10 w-full justify-center" loading={pending}>
        {t("createAccount")}
      </Button>
    </form>
  );
}
