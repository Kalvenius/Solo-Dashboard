"use client";

import { useActionState } from "react";
import { loginAction } from "@/lib/actions/auth";
import { useT } from "@/i18n/client";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input } from "@/components/ui/input";

export function LoginForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(loginAction, undefined);
  const t = useT("auth");
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="next" value={next ?? ""} />
      <FormError message={state?.error} />
      <Field label={t("email")} htmlFor="email">
        <Input id="email" name="email" type="email" autoComplete="email" required autoFocus placeholder={t("emailPlaceholder")} />
      </Field>
      <Field label={t("password")} htmlFor="password">
        <Input id="password" name="password" type="password" autoComplete="current-password" required />
      </Field>
      <Button type="submit" variant="primary" className="h-10 w-full justify-center" loading={pending}>
        {t("login")}
      </Button>
      <p className="text-center text-xs text-ink-subtle">{t("noAccount")}</p>
    </form>
  );
}
