import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { getT } from "@/i18n/server";
import { LoginForm } from "./login-form";

// Bazadakı istifadəçi sayına görə yönləndirir — build zamanı statik yığılmamalıdır
export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getT("auth"))("loginTitle") };
}

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  if ((await db.user.count()) === 0) redirect("/setup");
  if (await getCurrentUser()) redirect("/your-work");
  const { next } = await searchParams;
  const t = await getT("auth");
  return (
    <>
      <h1 className="mb-6 text-center text-base font-semibold text-ink-muted">{t("loginHeading")}</h1>
      <LoginForm next={next} />
    </>
  );
}
