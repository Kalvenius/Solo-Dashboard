import type { Metadata } from "next";
import { cookies } from "next/headers";
import { getLocale } from "@/i18n/server";
import { dictFor } from "@/i18n/server";
import { I18nProvider } from "@/i18n/client";
import { ThemeProvider } from "@/components/layout/theme";
import { THEME_COOKIE, isTheme, themeScript } from "@/lib/theme";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const locale = await getLocale();
  const description = dictFor(locale).nav.tagline;
  return {
    title: { default: "Solo", template: "%s · Solo" },
    description,
    icons: { icon: "/icon.svg" },
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await getLocale();
  const themeCookie = (await cookies()).get(THEME_COOKIE)?.value;
  const theme = isTheme(themeCookie) ? themeCookie : "system";

  return (
    <html lang={locale} className={theme === "dark" ? "dark" : undefined} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>
        <ThemeProvider initialTheme={theme}>
          <I18nProvider locale={locale} dict={dictFor(locale)}>
            {children}
          </I18nProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
