import Link from "next/link";
import { getT } from "@/i18n/server";

export default async function NotFound() {
  const t = await getT("common");
  return (
    <div className="flex min-h-full flex-col items-center justify-center px-6 py-20 text-center">
      <div className="text-6xl font-bold text-brand-600">404</div>
      <h1 className="mt-3 text-xl font-semibold text-ink">{t("notFoundTitle")}</h1>
      <p className="mt-1 text-sm text-ink-subtle">{t("notFoundText")}</p>
      <Link href="/your-work" className="mt-5 rounded-[3px] bg-brand-600 px-4 py-2 text-sm font-medium text-on-brand hover:bg-brand-700">
        {t("backHome")}
      </Link>
    </div>
  );
}
