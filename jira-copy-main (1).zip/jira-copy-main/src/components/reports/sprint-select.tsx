"use client";

import { useTransition } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useT } from "@/i18n/client";

export function SprintSelect({ sprints, value }: { sprints: { id: string; name: string; state: string }[]; value: string | null }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [pending, start] = useTransition();
  const t = useT("reports");
  if (!sprints.length) return null;
  return (
    <select
      aria-label={t("sprintSelect")}
      value={value ?? ""}
      disabled={pending}
      onChange={(e) => {
        const sp = new URLSearchParams(params.toString());
        sp.set("sprint", e.target.value);
        start(() => router.push(`${pathname}?${sp.toString()}`, { scroll: false }));
      }}
      className="h-7 cursor-pointer rounded-[3px] border-2 border-line bg-input px-1.5 pr-6 text-xs text-ink hover:bg-input-hover focus:border-brand-500 focus:outline-none disabled:opacity-60"
    >
      {sprints.map((s) => (
        <option key={s.id} value={s.id}>
          {s.name} ({s.state === "ACTIVE" ? t("stateActive") : s.state === "COMPLETED" ? t("stateCompleted") : s.state})
        </option>
      ))}
    </select>
  );
}
