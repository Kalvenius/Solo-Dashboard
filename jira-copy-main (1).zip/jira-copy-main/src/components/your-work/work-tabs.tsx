"use client";

import { useState } from "react";
import { isToday, subDays } from "date-fns";
import { Inbox } from "lucide-react";
import type { Status } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import { StatusLozenge } from "@/components/ui/lozenge";
import { EmptyState } from "@/components/ui/misc";
import { IssueTypeIcon } from "@/components/issue/icons";
import { useOpenIssue } from "@/components/issue/use-open-issue";

export type WorkRow = {
  id: string;
  key: string;
  title: string;
  type: string;
  status: string;
  updatedAt: Date;
  at: Date;
  project: { key: string; name: string; color: string };
};

type Tab = "worked" | "assigned" | "watching";

export function WorkTabs({ worked, assigned, watching }: { worked: WorkRow[]; assigned: WorkRow[]; watching: WorkRow[] }) {
  const [tab, setTab] = useState<Tab>(assigned.length && !worked.length ? "assigned" : "worked");
  const t = useT("yourWork");
  const te = useT("enums");

  const tabs: { id: Tab; label: string; count: number }[] = [
    { id: "worked", label: t("tabWorked"), count: worked.length },
    { id: "assigned", label: t("tabAssigned"), count: assigned.length },
    { id: "watching", label: t("tabWatching"), count: watching.length },
  ];

  let groups: { title: string; rows: WorkRow[] }[] = [];
  if (tab === "worked") {
    const weekAgo = subDays(new Date(), 7);
    groups = [
      { title: t("today"), rows: worked.filter((r) => isToday(r.at)) },
      { title: t("thisWeek"), rows: worked.filter((r) => !isToday(r.at) && r.at >= weekAgo) },
      { title: t("earlier"), rows: worked.filter((r) => r.at < weekAgo) },
    ];
  } else if (tab === "assigned") {
    groups = (["IN_PROGRESS", "IN_REVIEW", "TODO"] as Status[]).map((s) => ({ title: te(`status.${s}`), rows: assigned.filter((r) => r.status === s) }));
  } else {
    groups = [{ title: "", rows: watching }];
  }
  groups = groups.filter((g) => g.rows.length);

  return (
    <section>
      <div className="flex gap-4 border-b-2 border-line">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "-mb-[2px] flex items-center gap-1.5 border-b-2 pb-2 text-sm font-medium",
              tab === t.id ? "border-brand-600 text-brand-600" : "border-transparent text-ink-muted hover:text-ink",
            )}
          >
            {t.label}
            <span className={cn("rounded-full px-1.5 text-xs", tab === t.id ? "bg-brand-50 text-brand-700" : "bg-neutral text-ink-muted")}>{t.count}</span>
          </button>
        ))}
      </div>

      {groups.length === 0 ? (
        <EmptyState
          icon={<Inbox className="h-10 w-10" />}
          title={tab === "worked" ? t("emptyWorked") : tab === "assigned" ? t("emptyAssigned") : t("emptyWatching")}
          description={tab === "watching" ? t("emptyWatchingHint") : undefined}
        />
      ) : (
        groups.map((g) => (
          <div key={g.title} className="mt-4">
            {g.title && <h3 className="mb-1 text-xs font-bold uppercase text-ink-subtle">{g.title}</h3>}
            <ul>
              {g.rows.map((r) => (
                <Row key={r.id} row={r} showTouched={tab === "worked"} />
              ))}
            </ul>
          </div>
        ))
      )}
    </section>
  );
}

function Row({ row, showTouched }: { row: WorkRow; showTouched: boolean }) {
  const { open } = useOpenIssue();
  const f = useFormat();
  return (
    <li>
      <button onClick={() => open(row.key)} className="flex w-full items-center gap-3 rounded-[3px] px-2 py-2 text-left hover:bg-surface-hover">
        <IssueTypeIcon type={row.type} />
        <div className="min-w-0 flex-1">
          <div className={cn("truncate text-sm text-ink", row.status === "DONE" && "text-ink-subtle line-through")}>{row.title}</div>
          <div className="truncate text-xs text-ink-subtle">
            {row.key} · {row.project.name}
          </div>
        </div>
        <StatusLozenge status={row.status} />
        <span className="w-28 shrink-0 text-right text-xs text-ink-subtle" suppressHydrationWarning>{f.relative(showTouched ? row.at : row.updatedAt)}</span>
      </button>
    </li>
  );
}
