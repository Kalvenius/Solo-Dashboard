"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ChevronDown, ChevronRight, X } from "lucide-react";
import { STATUSES, type IssueType, type Status } from "@/lib/constants";
import type { IssueCardData } from "@/lib/issue-select";
import { moveIssue } from "@/lib/actions/board";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";
import { Avatar } from "@/components/ui/avatar";
import { Picker } from "@/components/ui/picker";
import { EpicTag, IssueTypeIcon } from "@/components/issue/icons";
import { useOpenIssue } from "@/components/issue/use-open-issue";
import { IssueCard } from "./issue-card";
import { QuickCreate } from "./quick-create";
import { AssigneeFilter, FilterTrigger, SearchBox, ToggleChip, type MemberLite } from "./filters";
import { isBelow, neighbors, normalize, preferItems, rankBetween } from "./dnd-utils";

type EpicLite = { id: string; key: string; title: string };
type GroupBy = "none" | "assignee" | "epic";

const SEP = "::";
const cid = (lane: string, status: string) => `${lane}${SEP}${status}`;
const parseCid = (c: string) => {
  const [lane, status] = c.split(SEP) as [string, Status];
  return { lane, status };
};

const epicIdOf = (i: IssueCardData) => (i.parent?.type === "EPIC" ? i.parent.id : "none");

export function Board({
  projectId,
  issues: serverIssues,
  members,
  epics,
  currentUserId,
  sprintId,
  isKanban,
}: {
  projectId: string;
  issues: IssueCardData[];
  members: MemberLite[];
  epics: EpicLite[];
  currentUserId: string;
  sprintId: string | null;
  isKanban: boolean;
}) {
  const { open } = useOpenIssue();
  const t = useT("board");
  const tc = useT("common");
  const te = useT("enums");
  const [issues, setIssuesState] = useState(serverIssues);
  const issuesRef = useRef(serverIssues);
  const setIssues = useCallback((next: IssueCardData[]) => {
    issuesRef.current = next;
    setIssuesState(next);
  }, []);
  const dragging = useRef(false);
  const snapshot = useRef<IssueCardData[] | null>(null);

  useEffect(() => {
    if (!dragging.current) setIssues(serverIssues);
  }, [serverIssues, setIssues]);

  // ---------- filtrlər ----------
  const [q, setQ] = useState("");
  const [assignees, setAssignees] = useState<Set<string>>(new Set());
  const [onlyMine, setOnlyMine] = useState(false);
  const [type, setType] = useState<string | null>(null);
  const [epic, setEpic] = useState<string | null>(null);
  const [groupBy, setGroupBy] = useState<GroupBy>("none");
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);

  const anyFilter = !!q || assignees.size > 0 || onlyMine || !!type || !!epic;
  const clearFilters = () => {
    setQ("");
    setAssignees(new Set());
    setOnlyMine(false);
    setType(null);
    setEpic(null);
  };

  const matches = useCallback(
    (i: IssueCardData) => {
      if (q && !normalize(`${i.key} ${i.title}`).includes(normalize(q))) return false;
      if (onlyMine && i.assignee?.id !== currentUserId) return false;
      if (assignees.size && !assignees.has(i.assignee?.id ?? "none")) return false;
      if (type && i.type !== type) return false;
      if (epic && epicIdOf(i) !== epic) return false;
      return true;
    },
    [q, onlyMine, assignees, type, epic, currentUserId],
  );

  const laneOf = useCallback(
    (i: IssueCardData) => (groupBy === "assignee" ? (i.assignee?.id ?? "none") : groupBy === "epic" ? epicIdOf(i) : "all"),
    [groupBy],
  );

  /** Verilmiş siyahıdan sütunları hesablayır (sürükləmə zamanı ən son lokal vəziyyət üçün) */
  const columnsFrom = useCallback(
    (list: IssueCardData[]) => {
      const map: Record<string, string[]> = {};
      for (const i of list.filter(matches).sort((a, b) => a.rank - b.rank)) (map[cid(laneOf(i), i.status)] ??= []).push(i.id);
      return map;
    },
    [matches, laneOf],
  );

  // Sətirlər server məlumatından hesablanır ki, sürükləmə zamanı sətir yox olmasın
  const lanes = useMemo(() => {
    if (groupBy === "none") return [{ id: "all", label: null as React.ReactNode, count: 0 }];
    const visible = serverIssues.filter(matches);
    const ids = new Set(visible.map(laneOf));
    const counts = new Map<string, number>();
    for (const i of issues.filter(matches)) counts.set(laneOf(i), (counts.get(laneOf(i)) ?? 0) + 1);
    const out: { id: string; label: React.ReactNode; count: number }[] = [];
    if (groupBy === "assignee") {
      const people = new Map<string, MemberLite>();
      for (const i of visible) if (i.assignee) people.set(i.assignee.id, i.assignee);
      const sorted = Array.from(people.values()).sort((a, b) =>
        a.id === currentUserId ? -1 : b.id === currentUserId ? 1 : a.name.localeCompare(b.name, "az"),
      );
      for (const p of sorted)
        out.push({
          id: p.id,
          label: (
            <span className="flex items-center gap-2">
              <Avatar user={p} size="sm" />
              {p.name}
            </span>
          ),
          count: counts.get(p.id) ?? 0,
        });
      if (ids.has("none"))
        out.push({
          id: "none",
          label: (
            <span className="flex items-center gap-2">
              <Avatar user={null} size="sm" />
              {tc("unassigned")}
            </span>
          ),
          count: counts.get("none") ?? 0,
        });
    } else {
      for (const e of epics)
        if (ids.has(e.id))
          out.push({
            id: e.id,
            label: (
              <span className="flex items-center gap-2">
                <IssueTypeIcon type="EPIC" />
                <span className="text-xs font-semibold text-ink-subtle">{e.key}</span>
                {e.title}
              </span>
            ),
            count: counts.get(e.id) ?? 0,
          });
      if (ids.has("none")) out.push({ id: "none", label: <span className="text-ink-muted">{t("issuesWithoutEpic")}</span>, count: counts.get("none") ?? 0 });
    }
    return out;
  }, [groupBy, serverIssues, issues, matches, laneOf, epics, currentUserId, t, tc]);

  // container id → sıralanmış tapşırıq id-ləri
  const columns = useMemo(() => {
    const map: Record<string, string[]> = {};
    for (const lane of lanes) for (const s of STATUSES) map[cid(lane.id, s)] = [];
    const sorted = issues.filter(matches).sort((a, b) => a.rank - b.rank);
    for (const i of sorted) {
      const key = cid(laneOf(i), i.status);
      (map[key] ??= []).push(i.id);
    }
    return map;
  }, [issues, lanes, matches, laneOf]);

  const byId = useMemo(() => new Map(issues.map((i) => [i.id, i])), [issues]);

  // ---------- sürükləmə ----------
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const collision = useMemo(() => preferItems((id) => String(id).includes(SEP)), []);

  const findContainer = (id: string): string | null => {
    if (id.includes(SEP)) return id;
    const issue = issuesRef.current.find((i) => i.id === id);
    return issue ? cid(laneOf(issue), issue.status) : null;
  };

  /** Lokal tapşırığı yeni sütun/sətrə köçürür */
  const relocate = (id: string, container: string, rank: number) => {
    const { lane, status } = parseCid(container);
    const next = issuesRef.current.map((i) => {
      if (i.id !== id) return i;
      const moved: IssueCardData = { ...i, status, rank };
      if (groupBy === "assignee" && lane !== (i.assignee?.id ?? "none")) {
        moved.assignee = lane === "none" ? null : (members.find((m) => m.id === lane) ?? i.assignee);
      }
      if (groupBy === "epic" && lane !== epicIdOf(i)) {
        const e = epics.find((x) => x.id === lane);
        moved.parent = e ? { id: e.id, key: e.key, title: e.title, type: "EPIC" } : null;
        moved.parentId = e?.id ?? null;
      }
      return moved;
    });
    setIssues(next);
  };

  const rankOf = (id: string | undefined) => (id ? issuesRef.current.find((i) => i.id === id)?.rank : undefined);

  const onDragStart = (e: DragStartEvent) => {
    dragging.current = true;
    snapshot.current = issuesRef.current;
    setActiveId(String(e.active.id));
    setError(null);
  };

  const onDragOver = ({ active, over }: DragOverEvent) => {
    if (!over) return;
    const activeC = findContainer(String(active.id));
    let overC = findContainer(String(over.id));
    if (!activeC || !overC || activeC === overC) return;
    const issue = issuesRef.current.find((i) => i.id === active.id);
    if (!issue) return;
    // alt tapşırıqları epic sətirləri arasında köçürmək olmaz (valideyni story-dir)
    if (groupBy === "epic" && issue.type === "SUBTASK" && parseCid(overC).lane !== parseCid(activeC).lane) {
      overC = cid(parseCid(activeC).lane, parseCid(overC).status);
      if (overC === activeC) return;
    }
    const list = (columnsFrom(issuesRef.current)[overC] ?? []).filter((x) => x !== active.id);
    let index = list.length;
    if (!String(over.id).includes(SEP)) {
      const overIndex = list.indexOf(String(over.id));
      if (overIndex >= 0) index = overIndex + (isBelow(active, over) ? 1 : 0);
    }
    relocate(issue.id, overC, rankBetween(rankOf(list[index - 1]), rankOf(list[index])));
  };

  const revert = () => {
    if (snapshot.current) setIssues(snapshot.current);
  };

  const onDragEnd = async ({ active, over }: DragEndEvent) => {
    setActiveId(null);
    const id = String(active.id);
    const before = snapshot.current?.find((i) => i.id === id);
    if (!over || !before) {
      revert();
      dragging.current = false;
      return;
    }

    const container = findContainer(id)!;
    let list = (columnsFrom(issuesRef.current)[container] ?? []).slice();
    if (!list.includes(id)) list.push(id);
    const overId = String(over.id);
    if (!overId.includes(SEP) && overId !== id && list.includes(overId)) {
      list = arrayMove(list, list.indexOf(id), list.indexOf(overId));
      const idx = list.indexOf(id);
      relocate(id, container, rankBetween(rankOf(list[idx - 1]), rankOf(list[idx + 1])));
    }

    const after = issuesRef.current.find((i) => i.id === id)!;
    const statusChanged = after.status !== before.status;
    const assigneeChanged = (after.assignee?.id ?? null) !== (before.assignee?.id ?? null);
    const parentChanged = (after.parentId ?? null) !== (before.parentId ?? null);
    const { beforeId, afterId } = neighbors(list, id);
    const origList = Object.values(columnsFrom(snapshot.current!)).find((l) => l.includes(id)) ?? [];
    const orig = neighbors(origList, id);
    const orderChanged = statusChanged || assigneeChanged || parentChanged || orig.beforeId !== beforeId || orig.afterId !== afterId;
    dragging.current = false;
    if (!orderChanged) return;

    const res = await moveIssue(id, {
      status: statusChanged ? after.status : undefined,
      assigneeId: assigneeChanged ? (after.assignee?.id ?? null) : undefined,
      parentId: parentChanged ? (after.parentId ?? null) : undefined,
      beforeId,
      afterId,
    });
    if (!res.ok) {
      revert();
      setError(res.error);
    }
  };

  const activeIssue = activeId ? byId.get(activeId) : null;
  const doneCutoffHint = isKanban ? t("doneHint") : null;

  // ---------- render ----------
  const typeOptions = (["STORY", "TASK", "BUG", "SUBTASK"] as IssueType[]).map((tp) => ({ value: tp, label: te(`type.${tp}`), icon: <IssueTypeIcon type={tp} /> }));
  const epicOptions = [{ value: "none", label: t("noEpic") }, ...epics.map((e) => ({ value: e.id, label: e.title, icon: <IssueTypeIcon type="EPIC" />, hint: e.key }))];
  const groupOptions = [
    { value: "none", label: t("groupNone") },
    { value: "assignee", label: tc("assignee") },
    { value: "epic", label: tc("epic") },
  ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* Filtr paneli */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <SearchBox value={q} onChange={setQ} placeholder={t("searchBoard")} />
        <AssigneeFilter
          members={members}
          selected={assignees}
          onToggle={(id) =>
            setAssignees((prev) => {
              const n = new Set(prev);
              if (n.has(id)) n.delete(id);
              else n.add(id);
              return n;
            })
          }
        />
        <ToggleChip active={onlyMine} onClick={() => setOnlyMine((v) => !v)}>
          {t("onlyMine")}
        </ToggleChip>
        <Picker
          options={typeOptions}
          value={type}
          onChange={setType}
          emptyLabel={t("allTypes")}
          renderTrigger={(sel) => <FilterTrigger label={tc("type")} value={sel?.label} active={!!type} />}
        />
        {epics.length > 0 && (
          <Picker
            options={epicOptions}
            value={epic}
            onChange={setEpic}
            emptyLabel={t("allEpics")}
            searchable
            renderTrigger={(sel) => <FilterTrigger label={tc("epic")} value={sel?.label} active={!!epic} />}
          />
        )}
        {anyFilter && (
          <button onClick={clearFilters} className="inline-flex h-8 items-center gap-1 px-2 text-sm text-ink-muted hover:text-ink">
            <X className="h-3.5 w-3.5" /> {t("clearFilters")}
          </button>
        )}
        <div className="ml-auto">
          <Picker
            align="right"
            options={groupOptions}
            value={groupBy}
            onChange={(v) => {
              setGroupBy((v as GroupBy) ?? "none");
              setCollapsed(new Set());
            }}
            renderTrigger={(sel) => <FilterTrigger label={t("groupBy")} value={sel?.label} active={groupBy !== "none"} />}
          />
        </div>
      </div>

      {error && (
        <div className="mb-3 flex items-center justify-between rounded-[3px] border border-danger-border bg-danger-subtle px-3 py-2 text-sm text-danger">
          {error}
          <button onClick={() => setError(null)} aria-label={tc("close")}>
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      <DndContext
        id="board-dnd"
        sensors={sensors}
        collisionDetection={collision}
        onDragStart={onDragStart}
        onDragOver={onDragOver}
        onDragEnd={onDragEnd}
        onDragCancel={() => {
          revert();
          dragging.current = false;
          setActiveId(null);
        }}
      >
        <div className="min-h-0 flex-1 overflow-x-auto pb-4">
          <div className="inline-flex min-w-full flex-col">
            {groupBy !== "none" && (
              <div className="sticky top-0 z-10 flex gap-2 bg-surface pb-2">
                {STATUSES.map((s) => (
                  <ColumnHeader key={s} status={s} count={issues.filter((i) => i.status === s && matches(i)).length} hint={s === "DONE" ? doneCutoffHint : null} />
                ))}
              </div>
            )}

            {groupBy !== "none" && lanes.length === 0 && (
              <div className="rounded-[3px] bg-surface-column px-4 py-10 text-center text-sm text-ink-subtle">{t("noMatches")}</div>
            )}

            {lanes.map((lane) => {
              const isCollapsed = collapsed.has(lane.id);
              return (
                <div key={lane.id} className={cn(groupBy !== "none" && "mb-2")}>
                  {groupBy !== "none" && (
                    <button
                      onClick={() =>
                        setCollapsed((prev) => {
                          const n = new Set(prev);
                          if (n.has(lane.id)) n.delete(lane.id);
                          else n.add(lane.id);
                          return n;
                        })
                      }
                      className="mb-1 flex w-full items-center gap-2 rounded-[3px] px-1 py-1.5 text-left text-sm font-medium text-ink hover:bg-surface-hover"
                    >
                      {isCollapsed ? <ChevronRight className="h-4 w-4 text-ink-subtle" /> : <ChevronDown className="h-4 w-4 text-ink-subtle" />}
                      {lane.label}
                      <span className="text-xs font-normal text-ink-subtle">{t("laneCount", { n: lane.count })}</span>
                    </button>
                  )}
                  {!isCollapsed && (
                    <div className="flex gap-2">
                      {STATUSES.map((s) => {
                        const container = cid(lane.id, s);
                        const ids = columns[container] ?? [];
                        return (
                          <Column
                            key={container}
                            id={container}
                            status={s}
                            ids={ids}
                            byId={byId}
                            activeId={activeId}
                            onOpen={open}
                            showHeader={groupBy === "none"}
                            tall={groupBy === "none"}
                            hint={s === "DONE" ? doneCutoffHint : null}
                            footer={
                              s === "TODO" && groupBy === "none" ? (
                                <QuickCreate projectId={projectId} defaults={{ sprintId, status: "TODO" }} types={["STORY", "TASK", "BUG"]} />
                              ) : null
                            }
                          />
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <DragOverlay dropAnimation={{ duration: 180, easing: "cubic-bezier(0.2, 0, 0, 1)" }}>
          {activeIssue ? (
            <div className="w-[270px]">
              <IssueCard issue={activeIssue} overlay />
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
    </div>
  );
}

function ColumnHeader({ status, count, hint }: { status: Status; count: number; hint?: string | null }) {
  const te = useT("enums");
  return (
    <div className="flex w-[270px] shrink-0 items-center gap-2 rounded-t-[3px] bg-surface-column px-3 pb-1 pt-3 text-xs font-semibold uppercase tracking-wide text-ink-subtle">
      <span className="truncate">{te(`status.${status}`)}</span>
      <span className="font-normal normal-case">{count}</span>
      {status === "DONE" && <span className="text-success-bold">✓</span>}
      {hint && <span className="ml-auto font-normal normal-case text-ink-faint">{hint}</span>}
    </div>
  );
}

function Column({
  id,
  status,
  ids,
  byId,
  activeId,
  onOpen,
  showHeader,
  tall,
  hint,
  footer,
}: {
  id: string;
  status: Status;
  ids: string[];
  byId: Map<string, IssueCardData>;
  activeId: string | null;
  onOpen: (key: string) => void;
  showHeader: boolean;
  tall: boolean;
  hint?: string | null;
  footer?: React.ReactNode;
}) {
  const { setNodeRef, isOver } = useDroppable({ id });
  const te = useT("enums");
  return (
    <div className={cn("flex w-[270px] shrink-0 flex-col rounded-[3px] bg-surface-column", showHeader ? "" : "rounded-t-none")}>
      {showHeader && (
        <div className="flex items-center gap-2 px-3 pb-1 pt-3 text-xs font-semibold uppercase tracking-wide text-ink-subtle">
          <span className="truncate">{te(`status.${status}`)}</span>
          <span className="font-normal normal-case">{ids.length}</span>
          {status === "DONE" && <span className="text-success-bold">✓</span>}
          {hint && <span className="ml-auto font-normal normal-case text-ink-faint">{hint}</span>}
        </div>
      )}
      <div
        ref={setNodeRef}
        className={cn(
          "flex flex-1 flex-col gap-1.5 p-1.5 transition-colors",
          tall ? "min-h-[calc(100vh-290px)]" : "min-h-[72px]",
          isOver && "bg-brand-50 ring-2 ring-inset ring-brand-200",
          "rounded-[3px]",
        )}
      >
        <SortableContext id={id} items={ids} strategy={verticalListSortingStrategy}>
          {ids.map((iid) => {
            const issue = byId.get(iid);
            return issue ? <SortableCard key={iid} issue={issue} onOpen={onOpen} hidden={activeId === iid} /> : null;
          })}
        </SortableContext>
        {footer}
      </div>
    </div>
  );
}

function SortableCard({ issue, onOpen, hidden }: { issue: IssueCardData; onOpen: (key: string) => void; hidden: boolean }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: issue.id });
  return (
    <div ref={setNodeRef} style={{ transform: CSS.Translate.toString(transform), transition }} {...attributes} {...listeners}>
      <IssueCard issue={issue} onOpen={onOpen} dragging={hidden} />
    </div>
  );
}
