"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { Plus } from "lucide-react";
import type { IssueType } from "@/lib/constants";
import { quickCreateIssue, type QuickCreateInput } from "@/lib/actions/board";
import { cn } from "@/lib/utils";
import { IssueTypeIcon } from "@/components/issue/icons";
import { Picker } from "@/components/ui/picker";
import { useT } from "@/i18n/client";

/**
 * "+ Yarat" sətri: klikləyəndə input açılır, Enter ilə tapşırıq yaranır, Esc bağlayır.
 * Lövhənin "Görüləcək" sütununda və backlog bölmələrində istifadə olunur.
 */
export function QuickCreate({
  projectId,
  defaults,
  types = ["STORY", "TASK", "BUG"],
  defaultType = "TASK",
  label,
  variant = "board",
  onCreated,
}: {
  projectId: string;
  defaults?: Omit<QuickCreateInput, "title" | "type">;
  types?: IssueType[];
  defaultType?: IssueType;
  label?: string;
  variant?: "board" | "row";
  onCreated?: (key: string) => void;
}) {
  const t = useT("board");
  const tc = useT("common");
  const te = useT("enums");
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [type, setType] = useState<string>(defaultType);
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const inputRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef(title);
  titleRef.current = title;

  // kənara klikləyəndə (və mətn boşdursa) bağlanır
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node) && !titleRef.current.trim()) {
        setOpen(false);
        setError(null);
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  const submit = () => {
    const text = title.trim();
    if (!text || pending) return;
    startTransition(async () => {
      setError(null);
      const res = await quickCreateIssue(projectId, { ...defaults, title: text, type });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      setTitle("");
      onCreated?.(res.data!.key);
      requestAnimationFrame(() => inputRef.current?.focus());
    });
  };

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "flex w-full items-center gap-1.5 rounded-[3px] px-2 text-left text-sm font-medium text-ink-muted hover:bg-tint-1",
          variant === "board" ? "h-9" : "h-10",
        )}
      >
        <Plus className="h-4 w-4" /> {label ?? tc("create")}
      </button>
    );
  }

  return (
    <div ref={boxRef} className={cn("rounded-[3px] border-2 border-brand-500 bg-surface-raised", variant === "board" ? "p-2" : "px-2 py-1")}>
      <div className="flex items-center gap-2">
        <Picker
          value={type}
          onChange={(v) => v && setType(v)}
          options={types.map((tp) => ({ value: tp, label: te(`type.${tp}`), icon: <IssueTypeIcon type={tp} /> }))}
          renderTrigger={() => (
            <span className="inline-flex h-7 items-center rounded-[3px] px-1 hover:bg-surface-hover" title={tc("type")}>
              <IssueTypeIcon type={type} />
            </span>
          )}
        />
        <input
          ref={inputRef}
          autoFocus
          value={title}
          disabled={pending}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              submit();
            } else if (e.key === "Escape") {
              setOpen(false);
              setTitle("");
              setError(null);
            }
          }}
          placeholder={t("quickCreatePlaceholder")}
          className="h-7 min-w-0 flex-1 bg-transparent text-sm text-ink placeholder:text-ink-faint focus:outline-none"
        />
        {pending && <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />}
      </div>
      {error ? (
        <p className="mt-1 text-xs text-danger">{error}</p>
      ) : (
        <p className="mt-1 text-[11px] text-ink-subtle">{t("quickCreateHint")}</p>
      )}
    </div>
  );
}
