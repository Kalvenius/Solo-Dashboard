import {
  closestCenter,
  closestCorners,
  pointerWithin,
  rectIntersection,
  type Active,
  type CollisionDetection,
  type Over,
  type UniqueIdentifier,
} from "@dnd-kit/core";

/** İki qonşu arasında sıra dəyəri (server tərəfindəki computeRank ilə eyni məntiq) */
export function rankBetween(prev: number | undefined, next: number | undefined) {
  if (prev !== undefined && next !== undefined) return (prev + next) / 2;
  if (prev !== undefined) return prev + 1000;
  if (next !== undefined) return next - 1000;
  return 1000;
}

/** Sürüklənən element üzərində olduğu elementin altına düşürmü (dnd-kit multi-container nümunəsi) */
export function isBelow(active: Active, over: Over) {
  const translated = active.rect.current.translated;
  return !!translated && translated.top > over.rect.top + over.rect.height / 2;
}

/** Qonşuları tapır: siyahıda id-dən əvvəlki və sonrakı */
export function neighbors(list: string[], id: string) {
  const i = list.indexOf(id);
  return { beforeId: i > 0 ? list[i - 1]! : null, afterId: i >= 0 && i < list.length - 1 ? list[i + 1]! : null };
}

export const normalize = (s: string) => s.toLocaleLowerCase("az");


/**
 * Kursor altındakı kartlara üstünlük verən toqquşma strategiyası.
 * Kart üzərindədirsə — ən yaxın kart, boş sahədədirsə — konteyner (sona əlavə).
 */
export function preferItems(isContainer: (id: UniqueIdentifier) => boolean): CollisionDetection {
  return (args) => {
    const pointer = pointerWithin(args);
    const hits = pointer.length ? pointer : rectIntersection(args);
    const itemHits = hits.filter((h) => !isContainer(h.id));
    if (itemHits.length) {
      const ids = new Set(itemHits.map((h) => h.id));
      return closestCenter({ ...args, droppableContainers: args.droppableContainers.filter((c) => ids.has(c.id)) });
    }
    return hits.length ? hits : closestCorners(args);
  };
}
