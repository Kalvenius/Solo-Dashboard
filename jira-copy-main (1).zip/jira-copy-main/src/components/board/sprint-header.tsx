"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { CompleteSprintModal } from "@/components/backlog/sprint-modals";
import { useT } from "@/i18n/client";

/** Lövhə başlığında "Sprinti tamamla" düyməsi + modal */
export function CompleteSprintButton({
  projectKey,
  sprint,
  doneCount,
  openCount,
  plannedSprints,
}: {
  projectKey: string;
  sprint: { id: string; name: string };
  doneCount: number;
  openCount: number;
  plannedSprints: { id: string; name: string }[];
}) {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const t = useT("board");
  return (
    <>
      <Button onClick={() => setOpen(true)}>{t("completeSprint")}</Button>
      <CompleteSprintModal
        open={open}
        onClose={() => setOpen(false)}
        sprint={sprint}
        doneCount={doneCount}
        openCount={openCount}
        plannedSprints={plannedSprints}
        onCompleted={() => router.push(`/projects/${projectKey}/backlog`)}
      />
    </>
  );
}
