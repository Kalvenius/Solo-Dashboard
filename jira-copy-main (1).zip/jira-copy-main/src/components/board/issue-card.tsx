"use client";

import { CalendarDays, ListTree } from "lucide-react";
import { startOfToday } from "date-fns";
import type { IssueCardData } from "@/lib/issue-select";
import { cn, parseLabels } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import { Avatar } from "@/components/ui/avatar";
import { EpicTag, IssueTypeIcon, PointsBadge, PriorityIcon } from "@/components/issue/icons";

export function isOverdue(issue: Pick<IssueCardData, "dueDate" | "status">) {
  return !!issue.dueDate && issue.status !== "DONE" && new Date(issue.dueDate) < startOfToday();
}

/** Lövhə kartı (Jira görünüşü) */
export function IssueCard({
  issue,
  onOpen,
  dragging,
  overlay,
}: {
  issue: IssueCardData;
  onOpen?: (key: string) => void;
  dragging?: boolean;
  overlay?: boolean;
}) {
  const t = useT("board");
  const f = useFormat();
  const labels = parseLabels(issue.labels);
  const done = issue.status === "DONE";
  const overdue = isOverdue(issue);
  const epic = issue.parent?.type === "EPIC" ? issue.parent : null;
  const parentOfSub = issue.type === "SUBTASK" && issue.parent ? issue.parent : null;

  return (
    <div
      role="button"
      tabIndex={-1}
      onClick={() => onOpen?.(issue.key)}
      className={cn(
        "group cursor-pointer select-none rounded-[3px] bg-surface-raised p-3 text-left shadow-card transition-colors hover:bg-surface-hover",
        dragging && "opacity-40",
        overlay && "rotate-[1.5deg] cursor-grabbing shadow-overlay",
      )}
    >
      <div className={cn("break-words text-sm text-ink", done && "text-ink-muted")}>{issue.title}</div>

      {(epic || parentOfSub || labels.length > 0) && (
        <div className="mt-2 flex flex-wrap items-center gap-1">
          {epic && <EpicTag title={epic.title} />}
          {parentOfSub && (
            <span className="rounded-[3px] bg-tint-1 px-1.5 text-[11px] font-semibold leading-5 text-ink-muted" title={parentOfSub.title}>
              ↳ {parentOfSub.key}
            </span>
          )}
          {labels.slice(0, 2).map((l) => (
            <span key={l} className="max-w-[110px] truncate rounded-[3px] border border-line px-1 text-[11px] leading-[18px] text-ink-muted">
              {l}
            </span>
          ))}
          {labels.length > 2 && <span className="text-[11px] text-ink-subtle">+{labels.length - 2}</span>}
        </div>
      )}

      {issue.dueDate && !done && (
        <div className={cn("mt-2 inline-flex items-center gap-1 rounded-[3px] px-1 text-[11px] font-semibold", overdue ? "bg-danger-subtle text-danger" : "text-ink-subtle")}>
          <CalendarDays className="h-3 w-3" />
          {f.date(issue.dueDate)}
        </div>
      )}

      <div className="mt-2.5 flex items-center gap-1.5">
        <IssueTypeIcon type={issue.type} />
        <span className={cn("text-xs font-semibold text-ink-subtle", done && "line-through")}>{issue.key}</span>
        <div className="ml-auto flex items-center gap-1.5">
          {issue.type !== "SUBTASK" && issue._count.children > 0 && (
            <span className="inline-flex items-center gap-0.5 text-[11px] text-ink-subtle" title={t("subtaskCount", { n: issue._count.children })}>
              <ListTree className="h-3.5 w-3.5" />
              {issue._count.children}
            </span>
          )}
          <PriorityIcon priority={issue.priority} />
          <PointsBadge points={issue.storyPoints} />
          <Avatar user={issue.assignee} size="sm" />
        </div>
      </div>
    </div>
  );
}
