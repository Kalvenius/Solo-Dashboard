"use client";

import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { useT } from "@/i18n/client";

export type MemberLite = { id: string; name: string; avatarColor: string };

export function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  const tc = useT("common");
  return (
    <div className="relative">
      <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-subtle" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder ?? tc("search")}
        className="h-8 w-44 rounded-[3px] border-2 border-line bg-surface-raised pl-8 pr-7 text-sm text-ink placeholder:text-ink-faint focus:border-brand-500 focus:outline-none"
      />
      {value && (
        <button onClick={() => onChange("")} className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-0.5 text-ink-subtle hover:bg-surface-hover" aria-label={tc("clear")}>
          <X className="h-3.5 w-3.5" />
        </button>
      )}
    </div>
  );
}

/** Jira-dakı kimi üst-üstə düzülmüş klikləmə ilə seçilən avatarlar. "none" = təyin edilməyənlər. */
export function AssigneeFilter({
  members,
  selected,
  onToggle,
  max = 8,
}: {
  members: MemberLite[];
  selected: Set<string>;
  onToggle: (id: string) => void;
  max?: number;
}) {
  const shown = members.slice(0, max);
  const tc = useT("common");
  return (
    <div className="flex items-center pl-1">
      {shown.map((m) => (
        <button
          key={m.id}
          type="button"
          onClick={() => onToggle(m.id)}
          title={m.name}
          className={cn(
            "-ml-1 rounded-full ring-2 transition-transform hover:z-10 hover:-translate-y-0.5",
            selected.has(m.id) ? "z-10 ring-brand-600" : "ring-surface",
          )}
        >
          <Avatar user={m} size="md" title={m.name} />
        </button>
      ))}
      <button
        type="button"
        onClick={() => onToggle("none")}
        title={tc("unassigned")}
        className={cn(
          "-ml-1 rounded-full ring-2 transition-transform hover:z-10 hover:-translate-y-0.5",
          selected.has("none") ? "z-10 ring-brand-600" : "ring-surface",
        )}
      >
        <Avatar user={null} size="md" title={tc("unassigned")} />
      </button>
    </div>
  );
}

export function ToggleChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex h-8 items-center gap-1 rounded-[3px] px-2.5 text-sm font-medium transition-colors",
        active ? "bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200" : "bg-transparent text-ink-muted hover:bg-tint-1",
      )}
    >
      {children}
    </button>
  );
}

export function FilterTrigger({ label, value, active }: { label: string; value?: string; active?: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex h-8 items-center gap-1 rounded-[3px] px-2.5 text-sm font-medium",
        active ? "bg-brand-50 text-brand-700 ring-1 ring-inset ring-brand-200" : "text-ink-muted hover:bg-tint-1",
      )}
    >
      <span className="flex max-w-[200px] items-center">
        {label}
        {value && <span className="truncate font-normal">: {value}</span>}
      </span>
      <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
        <path d="m4 6 4 4 4-4" />
      </svg>
    </span>
  );
}
