import { db } from "@/lib/db";
import type { CurrentUser } from "@/lib/auth";
import { accessibleProjectIds } from "@/lib/access";
import { buildIssueWhere, distinctLabels, parseIssueFilters, queryIssues, type SearchParams } from "@/lib/issue-filters";
import { FilterBar, type FilterOptions } from "./filter-bar";
import { IssueTable } from "./issue-table";

/** Filtr paneli + tapşırıq cədvəli. project verilsə layihə səhifəsi, yoxsa qlobal "Filtrlər" səhifəsi. */
export async function IssueNavigator({
  user,
  searchParams,
  project,
}: {
  user: CurrentUser;
  searchParams: SearchParams;
  project?: { id: string; key: string; members: { user: { id: string; name: string; avatarColor: string } }[] };
}) {
  const f = parseIssueFilters(searchParams);
  const where = await buildIssueWhere(f, user, project?.id);
  const scopeWhere = project ? { projectId: project.id } : await buildIssueWhere(parseIssueFilters({}), user);

  const [result, labels, extra] = await Promise.all([
    queryIssues(where, f),
    distinctLabels(scopeWhere),
    project ? loadProjectOptions(project.id) : loadGlobalOptions(user),
  ]);

  const users = project ? project.members.map((m) => m.user) : (extra as GlobalOptions).users;
  const options: FilterOptions = {
    me: { id: user.id, name: user.name, avatarColor: user.avatarColor },
    users: users.slice().sort((a, b) => a.name.localeCompare(b.name, "az")),
    labels,
    ...(project ? { sprints: (extra as ProjectOptions).sprints } : { projects: (extra as GlobalOptions).projects }),
  };

  const exportParams = new URLSearchParams();
  for (const [k, v] of Object.entries(searchParams)) {
    const val = Array.isArray(v) ? v[0] : v;
    if (val && k !== "selectedIssue" && k !== "page") exportParams.set(k, val);
  }
  if (project) exportParams.set("project", project.key);

  return (
    <>
      <FilterBar options={options} exportHref={`/api/issues/export?${exportParams.toString()}`} />
      <IssueTable
        rows={result.rows}
        total={result.total}
        page={result.page}
        pageSize={result.pageSize}
        pageCount={result.pageCount}
        sort={f.sort}
        dir={f.dir}
        mode={project ? "project" : "global"}
      />
    </>
  );
}

type ProjectOptions = { sprints: { id: string; name: string; state: string }[] };
type GlobalOptions = { users: { id: string; name: string; avatarColor: string }[]; projects: { key: string; name: string; color: string }[] };

async function loadProjectOptions(projectId: string): Promise<ProjectOptions> {
  const sprints = await db.sprint.findMany({
    where: { projectId },
    select: { id: true, name: true, state: true },
    orderBy: { createdAt: "desc" },
  });
  return { sprints };
}

async function loadGlobalOptions(user: CurrentUser): Promise<GlobalOptions> {
  const ids = await accessibleProjectIds(user);
  const [projects, users] = await Promise.all([
    db.project.findMany({ where: ids === null ? {} : { id: { in: ids } }, select: { key: true, name: true, color: true }, orderBy: { name: "asc" } }),
    db.user.findMany({
      where: ids === null ? {} : { memberships: { some: { projectId: { in: ids } } } },
      select: { id: true, name: true, avatarColor: true },
    }),
  ]);
  return { projects, users };
}
