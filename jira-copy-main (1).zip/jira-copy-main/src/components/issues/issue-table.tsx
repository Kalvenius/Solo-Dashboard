"use client";

import Link from "next/link";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight } from "lucide-react";
import { cn, parseLabels } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import { Avatar } from "@/components/ui/avatar";
import { StatusLozenge } from "@/components/ui/lozenge";
import { EmptyState, ProjectAvatar } from "@/components/ui/misc";
import { IssueTypeIcon, PointsBadge, PriorityIcon } from "@/components/issue/icons";
import { useOpenIssue } from "@/components/issue/use-open-issue";
import { useQueryParams } from "./use-query-params";

export type IssueTableRow = {
  id: string;
  key: string;
  title: string;
  type: string;
  status: string;
  priority: string;
  storyPoints: number | null;
  dueDate: Date | null;
  labels: string;
  createdAt: Date;
  updatedAt: Date;
  assignee: { id: string; name: string; avatarColor: string } | null;
  parent: { key: string; title: string; type: string } | null;
  sprint: { id: string; name: string; state: string } | null;
  project: { key: string; name: string; color: string };
};

type Col = { id: string; label: string; sort?: string; className?: string };

export function IssueTable({
  rows,
  total,
  page,
  pageSize,
  pageCount,
  sort,
  dir,
  mode,
}: {
  rows: IssueTableRow[];
  total: number;
  page: number;
  pageSize: number;
  pageCount: number;
  sort: string;
  dir: "asc" | "desc";
  mode: "project" | "global";
}) {
  const { open } = useOpenIssue();
  const { set } = useQueryParams();
  const t = useT("issueTable");
  const tc = useT("common");
  const f = useFormat();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const cols: Col[] = [
    { id: "type", label: t("colType"), className: "w-10" },
    { id: "key", label: t("colKey"), sort: "key", className: "w-24" },
    { id: "title", label: t("colTitle"), sort: "title", className: "min-w-[240px]" },
    { id: "status", label: tc("status"), sort: "status", className: "w-28" },
    { id: "assignee", label: tc("assignee"), sort: "assignee", className: "w-40" },
    { id: "priority", label: tc("priority"), sort: "priority", className: "w-20" },
    mode === "project" ? { id: "sprint", label: tc("sprint"), className: "w-36" } : { id: "project", label: t("colProject"), className: "w-40" },
    { id: "points", label: t("colPoints"), className: "w-12 text-center" },
    { id: "due", label: t("colDue"), sort: "due", className: "w-28" },
    { id: "created", label: tc("created"), sort: "created", className: "hidden w-28 2xl:table-cell" },
    { id: "updated", label: tc("updated"), sort: "updated", className: "w-32" },
  ];

  const onSort = (key: string) => {
    if (sort === key) set({ sort: key, dir: dir === "asc" ? "desc" : "asc" });
    else set({ sort: key, dir: key === "title" || key === "assignee" || key === "key" || key === "due" ? "asc" : "desc" });
  };

  if (total === 0) {
    return (
      <div className="rounded-[3px] border border-line bg-surface-raised">
        <EmptyState title={t("emptyTitle")} description={t("emptyDesc")} />
      </div>
    );
  }

  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, total);

  return (
    <div>
      <div className="overflow-x-auto rounded-[3px] border border-line bg-surface-raised">
        <table className="w-full min-w-[1000px] border-collapse text-sm">
          <thead>
            <tr className="border-b-2 border-line bg-surface-raised text-left">
              {cols.map((c) => (
                <th key={c.id} className={cn("whitespace-nowrap px-2 py-2 text-xs font-semibold text-ink-subtle", c.className)}>
                  {c.id === "title" && <div className="h-0 w-[240px]" aria-hidden />}
                  {c.sort ? (
                    <button onClick={() => onSort(c.sort!)} title={t("sortBy", { col: c.label })} className="inline-flex items-center gap-1 hover:text-ink">
                      {c.label}
                      {sort === c.sort && (dir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                    </button>
                  ) : (
                    c.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const overdue = r.dueDate && r.status !== "DONE" && new Date(r.dueDate) < today;
              return (
                <tr key={r.id} onClick={() => open(r.key)} className="cursor-pointer border-b border-line last:border-b-0 hover:bg-surface-hover">
                  <td className="px-2 py-1.5">
                    <IssueTypeIcon type={r.type} />
                  </td>
                  <td className="whitespace-nowrap px-2 py-1.5">
                    <Link
                      href={`/browse/${r.key}`}
                      onClick={(e) => {
                        if (e.metaKey || e.ctrlKey || e.shiftKey) {
                          e.stopPropagation();
                          return;
                        }
                        e.preventDefault();
                      }}
                      className={cn("font-medium text-brand-600 hover:underline", r.status === "DONE" && "line-through")}
                    >
                      {r.key}
                    </Link>
                  </td>
                  <td className="max-w-0 px-2 py-1.5">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-ink">{r.title}</span>
                      {parseLabels(r.labels)
                        .slice(0, 2)
                        .map((l) => (
                          <span key={l} className="hidden shrink-0 rounded-[3px] border border-line px-1 text-[11px] text-ink-muted xl:inline">
                            {l}
                          </span>
                        ))}
                    </div>
                    {r.parent && (
                      <div className="truncate text-xs text-ink-subtle">
                        {r.parent.key} · {r.parent.title}
                      </div>
                    )}
                  </td>
                  <td className="px-2 py-1.5">
                    <StatusLozenge status={r.status} />
                  </td>
                  <td className="px-2 py-1.5">
                    <div className="flex items-center gap-2">
                      <Avatar user={r.assignee} size="xs" />
                      <span className={cn("truncate", !r.assignee && "text-ink-subtle")}>{r.assignee?.name ?? tc("unassigned")}</span>
                    </div>
                  </td>
                  <td className="px-2 py-1.5">
                    <PriorityIcon priority={r.priority} />
                  </td>
                  {mode === "project" ? (
                    <td className="truncate px-2 py-1.5 text-ink-muted">{r.sprint?.name ?? <span className="text-ink-faint">—</span>}</td>
                  ) : (
                    <td className="px-2 py-1.5">
                      <div className="flex items-center gap-2">
                        <ProjectAvatar project={r.project} size="sm" />
                        <span className="truncate text-ink-muted">{r.project.name}</span>
                      </div>
                    </td>
                  )}
                  <td className="px-2 py-1.5 text-center">
                    <PointsBadge points={r.storyPoints} />
                  </td>
                  <td className={cn("whitespace-nowrap px-2 py-1.5", overdue ? "font-medium text-danger" : "text-ink-muted")}>
                    {r.dueDate ? f.date(r.dueDate) : <span className="text-ink-faint">—</span>}
                  </td>
                  <td className="hidden whitespace-nowrap px-2 py-1.5 text-ink-muted 2xl:table-cell">{f.date(r.createdAt)}</td>
                  <td className="whitespace-nowrap px-2 py-1.5 text-ink-muted" title={f.dateTime(r.updatedAt)} suppressHydrationWarning>
                    {f.relative(r.updatedAt)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="mt-3 flex items-center justify-between text-sm text-ink-subtle">
        <span>{t("range", { from: f.num(from), to: f.num(to), total: f.num(total) })}</span>
        {pageCount > 1 && (
          <div className="flex items-center gap-1">
            <button
              disabled={page <= 1}
              onClick={() => set({ page: String(page - 1) }, { resetPage: false })}
              className="rounded p-1 hover:bg-surface-hover disabled:opacity-40"
              aria-label={t("prevPage")}
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            {Array.from({ length: pageCount }, (_, i) => i + 1)
              .filter((p) => p === 1 || p === pageCount || Math.abs(p - page) <= 2)
              .map((p, i, arr) => (
                <span key={p} className="flex items-center">
                  {i > 0 && p - arr[i - 1]! > 1 && <span className="px-1">…</span>}
                  <button
                    onClick={() => set({ page: String(p) }, { resetPage: false })}
                    className={cn("h-7 min-w-7 rounded px-1.5", p === page ? "bg-brand-50 font-semibold text-brand-700" : "hover:bg-surface-hover")}
                  >
                    {p}
                  </button>
                </span>
              ))}
            <button
              disabled={page >= pageCount}
              onClick={() => set({ page: String(page + 1) }, { resetPage: false })}
              className="rounded p-1 hover:bg-surface-hover disabled:opacity-40"
              aria-label={t("nextPage")}
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
