"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useCallback, useTransition } from "react";

/** URL searchParams-ı yeniləmək üçün: set({ status: "TODO", page: null }) — null açarı silir */
export function useQueryParams() {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [pending, startTransition] = useTransition();

  const set = useCallback(
    (patch: Record<string, string | null>, opts: { resetPage?: boolean } = { resetPage: true }) => {
      const sp = new URLSearchParams(params.toString());
      for (const [k, v] of Object.entries(patch)) {
        if (v === null || v === "") sp.delete(k);
        else sp.set(k, v);
      }
      if (opts.resetPage && !("page" in patch)) sp.delete("page");
      const q = sp.toString();
      startTransition(() => router.replace(q ? `${pathname}?${q}` : pathname, { scroll: false }));
    },
    [params, pathname, router],
  );

  const clear = useCallback(
    (keys: string[]) => {
      const sp = new URLSearchParams(params.toString());
      keys.forEach((k) => sp.delete(k));
      const q = sp.toString();
      startTransition(() => router.replace(q ? `${pathname}?${q}` : pathname, { scroll: false }));
    },
    [params, pathname, router],
  );

  const getList = useCallback(
    (key: string) =>
      (params.get(key) ?? "")
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
    [params],
  );

  return { params, set, clear, getList, pending };
}
