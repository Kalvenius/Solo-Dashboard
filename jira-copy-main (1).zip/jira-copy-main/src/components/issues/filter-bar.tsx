"use client";

import { useEffect, useRef, useState } from "react";
import { Download, Search, X } from "lucide-react";
import { ISSUE_TYPES, PRIORITIES, STATUSES } from "@/lib/constants";
import { useT } from "@/i18n/client";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ProjectAvatar } from "@/components/ui/misc";
import { IssueTypeIcon, PriorityIcon } from "@/components/issue/icons";
import { MultiSelect } from "./multi-select";
import { useQueryParams } from "./use-query-params";

export const FILTER_KEYS = ["q", "status", "type", "assignee", "priority", "sprint", "label", "project", "reporter", "created", "resolved", "overdue", "watching", "page"];

export type FilterOptions = {
  me: { id: string; name: string; avatarColor: string };
  users: { id: string; name: string; avatarColor: string }[];
  sprints?: { id: string; name: string; state: string }[];
  projects?: { key: string; name: string; color: string }[];
  labels: string[];
};

export function FilterBar({ options, exportHref }: { options: FilterOptions; exportHref: string }) {
  const { params, set, clear, getList, pending } = useQueryParams();
  const t = useT("issueTable");
  const tc = useT("common");
  const te = useT("enums");
  const [q, setQ] = useState(params.get("q") ?? "");
  const lastPushed = useRef(params.get("q") ?? "");

  // URL dəyişəndə (məs. "Təmizlə" və ya preset) input-u sinxronlaşdır
  useEffect(() => {
    const urlQ = params.get("q") ?? "";
    if (urlQ !== lastPushed.current) {
      lastPushed.current = urlQ;
      setQ(urlQ);
    }
  }, [params]);

  useEffect(() => {
    if (q === lastPushed.current) return;
    const timer = setTimeout(() => {
      lastPushed.current = q;
      set({ q: q.trim() || null });
    }, 300);
    return () => clearTimeout(timer);
  }, [q, set]);

  const multi = (key: string) => ({
    value: getList(key),
    onChange: (v: string[]) => set({ [key]: v.length ? v.join(",") : null }),
  });

  const hasAny = FILTER_KEYS.some((k) => k !== "page" && params.get(k));

  // preset-lərdən gələn əlavə şərtlər — çip kimi göstərilir
  const chips: { key: string; label: string }[] = [];
  const reporter = params.get("reporter");
  if (reporter)
    chips.push({
      key: "reporter",
      label: reporter === "me" ? t("chipReporterMe") : t("chipReporter", { name: options.users.find((u) => u.id === reporter)?.name ?? "—" }),
    });
  if (params.get("created")) chips.push({ key: "created", label: t("chipCreated", { n: Number(params.get("created")) }) });
  if (params.get("resolved")) chips.push({ key: "resolved", label: t("chipResolved", { n: Number(params.get("resolved")) }) });
  if (params.get("overdue") === "1") chips.push({ key: "overdue", label: t("chipOverdue") });
  if (params.get("watching") === "1") chips.push({ key: "watching", label: t("chipWatching") });

  return (
    <div className="mb-3 space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-subtle" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("searchPlaceholder")}
            className="h-8 w-56 rounded-[3px] border-2 border-line bg-input pl-8 pr-2 text-sm text-ink placeholder:text-ink-faint focus:border-brand-500 focus:bg-surface-raised focus:outline-none"
          />
        </div>
        {options.projects && (
          <MultiSelect
            label={t("project")}
            options={options.projects.map((p) => ({ value: p.key, label: p.name, icon: <ProjectAvatar project={p} size="sm" /> }))}
            {...multi("project")}
          />
        )}
        <MultiSelect
          label={tc("type")}
          options={ISSUE_TYPES.map((ty) => ({ value: ty, label: te(`type.${ty}`), icon: <IssueTypeIcon type={ty} /> }))}
          {...multi("type")}
        />
        <MultiSelect label={tc("status")} options={STATUSES.map((s) => ({ value: s, label: te(`status.${s}`) }))} {...multi("status")} />
        <MultiSelect
          label={tc("assignee")}
          searchable
          options={[
            { value: "me", label: tc("me"), icon: <Avatar user={options.me} size="xs" /> },
            { value: "unassigned", label: tc("unassigned"), icon: <Avatar user={null} size="xs" /> },
            ...options.users.filter((u) => u.id !== options.me.id).map((u) => ({ value: u.id, label: u.name, icon: <Avatar user={u} size="xs" /> })),
          ]}
          {...multi("assignee")}
        />
        <MultiSelect
          label={tc("priority")}
          options={PRIORITIES.map((p) => ({ value: p, label: te(`priority.${p}`), icon: <PriorityIcon priority={p} /> }))}
          {...multi("priority")}
        />
        {options.sprints && (
          <MultiSelect
            label={tc("sprint")}
            options={[
              { value: "active", label: t("activeSprint") },
              { value: "backlog", label: t("backlogNoSprint") },
              ...options.sprints.map((s) => ({ value: s.id, label: s.state === "COMPLETED" ? t("sprintCompleted", { name: s.name }) : s.name })),
            ]}
            {...multi("sprint")}
          />
        )}
        {options.labels.length > 0 && <MultiSelect label={t("label")} options={options.labels.map((l) => ({ value: l, label: l }))} {...multi("label")} />}
        {hasAny && (
          <Button variant="subtle" onClick={() => clear(FILTER_KEYS)}>
            {tc("clear")}
          </Button>
        )}
        {pending && <span className="h-4 w-4 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />}
        <a href={exportHref} className="ml-auto">
          <Button variant="default">
            <Download className="h-4 w-4" /> {t("exportCsv")}
          </Button>
        </a>
      </div>
      {chips.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {chips.map((c) => (
            <span key={c.key} className="inline-flex items-center gap-1 rounded-[3px] bg-brand-50 py-0.5 pl-2 pr-1 text-xs font-medium text-brand-700">
              {c.label}
              <button onClick={() => set({ [c.key]: null })} className="rounded p-0.5 hover:bg-brand-100" aria-label={t("removeFilter")}>
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
