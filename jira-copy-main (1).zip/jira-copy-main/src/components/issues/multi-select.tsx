"use client";

import { useState, type ReactNode } from "react";
import { Check, ChevronDown } from "lucide-react";
import { Popover } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";

export type MultiOption = { value: string; label: string; icon?: ReactNode };

/** Jira filtr düyməsi: "Status" → seçiləndə "Status: İcrada +1" */
export function MultiSelect({
  label,
  options,
  value,
  onChange,
  searchable,
}: {
  label: string;
  options: MultiOption[];
  value: string[];
  onChange: (v: string[]) => void;
  searchable?: boolean;
}) {
  const t = useT("issueTable");
  const tc = useT("common");
  const [q, setQ] = useState("");
  const selected = options.filter((o) => value.includes(o.value));
  const filtered = q ? options.filter((o) => o.label.toLowerCase().includes(q.toLowerCase())) : options;
  const active = selected.length > 0;

  const toggle = (v: string) => onChange(value.includes(v) ? value.filter((x) => x !== v) : [...value, v]);

  return (
    <Popover
      className="max-h-80 w-60 overflow-y-auto"
      trigger={({ toggle, open }) => (
        <button
          type="button"
          onClick={toggle}
          className={cn(
            "inline-flex h-8 items-center gap-1 rounded-[3px] px-2.5 text-sm font-medium transition-colors",
            active ? "bg-brand-50 text-brand-700 hover:bg-brand-100" : "bg-tint-1 text-ink hover:bg-tint-2",
            open && !active && "bg-tint-2",
          )}
        >
          <span className="max-w-[180px] truncate">
            {label}
            {active && `: ${selected[0]!.label}`}
          </span>
          {selected.length > 1 && <span className="rounded bg-brand-600 px-1 text-[11px] text-on-brand">+{selected.length - 1}</span>}
          <ChevronDown className="h-4 w-4" />
        </button>
      )}
    >
      {(searchable ?? options.length > 8) && (
        <div className="px-2 pb-1 pt-1">
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={tc("searchPlaceholder")}
            className="h-8 w-full rounded-[3px] border-2 border-line bg-input px-2 text-sm text-ink placeholder:text-ink-faint focus:border-brand-500 focus:outline-none"
          />
        </div>
      )}
      {filtered.length === 0 && <div className="px-3 py-2 text-sm text-ink-subtle">{tc("noResults")}</div>}
      {filtered.map((o) => {
        const on = value.includes(o.value);
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => toggle(o.value)}
            className="flex w-full items-center gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-hover"
          >
            <span
              className={cn(
                "flex h-4 w-4 shrink-0 items-center justify-center rounded-[3px] border-2",
                on ? "border-brand-600 bg-brand-600 text-on-brand" : "border-neutral-strong bg-surface-raised",
              )}
            >
              {on && <Check className="h-3 w-3" strokeWidth={3} />}
            </span>
            {o.icon}
            <span className="flex-1 truncate">{o.label}</span>
          </button>
        );
      })}
      {active && (
        <>
          <div className="my-1 border-t border-line" />
          <button type="button" onClick={() => onChange([])} className="w-full px-3 py-1.5 text-left text-sm text-ink-subtle hover:bg-surface-hover">
            {t("clearSelection")}
          </button>
        </>
      )}
    </Popover>
  );
}
