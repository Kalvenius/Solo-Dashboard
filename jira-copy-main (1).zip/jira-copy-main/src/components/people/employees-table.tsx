"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowDown, ArrowUp } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Lozenge } from "@/components/ui/lozenge";
import { Sparkline } from "@/components/charts/sparkline";
import { minutesToHours } from "@/components/charts/theme";
import { cn } from "@/lib/utils";
import { useFormat, useLocale, useT } from "@/i18n/client";
import type { Translator } from "@/i18n/types";

export type EmployeeRow = {
  id: string;
  name: string;
  title: string | null;
  avatarColor: string;
  active: boolean;
  open: number;
  inProgress: number;
  inReview: number;
  completed: number;
  points: number;
  minutes: number;
  overdue: number;
  onTimeRate: number | null;
  avgCycleDays: number | null;
  lastActive: string | null;
  weekly: number[];
};

type Key = keyof Pick<EmployeeRow, "name" | "open" | "inProgress" | "inReview" | "completed" | "points" | "minutes" | "overdue" | "onTimeRate" | "avgCycleDays" | "lastActive">;

const columns = (t: Translator<"people">, te: Translator<"enums">, tc: Translator<"common">): { key: Key; label: string; title?: string; numeric?: boolean }[] => [
  { key: "name", label: t("colEmployee") },
  { key: "open", label: t("colOpen"), numeric: true, title: t("colOpenTitle") },
  { key: "inProgress", label: te("status.IN_PROGRESS"), numeric: true },
  { key: "inReview", label: te("status.IN_REVIEW"), numeric: true },
  { key: "completed", label: t("colCompleted"), numeric: true, title: t("colCompletedTitle") },
  { key: "points", label: tc("storyPoints"), numeric: true },
  { key: "minutes", label: t("colHours"), numeric: true, title: t("colHoursTitle") },
  { key: "overdue", label: t("kpiOverdue"), numeric: true, title: t("colOverdueTitle") },
  { key: "onTimeRate", label: t("colOnTime"), numeric: true, title: t("colOnTimeTitle") },
  { key: "avgCycleDays", label: t("colCycle"), numeric: true, title: t("colCycleTitle") },
  { key: "lastActive", label: t("colLastActive"), numeric: true },
];

export function EmployeesTable({ rows, projectKey }: { rows: EmployeeRow[]; projectKey: string | null }) {
  const router = useRouter();
  const t = useT("people");
  const te = useT("enums");
  const tc = useT("common");
  const f = useFormat();
  const locale = useLocale();
  const COLS = columns(t, te, tc);
  const [sort, setSort] = useState<{ key: Key; dir: "asc" | "desc" }>({ key: "completed", dir: "desc" });
  const href = (id: string) => `/people/${id}${projectKey ? `?project=${projectKey}` : ""}`;

  const sorted = useMemo(() => {
    const val = (r: EmployeeRow) => {
      const v = r[sort.key];
      if (sort.key === "lastActive") return v ? new Date(v as string).getTime() : -Infinity;
      return v;
    };
    return [...rows].sort((a, b) => {
      const va = val(a);
      const vb = val(b);
      let c: number;
      if (typeof va === "string" && typeof vb === "string") c = va.localeCompare(vb, locale);
      else c = (va == null ? -Infinity : (va as number)) - (vb == null ? -Infinity : (vb as number));
      return sort.dir === "asc" ? c : -c;
    });
  }, [rows, sort, locale]);

  const toggle = (key: Key) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: key === "name" ? "asc" : "desc" }));

  return (
    <div className="overflow-x-auto rounded-[3px] border border-line bg-surface-raised">
      <table className="w-full min-w-[1100px] text-[13px]">
        <thead>
          <tr className="border-b-2 border-line text-left">
            {COLS.map((c) => (
              <th
                key={c.key}
                title={c.title}
                aria-sort={sort.key === c.key ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}
                className={cn("whitespace-nowrap px-3 py-2 text-xs font-semibold text-ink-subtle", c.numeric && "text-right")}
              >
                <button onClick={() => toggle(c.key)} className={cn("inline-flex items-center gap-1 hover:text-ink", sort.key === c.key && "text-ink")}>
                  {c.label}
                  {sort.key === c.key && (sort.dir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                </button>
              </th>
            ))}
            <th className="px-3 py-2 text-right text-xs font-semibold text-ink-subtle" title={t("colTrendTitle")}>
              {t("colTrend")}
            </th>
          </tr>
        </thead>
        <tbody>
          {sorted.length === 0 && (
            <tr>
              <td colSpan={COLS.length + 1} className="px-3 py-10 text-center text-sm text-ink-subtle">
                {t("noEmployees")}
              </td>
            </tr>
          )}
          {sorted.map((r) => (
            <tr key={r.id} onClick={() => router.push(href(r.id))} className="cursor-pointer border-b border-line last:border-0 hover:bg-surface-hover">
              <td className="px-3 py-2">
                <Link href={href(r.id)} onClick={(e) => e.stopPropagation()} className="flex items-center gap-2.5">
                  <Avatar user={r} size="md" />
                  <span className="min-w-0">
                    <span className="flex items-center gap-1.5 font-medium text-ink hover:text-brand-600 hover:underline">
                      <span className="truncate">{r.name}</span>
                      {!r.active && <Lozenge tone="todo">{tc("inactive")}</Lozenge>}
                    </span>
                    <span className="block truncate text-xs text-ink-subtle">{r.title ?? "—"}</span>
                  </span>
                </Link>
              </td>
              <Num v={r.open} />
              <Num v={r.inProgress} />
              <Num v={r.inReview} />
              <Num v={r.completed} strong />
              <Num v={r.points} />
              <td className="px-3 py-2 text-right tabular-nums text-ink">{f.num(minutesToHours(r.minutes), 1)}</td>
              <td className={cn("px-3 py-2 text-right tabular-nums", r.overdue > 0 ? "font-semibold text-danger" : "text-ink-subtle")}>{r.overdue}</td>
              <td className="px-3 py-2 text-right tabular-nums text-ink">{r.onTimeRate == null ? <span className="text-ink-faint">—</span> : `${r.onTimeRate}%`}</td>
              <td className="px-3 py-2 text-right tabular-nums text-ink">
                {r.avgCycleDays == null ? <span className="text-ink-faint">—</span> : t("cycleDays", { n: f.num(r.avgCycleDays, 1) })}
              </td>
              <td suppressHydrationWarning className="whitespace-nowrap px-3 py-2 text-right text-ink-subtle">{r.lastActive ? f.relative(r.lastActive) : "—"}</td>
              <td className="px-3 py-2">
                <div className="flex justify-end">
                  <Sparkline values={r.weekly} label={t("sparkLabel", { name: r.name, values: r.weekly.join(", ") })} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Num({ v, strong }: { v: number; strong?: boolean }) {
  return <td className={cn("px-3 py-2 text-right tabular-nums", v === 0 ? "text-ink-faint" : "text-ink", strong && v > 0 && "font-semibold")}>{v}</td>;
}
