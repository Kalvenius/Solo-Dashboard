"use client";

import { useOpenIssue } from "@/components/issue/use-open-issue";
import { IssueTypeIcon, PriorityIcon } from "@/components/issue/icons";
import { StatusLozenge } from "@/components/ui/lozenge";
import { ProjectAvatar } from "@/components/ui/misc";
import type { Status } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";

export type OpenIssue = {
  id: string;
  key: string;
  title: string;
  type: string;
  status: string;
  priority: string;
  dueDate: Date | string | null;
  overdue: boolean;
  project: { key: string; name: string; color: string };
};

export function OpenIssues({ groups }: { groups: { status: Status; issues: OpenIssue[] }[] }) {
  const { open } = useOpenIssue();
  const t = useT("people");
  const te = useT("enums");
  const f = useFormat();
  const total = groups.reduce((s, g) => s + g.issues.length, 0);
  if (!total) return <p className="py-8 text-center text-sm text-ink-subtle">{t("noOpenIssuesYay")}</p>;
  return (
    <div className="space-y-4">
      {groups
        .filter((g) => g.issues.length)
        .map((g) => (
          <div key={g.status}>
            <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase text-ink-subtle">
              {te(`status.${g.status}`)}
              <span className="rounded-full bg-neutral px-1.5 text-[11px] text-ink-muted">{g.issues.length}</span>
            </div>
            <ul className="divide-y divide-line rounded-[3px] border border-line">
              {g.issues.map((i) => (
                <li key={i.id}>
                  <button onClick={() => open(i.key)} className="flex w-full items-center gap-3 px-3 py-2 text-left text-[13px] hover:bg-surface-hover">
                    <IssueTypeIcon type={i.type} />
                    <span className="w-16 shrink-0 font-medium text-ink-subtle">{i.key}</span>
                    <span className="min-w-0 flex-1 truncate text-ink">{i.title}</span>
                    <span className="hidden items-center gap-1.5 text-xs text-ink-subtle sm:flex">
                      <ProjectAvatar project={i.project} size="sm" />
                    </span>
                    <PriorityIcon priority={i.priority} />
                    <span className={cn("w-24 shrink-0 text-right text-xs", i.overdue ? "font-semibold text-danger" : "text-ink-subtle")}>
                      {i.dueDate ? f.date(i.dueDate) : "—"}
                    </span>
                    <span className="hidden w-24 shrink-0 text-right md:block">
                      <StatusLozenge status={i.status} />
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
    </div>
  );
}
