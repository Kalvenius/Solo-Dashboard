"use client";

import { useOpenIssue } from "@/components/issue/use-open-issue";
import { cn } from "@/lib/utils";

/** Tapşırıq açarı — klikdə tapşırığı cari səhifənin üstündə modal kimi açır */
export function IssueKeyButton({ issueKey, className, children }: { issueKey: string; className?: string; children?: React.ReactNode }) {
  const { open } = useOpenIssue();
  return (
    <button type="button" onClick={() => open(issueKey)} className={cn("font-medium text-brand-600 hover:underline", className)}>
      {children ?? issueKey}
    </button>
  );
}
