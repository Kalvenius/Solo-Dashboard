"use client";

import { useTransition, type ReactNode } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";

const PERIODS = [7, 14, 30, 90];

/**
 * Filtr sətri (dövr + layihə) — altındakı hər şeyi əhatə edir. URL-i yeniləyir;
 * yüklənmə zamanı köhnə məzmun azaldılmış şəffaflıqla qalır (sıçrayış yoxdur).
 */
export function DashboardFrame({
  period,
  projects,
  projectKey,
  rangeLabel,
  children,
}: {
  period: number;
  projects: { key: string; name: string }[];
  projectKey: string | null;
  rangeLabel?: string;
  children: ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [pending, start] = useTransition();
  const t = useT("people");
  const tc = useT("common");

  const go = (patch: Record<string, string | null>) => {
    const sp = new URLSearchParams(params.toString());
    for (const [k, v] of Object.entries(patch)) {
      if (v === null) sp.delete(k);
      else sp.set(k, v);
    }
    sp.delete("selectedIssue");
    const q = sp.toString();
    start(() => router.push(q ? `${pathname}?${q}` : pathname, { scroll: false }));
  };

  return (
    <>
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="flex rounded-[3px] border border-line bg-surface-raised p-0.5" role="radiogroup" aria-label={t("periodAria")}>
          {PERIODS.map((p) => (
            <button
              key={p}
              role="radio"
              aria-checked={period === p}
              onClick={() => go({ period: p === 30 ? null : String(p) })}
              className={cn(
                "inline-flex h-7 items-center gap-1 rounded-[2px] px-2.5 text-[13px] font-medium",
                period === p ? "bg-brand-50 text-brand-700" : "text-ink-muted hover:bg-surface-hover",
              )}
            >
              {period === p && <Check className="h-3.5 w-3.5" strokeWidth={3} />}
              {t("lastDays", { n: p })}
            </button>
          ))}
        </div>
        <select
          aria-label={tc("project")}
          value={projectKey ?? ""}
          onChange={(e) => go({ project: e.target.value || null })}
          className="h-8 cursor-pointer rounded-[3px] border-2 border-line bg-input px-2 pr-7 text-[13px] text-ink hover:bg-input-hover focus:border-brand-500 focus:outline-none"
        >
          <option value="">{t("allProjects")}</option>
          {projects.map((p) => (
            <option key={p.key} value={p.key}>
              {p.name} ({p.key})
            </option>
          ))}
        </select>
        {rangeLabel && <span className="text-xs text-ink-subtle">{rangeLabel}</span>}
        {pending && <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" aria-label={tc("loading")} />}
      </div>
      <div className={cn("transition-opacity", pending && "pointer-events-none opacity-60")}>{children}</div>
    </>
  );
}
