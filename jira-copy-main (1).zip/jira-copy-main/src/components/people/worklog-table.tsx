"use client";

import { IssueTypeIcon } from "@/components/issue/icons";
import { useFormat, useT } from "@/i18n/client";
import { IssueKeyButton } from "./issue-key-button";

export type WorklogItem = { id: string; minutes: number; startedAt: Date | string; note: string | null; issue: { key: string; title: string; type: string } };

export function WorklogTable({ items }: { items: WorklogItem[] }) {
  const t = useT("people");
  const tc = useT("common");
  const f = useFormat();
  if (!items.length) return <p className="py-8 text-center text-sm text-ink-subtle">{t("noWorklogs")}</p>;
  const total = items.reduce((s, w) => s + w.minutes, 0);
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-[13px]">
        <thead>
          <tr className="border-b-2 border-line text-left text-xs text-ink-subtle">
            <th className="py-1.5 pr-3 font-semibold">{t("colDate")}</th>
            <th className="py-1.5 pr-3 font-semibold">{tc("issue")}</th>
            <th className="py-1.5 pr-3 font-semibold">{t("colNote")}</th>
            <th className="py-1.5 text-right font-semibold">{t("colDuration")}</th>
          </tr>
        </thead>
        <tbody>
          {items.map((w) => (
            <tr key={w.id} className="border-b border-line last:border-0">
              <td className="whitespace-nowrap py-1.5 pr-3 text-ink-subtle">{f.date(w.startedAt)}</td>
              <td className="max-w-[260px] py-1.5 pr-3">
                <span className="flex items-center gap-1.5">
                  <IssueTypeIcon type={w.issue.type} />
                  <IssueKeyButton issueKey={w.issue.key} />
                  <span className="truncate text-ink" title={w.issue.title}>
                    {w.issue.title}
                  </span>
                </span>
              </td>
              <td className="max-w-[180px] truncate py-1.5 pr-3 text-ink-subtle">{w.note ?? "—"}</td>
              <td className="whitespace-nowrap py-1.5 text-right font-medium tabular-nums text-ink">{f.minutes(w.minutes)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan={3} className="pt-2 text-right text-xs font-semibold text-ink-subtle">
              {t("worklogTotal", { n: items.length })}
            </td>
            <td className="pt-2 text-right font-semibold tabular-nums text-ink">{f.minutes(total)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
