import type { Formatters } from "@/i18n/fmt";
import type { Translator } from "@/i18n/types";

export type ActivityRow = {
  id: string;
  action: string;
  field: string | null;
  fromValue: string | null;
  toValue: string | null;
  createdAt: Date | string;
  issue: { key: string; title: string };
};

const KNOWN_FIELDS = ["status", "assignee", "reporter", "priority", "title", "description", "type", "sprint", "parent", "storyPoints", "dueDate", "startDate", "labels", "estimate"];

/**
 * Tarixçə sətrini istifadəçinin dilində cümləyə çevirir.
 * Tərcümədə {key} yer tutucusu qalır — komponent onu kliklənən tapşırıq açarı ilə əvəz edir: [əvvəl, açar, sonra].
 * Status / prioritet / növ xam kod kimi saxlanılır (enums ilə adlandırılır); icraçı / sprint isə ad kimi.
 */
export function describeActivity(
  a: ActivityRow,
  t: Translator<"people">,
  te: Translator<"enums">,
  f: Formatters,
): { before: string; after: string } {
  const code = (prefix: "status" | "priority" | "type", v: string | null) => (v ? te(`${prefix}.${v}` as Parameters<typeof te>[0]) : "—");
  const field = (name: string) => (KNOWN_FIELDS.includes(name) ? te(`field.${name}` as Parameters<typeof te>[0]) : name).toLowerCase();

  let text: string;
  switch (a.action) {
    case "CREATED":
      text = t("actCreated");
      break;
    case "COMMENTED":
      text = t("actCommented");
      break;
    case "ATTACHED":
      text = t("actAttached");
      break;
    case "LOGGED_WORK": {
      const n = Number(a.toValue);
      text = Number.isFinite(n) && n > 0 ? t("actLogged", { time: f.minutes(n) }) : t("actLoggedNoTime");
      break;
    }
    default: {
      const fld = a.field ?? "";
      switch (fld) {
        case "status":
          text = t("actStatus", { from: code("status", a.fromValue), to: code("status", a.toValue) });
          break;
        case "priority":
          text = t("actPriority", { from: code("priority", a.fromValue), to: code("priority", a.toValue) });
          break;
        case "type":
          text = t("actType", { from: code("type", a.fromValue), to: code("type", a.toValue) });
          break;
        case "assignee":
          text = a.toValue ? t("actAssigned", { name: a.toValue }) : t("actUnassigned");
          break;
        case "sprint":
          text = a.toValue ? t("actSprint", { sprint: a.toValue }) : t("actBacklog");
          break;
        case "description":
          text = t("actDescription");
          break;
        case "title":
          text = t("actTitle");
          break;
        case "dueDate":
        case "startDate":
          text = t("actDate", { field: field(fld), value: a.toValue ? f.date(a.toValue) : t("empty") });
          break;
        case "storyPoints":
          text = t("actPoints", { value: a.toValue ?? t("empty") });
          break;
        default:
          text = t("actField", { field: field(fld || "field") });
      }
    }
  }
  const i = text.indexOf("{key}");
  if (i < 0) return { before: text, after: "" };
  return { before: text.slice(0, i), after: text.slice(i + "{key}".length) };
}
