"use client";

import { Avatar } from "@/components/ui/avatar";
import { useFormat, useT } from "@/i18n/client";
import { describeActivity, type ActivityRow } from "./activity-text";
import { IssueKeyButton } from "./issue-key-button";

export function ActivityFeed({ items, person }: { items: ActivityRow[]; person: { name: string; avatarColor: string } }) {
  const t = useT("people");
  const te = useT("enums");
  const f = useFormat();
  if (!items.length) return <p className="py-8 text-center text-sm text-ink-subtle">{t("noActivity")}</p>;
  return (
    <ol className="space-y-3">
      {items.map((a) => {
        const d = describeActivity(a, t, te, f);
        return (
          <li key={a.id} className="flex gap-2.5 text-[13px]">
            <Avatar user={person} size="sm" className="mt-0.5" />
            <div className="min-w-0 flex-1">
              <p className="leading-5 text-ink">
                <span className="font-semibold">{person.name.split(" ")[0]}</span> {d.before}
                <IssueKeyButton issueKey={a.issue.key} />
                {d.after}
              </p>
              <p className="truncate text-xs text-ink-subtle" title={a.issue.title}>
                {a.issue.title}
              </p>
              <time suppressHydrationWarning className="text-xs text-ink-faint" title={f.dateTime(a.createdAt)}>
                {f.relative(a.createdAt)}
              </time>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
