"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import { ACCENT } from "./theme";
import { ChartVars } from "./chart-vars";

export type RankedRow = { key: string; label: string; icon?: ReactNode; value: number; valueLabel?: string; href?: string };

/**
 * Sıralanmış üfüqi zolaqlar (hissə-bütöv müqayisəsi üçün dairəvi diaqram əvəzinə).
 * Tək rəng; dəyər zolağın ucunda; zolaq ≤ 16px, sağ ucu 4px yuvarlaq.
 */
export function RankedBars({ rows, color = ACCENT, total, empty, labelWidth = "w-36" }: { rows: RankedRow[]; color?: string; total?: number; empty?: string; labelWidth?: string }) {
  const t = useT("charts");
  const fmt = useFormat();
  const fmtNum = (n: number) => fmt.num(n);
  if (!rows.length || rows.every((r) => r.value === 0)) return <p className="py-6 text-center text-sm text-ink-subtle">{empty ?? t("noData")}</p>;
  const max = Math.max(...rows.map((r) => r.value), 1);
  const sum = total ?? rows.reduce((s, r) => s + r.value, 0);
  return (
    <ul className="space-y-1.5">
      <ChartVars />
      {rows.map((r) => {
        const share = sum ? Math.round((r.value / sum) * 100) : 0;
        const title = `${r.label}: ${r.valueLabel ?? fmtNum(r.value)}${total !== 0 ? ` (${share}%)` : ""}`;
        const inner = (
          <>
            <span className={cn("flex shrink-0 items-center gap-1.5 truncate text-[13px] text-ink", labelWidth)}>
              {r.icon}
              <span className="truncate">{r.label}</span>
            </span>
            <span className="flex min-w-0 flex-1 items-center gap-2">
              <span
                className="h-4 rounded-r-[4px] transition-opacity group-hover:opacity-80"
                style={{ width: `${(r.value / max) * 100}%`, minWidth: r.value > 0 ? 2 : 0, backgroundColor: color }}
              />
              <span className="shrink-0 text-xs tabular-nums text-ink-muted">
                {r.valueLabel ?? fmtNum(r.value)}
                <span className="ml-1 text-ink-faint">{share}%</span>
              </span>
            </span>
          </>
        );
        return (
          <li key={r.key} title={title}>
            {r.href ? (
              <Link href={r.href} className="group flex items-center gap-3 rounded-[3px] px-1 py-0.5 hover:bg-surface-hover">
                {inner}
              </Link>
            ) : (
              <div className="group flex items-center gap-3 px-1 py-0.5">{inner}</div>
            )}
          </li>
        );
      })}
    </ul>
  );
}

export type StackedRow = { key: string; label: string; lead?: ReactNode; values: number[]; href?: string; sub?: string };

/**
 * Hər sətirdə yığılmış üfüqi zolaq (məs. şəxs üzrə Görüləcək / İcrada / Yoxlamada).
 * Seqmentlər arasında 2px boşluq, son seqmentin ucu yuvarlaq, cəm zolağın ucunda.
 */
export function StackedRows({
  rows,
  series,
  empty,
  format,
}: {
  rows: StackedRow[];
  series: { name: string; color: string }[];
  empty?: string;
  format?: (n: number) => string;
}) {
  const t = useT("charts");
  const fmt = useFormat();
  const show = format ?? ((n: number) => fmt.num(n));
  const totals = rows.map((r) => r.values.reduce((a, b) => a + b, 0));
  const max = Math.max(...totals, 1);
  if (!rows.length || totals.every((x) => x === 0)) return <p className="py-6 text-center text-sm text-ink-subtle">{empty ?? t("noData")}</p>;
  return (
    <ul className="space-y-1.5">
      <ChartVars />
      {rows.map((r, idx) => {
        const total = totals[idx]!;
        const lastNonZero = r.values.reduce((acc, v, i) => (v > 0 ? i : acc), -1);
        const inner = (
          <>
            <span className="flex w-40 shrink-0 items-center gap-2 truncate text-[13px] text-ink">
              {r.lead}
              <span className="truncate">{r.label}</span>
            </span>
            <span className="flex min-w-0 flex-1 items-center gap-2">
              <span className="flex h-4 gap-[2px]" style={{ width: `${(total / max) * 100}%`, minWidth: total > 0 ? 2 : 0 }}>
                {r.values.map((v, i) =>
                  v > 0 ? (
                    <span
                      key={i}
                      title={`${series[i]?.name}: ${show(v)}`}
                      className={cn("h-full transition-opacity hover:opacity-80", i === lastNonZero && "rounded-r-[4px]")}
                      style={{ flexGrow: v, flexBasis: 0, backgroundColor: series[i]?.color }}
                    />
                  ) : null,
                )}
              </span>
              <span className="shrink-0 text-xs font-medium tabular-nums text-ink-muted">{show(total)}</span>
            </span>
          </>
        );
        return (
          <li key={r.key} title={`${r.label}: ${r.values.map((v, i) => `${series[i]?.name} ${show(v)}`).join(", ")}`}>
            {r.href ? (
              <Link href={r.href} className="flex items-center gap-3 rounded-[3px] px-1 py-0.5 hover:bg-surface-hover">
                {inner}
              </Link>
            ) : (
              <div className="flex items-center gap-3 px-1 py-0.5">{inner}</div>
            )}
          </li>
        );
      })}
    </ul>
  );
}
