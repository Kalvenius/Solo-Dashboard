import { cn } from "@/lib/utils";

export type LegendItem = { name: string; color: string; shape?: "rect" | "line" };

/** Legend: işarə marka formasını təkrarlayır (sütun/sahə üçün kvadrat, xətt üçün qısa xətt). Mətn həmişə mətn rəngindədir. */
export function Legend({ items, className }: { items: LegendItem[]; className?: string }) {
  return (
    <ul className={cn("flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-muted", className)}>
      {items.map((it) => (
        <li key={it.name} className="inline-flex items-center gap-1.5">
          {it.shape === "line" ? (
            <span className="inline-block h-[2px] w-3 rounded-full" style={{ backgroundColor: it.color }} />
          ) : (
            <span className="inline-block h-2.5 w-2.5 rounded-[2px]" style={{ backgroundColor: it.color }} />
          )}
          {it.name}
        </li>
      ))}
    </ul>
  );
}
