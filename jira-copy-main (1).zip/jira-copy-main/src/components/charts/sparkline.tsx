"use client";

import { useT } from "@/i18n/client";
import { ACCENT, MUTED_SERIES } from "./theme";

/** Kiçik trend xətti: xətt ikinci dərəcəli rəngdə, cari (son) nöqtə vurğu rəngində. */
export function Sparkline({ values, width = 72, height = 20, label }: { values: number[]; width?: number; height?: number; label?: string }) {
  const t = useT("charts");
  if (!values.length) return null;
  const max = Math.max(...values, 1);
  const step = values.length > 1 ? (width - 6) / (values.length - 1) : 0;
  const pts = values.map((v, i) => [3 + i * step, height - 3 - (v / max) * (height - 6)] as const);
  const last = pts[pts.length - 1]!;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} role="img" aria-label={label ?? t("trend", { values: values.join(", ") })} className="shrink-0">
      <title>{label ?? values.join(", ")}</title>
      <polyline points={pts.map((p) => p.join(",")).join(" ")} fill="none" stroke={MUTED_SERIES} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={last[0]} cy={last[1]} r={2.5} fill={ACCENT} />
    </svg>
  );
}
