"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Sparkline } from "./sparkline";
import { ChartVars } from "./chart-vars";
import { useT } from "@/i18n/client";

/**
 * Göstərici plitəsi: ad · dəyər · (əvvəlki dövrə görə dəyişmə) · (trend).
 * Dəyişmənin rəngi = istiqamət × "artım yaxşıdır?"; həmişə ▲/▼ işarəsi ilə (yalnız rəng deyil).
 */
export function KpiTile({
  label,
  value,
  unit,
  current,
  previous,
  upIsGood = true,
  sub,
  trend,
  tone,
}: {
  label: string;
  value: ReactNode;
  unit?: string;
  current?: number | null;
  previous?: number | null;
  upIsGood?: boolean;
  sub?: ReactNode;
  trend?: number[];
  tone?: "bad";
}) {
  const t = useT("charts");
  let delta: ReactNode = null;
  let compared = false; // faiz dəyişməsi göstərilibsə "əvvəlki dövrə görə" əlavə olunur
  if (current != null && previous != null) {
    if (previous === 0 && current === 0) delta = <span className="text-ink-subtle">{t("unchanged")}</span>;
    else if (previous === 0) delta = <span className="text-ink-subtle">{t("prevZero")}</span>;
    else {
      const pct = Math.round(((current - previous) / previous) * 100);
      if (pct === 0) delta = <span className="text-ink-subtle">{t("unchanged")}</span>;
      else {
        const up = pct > 0;
        const good = up === upIsGood;
        compared = true;
        delta = (
          <span className={cn("font-semibold", good ? "text-success" : "text-danger")}>
            {up ? "▲" : "▼"} {Math.abs(pct)}%
          </span>
        );
      }
    }
  }
  return (
    <div className="flex min-w-0 flex-col rounded-[3px] border border-line bg-surface-raised px-4 py-3">
      <ChartVars />
      <div className="truncate text-xs font-medium text-ink-subtle" title={label}>
        {label}
      </div>
      <div className="mt-1.5 flex items-end justify-between gap-2">
        <div className={cn("text-[26px] font-semibold leading-none", tone === "bad" ? "text-danger" : "text-ink")}>
          {value}
          {unit && <span className="ml-1 text-sm font-medium text-ink-subtle">{unit}</span>}
        </div>
        {trend && <Sparkline values={trend} label={t("trendLabel", { label, values: trend.join(", ") })} />}
      </div>
      <div className="mt-2 min-h-[16px] text-xs text-ink-subtle">
        {delta && <span className="whitespace-nowrap">{delta}</span>}
        {delta && (sub || compared) ? <span className="mx-1">{sub ? "·" : ""}</span> : null}
        {sub ?? (compared ? <span>{t("vsPrevious")}</span> : null)}
      </div>
    </div>
  );
}
