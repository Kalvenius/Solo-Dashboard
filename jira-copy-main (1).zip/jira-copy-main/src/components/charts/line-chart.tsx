"use client";

import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CHART } from "./theme";
import { useFormat } from "@/i18n/client";
import { ChartTooltip } from "./tooltip";
import type { Series } from "./column-chart";

type Datum = Record<string, string | number | null>;

/** Xətt qrafiki: 2px xətlər, hover-də şaquli kursor xətti və bütün seriyaları göstərən tooltip. */
export function LineChartView({
  data,
  xKey = "label",
  series,
  height = 240,
  digits = 0,
  yWidth = 32,
}: {
  data: Datum[];
  xKey?: string;
  series: Series[];
  height?: number;
  /** dəyərlərin onluq rəqəm sayı (server komponentlərdən funksiya ötürmək olmur) */
  digits?: number;
  yWidth?: number;
}) {
  const names = Object.fromEntries(series.map((s) => [s.key, s.name]));
  const f = useFormat();
  const format = (v: number) => f.num(v, digits);
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke={CHART.grid} />
          <XAxis dataKey={xKey} tick={{ fill: CHART.tick, fontSize: 11 }} tickLine={false} axisLine={{ stroke: CHART.axis }} interval="preserveStartEnd" minTickGap={16} />
          <YAxis tick={{ fill: CHART.tick, fontSize: 11 }} tickLine={false} axisLine={false} width={yWidth} allowDecimals={digits > 0} tickFormatter={(v) => format(Number(v))} />
          <Tooltip cursor={{ stroke: CHART.axis, strokeWidth: 1 }} content={<ChartTooltip names={names} format={format} />} isAnimationActive={false} />
          {series.map((s) => (
            <Line
              key={s.key}
              dataKey={s.key}
              name={s.name}
              stroke={s.color}
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
              dot={false}
              activeDot={{ r: 4, fill: s.color, stroke: CHART.surface, strokeWidth: 2 }}
              connectNulls={false}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
