"use client";

import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CHART } from "./theme";
import { ChartTooltip } from "./tooltip";
import type { Series } from "./column-chart";

type Datum = Record<string, string | number | null>;

/** Yığılmış sahə (kumulyativ axın). Zolaqlar arasında 2px fon rəngli ayırıcı. Seriyalar aşağıdan yuxarıya sırayla. */
export function StackedArea({ data, xKey = "label", series, height = 260 }: { data: Datum[]; xKey?: string; series: Series[]; height?: number }) {
  const names = Object.fromEntries(series.map((s) => [s.key, s.name]));
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke={CHART.grid} />
          <XAxis dataKey={xKey} tick={{ fill: CHART.tick, fontSize: 11 }} tickLine={false} axisLine={{ stroke: CHART.axis }} interval="preserveStartEnd" minTickGap={16} />
          <YAxis allowDecimals={false} tick={{ fill: CHART.tick, fontSize: 11 }} tickLine={false} axisLine={false} width={32} />
          <Tooltip cursor={{ stroke: CHART.axis, strokeWidth: 1 }} content={<ChartTooltip names={names} total />} isAnimationActive={false} />
          {series.map((s) => (
            <Area
              key={s.key}
              dataKey={s.key}
              name={s.name}
              stackId="1"
              type="linear"
              stroke={CHART.surface}
              strokeWidth={2}
              fill={s.color}
              fillOpacity={1}
              activeDot={false}
              isAnimationActive={false}
            />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
