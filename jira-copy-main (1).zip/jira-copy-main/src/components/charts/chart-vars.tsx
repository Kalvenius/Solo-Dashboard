import { CHART_VARS_CSS } from "./theme";

/**
 * Qrafik rəng dəyişənləri (işıqlı + qaranlıq). React 19 href+precedence ilə <head>-ə qaldırır və təkrarları birləşdirir —
 * hər qrafik səhifəsində/komponentində təhlükəsiz render oluna bilər.
 */
export function ChartVars() {
  return (
    <style href="solo-chart-vars" precedence="default">
      {CHART_VARS_CSS}
    </style>
  );
}
