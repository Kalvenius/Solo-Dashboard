"use client";

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CHART } from "./theme";
import { useFormat } from "@/i18n/client";
import { ChartTooltip } from "./tooltip";

export type Series = { key: string; name: string; color: string };
type Datum = Record<string, string | number | null>;

/**
 * Sütun qrafiki (tək, qruplaşdırılmış və ya yığılmış).
 * Marka qaydaları: sütun ≤ 24px, yuxarı ucu 4px yuvarlaq, baza düz; yığılmış seqmentlər arasında 2px boşluq.
 */
export function ColumnChart({
  data,
  xKey = "label",
  series,
  stacked,
  height = 240,
  digits = 0,
  yWidth = 32,
}: {
  data: Datum[];
  xKey?: string;
  series: Series[];
  stacked?: boolean;
  height?: number;
  /** dəyərlərin onluq rəqəm sayı (server komponentlərdən funksiya ötürmək olmur) */
  digits?: number;
  yWidth?: number;
}) {
  const names = Object.fromEntries(series.map((s) => [s.key, s.name]));
  const f = useFormat();
  const format = (v: number) => f.num(v, digits);
  const keys = series.map((s) => s.key);
  const val = (d: Datum, k: string) => Number(d[k] ?? 0);
  const topKey = (d: Datum) => [...keys].reverse().find((k) => val(d, k) > 0);
  const bottomKey = (d: Datum) => keys.find((k) => val(d, k) > 0);

  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 4, left: 0, bottom: 0 }} barGap={2} barCategoryGap="20%">
          <CartesianGrid vertical={false} stroke={CHART.grid} />
          <XAxis dataKey={xKey} tick={{ fill: CHART.tick, fontSize: 11 }} tickLine={false} axisLine={{ stroke: CHART.axis }} interval="preserveStartEnd" minTickGap={8} />
          <YAxis tick={{ fill: CHART.tick, fontSize: 11 }} tickLine={false} axisLine={false} width={yWidth} allowDecimals={digits > 0} tickFormatter={(v) => format(Number(v))} />
          <Tooltip
            cursor={{ fill: CHART.hover }}
            content={<ChartTooltip names={names} format={format} hideZero={stacked} total={stacked} />}
            isAnimationActive={false}
          />
          {series.map((s) => (
            <Bar
              key={s.key}
              dataKey={s.key}
              name={s.name}
              fill={s.color}
              stackId={stacked ? "stack" : undefined}
              maxBarSize={24}
              isAnimationActive={false}
              shape={(p: unknown) => {
                const props = p as { x: number; y: number; width: number; height: number; payload: Datum };
                const round = stacked ? topKey(props.payload) === s.key : true;
                const gap = stacked && bottomKey(props.payload) !== s.key ? 2 : 0;
                return <RoundedTopRect {...props} fill={s.color} round={round} gapBottom={gap} />;
              }}
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function RoundedTopRect({
  x,
  y,
  width,
  height,
  fill,
  round,
  gapBottom = 0,
}: {
  x: number;
  y: number;
  width: number;
  height: number;
  fill: string;
  round: boolean;
  gapBottom?: number;
}) {
  const h = height - gapBottom;
  if (!h || h <= 0 || !width) return null;
  const r = round ? Math.min(4, width / 2, h) : 0;
  const d = `M${x},${y + h} L${x},${y + r} Q${x},${y} ${x + r},${y} L${x + width - r},${y} Q${x + width},${y} ${x + width},${y + r} L${x + width},${y + h} Z`;
  return <path d={d} fill={fill} />;
}
