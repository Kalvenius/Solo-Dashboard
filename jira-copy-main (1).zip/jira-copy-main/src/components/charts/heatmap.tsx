"use client";

import { addDays, format, isAfter, startOfDay } from "date-fns";
import { useFormat, useT } from "@/i18n/client";
import { CHART, HEAT_EMPTY, HEAT_RAMP } from "./theme";
import { ChartVars } from "./chart-vars";

/**
 * GitHub tipli aktivlik xəritəsi: sütunlar = həftələr (bazar ertəsindən başlayır), sətirlər = həftə günləri.
 * Ardıcıl tək rəngli (mavi) şkala; 0 = boz xana. Hər xananın tooltipi var.
 */
export function ActivityHeatmap({ start, weeks, counts }: { start: string; weeks: number; counts: Record<string, number> }) {
  const t = useT("charts");
  const f = useFormat();
  const dayLabels = [t("dayMon"), "", t("dayWed"), "", t("dayFri"), "", ""];
  const s = startOfDay(new Date(start));
  const today = startOfDay(new Date());
  const max = Math.max(1, ...Object.values(counts));
  const level = (v: number) => (v <= 0 ? -1 : Math.min(HEAT_RAMP.length - 1, Math.ceil((v / max) * HEAT_RAMP.length) - 1));
  const CELL = 12;
  const GAP = 3;
  const LEFT = 30;
  const TOP = 16;
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  const activeDays = Object.values(counts).filter((v) => v > 0).length;

  const cells: { x: number; y: number; d: Date; v: number }[] = [];
  const months: { x: number; label: string }[] = [];
  let lastMonth = -1;
  for (let w = 0; w < weeks; w++) {
    const weekStart = addDays(s, w * 7);
    if (weekStart.getMonth() !== lastMonth) {
      lastMonth = weekStart.getMonth();
      months.push({ x: LEFT + w * (CELL + GAP), label: f.pattern(weekStart, "LLL") });
    }
    for (let d = 0; d < 7; d++) {
      const day = addDays(weekStart, d);
      if (isAfter(day, today)) continue;
      cells.push({ x: LEFT + w * (CELL + GAP), y: TOP + d * (CELL + GAP), d: day, v: counts[format(day, "yyyy-MM-dd")] ?? 0 });
    }
  }
  const width = LEFT + weeks * (CELL + GAP);
  const height = TOP + 7 * (CELL + GAP);

  return (
    <div>
      <ChartVars />
      <div className="overflow-x-auto">
        <svg width={width} height={height} role="img" aria-label={t("heatAria", { weeks, total, days: activeDays })}>
          {months.map((m, i) => (
            <text key={i} x={m.x} y={10} fontSize={10} fill={CHART.tick}>
              {m.label}
            </text>
          ))}
          {[0, 2, 4].map((d) => (
            <text key={d} x={0} y={TOP + d * (CELL + GAP) + CELL - 2} fontSize={10} fill={CHART.tick}>
              {dayLabels[d]}
            </text>
          ))}
          {cells.map((c) => {
            const l = level(c.v);
            return (
              <rect key={c.x + "-" + c.y} x={c.x} y={c.y} width={CELL} height={CELL} rx={2} fill={l < 0 ? HEAT_EMPTY : HEAT_RAMP[l]} className="hover:stroke-ink" strokeWidth={1}>
                <title>{t("heatCell", { date: f.pattern(c.d, "PPPP"), n: c.v })}</title>
              </rect>
            );
          })}
        </svg>
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-ink-subtle">
        <span>
          {t("heatTotal", { weeks, total })} · {t("heatDays", { n: activeDays })}
        </span>
        <span className="flex items-center gap-1">
          {t("less")}
          <span className="inline-block h-2.5 w-2.5 rounded-[2px]" style={{ backgroundColor: HEAT_EMPTY }} />
          {HEAT_RAMP.map((c) => (
            <span key={c} className="inline-block h-2.5 w-2.5 rounded-[2px]" style={{ backgroundColor: c }} />
          ))}
          {t("more")}
        </span>
      </div>
    </div>
  );
}
