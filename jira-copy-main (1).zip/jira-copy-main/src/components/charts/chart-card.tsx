"use client";

import { useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";
import { ChartVars } from "./chart-vars";

export type ChartTable = { columns: string[]; rows: (string | number)[][] };

/**
 * Qrafik kartı: başlıq, alt başlıq, legend və "Qrafik / Cədvəl" keçidi.
 * Cədvəl görünüşü hər qrafikin dəyərlərini hover olmadan oxumağa imkan verir (əlçatanlıq).
 */
export function ChartCard({
  title,
  subtitle,
  legend,
  table,
  actions,
  children,
  className,
}: {
  title: ReactNode;
  subtitle?: ReactNode;
  legend?: ReactNode;
  table?: ChartTable;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const [view, setView] = useState<"chart" | "table">("chart");
  const t = useT("charts");
  return (
    <section className={cn("flex min-w-0 flex-col rounded-[3px] border border-line bg-surface-raised", className)}>
      <ChartVars />
      <header className="flex flex-wrap items-start justify-between gap-3 px-4 pt-3">
        <div className="min-w-0">
          <h2 className="text-sm font-semibold text-ink">{title}</h2>
          {subtitle && <p className="mt-0.5 text-xs text-ink-subtle">{subtitle}</p>}
        </div>
        <div className="flex items-center gap-2">
          {actions}
          {table && (
            <div className="flex rounded-[3px] bg-tint-1 p-0.5 text-xs font-medium" role="tablist">
              {(["chart", "table"] as const).map((v) => (
                <button
                  key={v}
                  role="tab"
                  aria-selected={view === v}
                  onClick={() => setView(v)}
                  className={cn("rounded-[2px] px-2 py-0.5", view === v ? "bg-surface-raised text-ink shadow-card" : "text-ink-subtle hover:text-ink")}
                >
                  {v === "chart" ? t("chart") : t("table")}
                </button>
              ))}
            </div>
          )}
        </div>
      </header>
      {legend && view === "chart" && <div className="px-4 pt-2">{legend}</div>}
      <div className="min-w-0 flex-1 px-4 pb-4 pt-3">
        {view === "chart" || !table ? children : <DataTable table={table} />}
      </div>
    </section>
  );
}

export function DataTable({ table }: { table: ChartTable }) {
  return (
    <div className="max-h-[320px] overflow-auto">
      <table className="w-full text-left text-[13px]">
        <thead className="sticky top-0 bg-surface-raised">
          <tr className="border-b border-line">
            {table.columns.map((c, i) => (
              <th key={i} className={cn("py-1.5 pr-3 text-xs font-semibold text-ink-subtle", i > 0 && "text-right")}>
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {table.rows.map((r, i) => (
            <tr key={i} className="border-b border-line/60 last:border-0">
              {r.map((cell, j) => (
                <td key={j} className={cn("py-1.5 pr-3 text-ink", j > 0 && "text-right tabular-nums")}>
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
