"use client";

import { useT } from "@/i18n/client";

/* Recharts üçün tooltip: dəyər qalın və öndə, seriya adı ikinci dərəcəli; seriya qısa xəttlə işarələnir. */

type Row = { name?: string | number; value?: number | string | null | (string | number)[]; color?: string; dataKey?: string | number; payload?: Record<string, unknown> };

export function ChartTooltip({
  active,
  payload,
  label,
  format = (v) => String(v),
  names,
  hideZero,
  total,
}: {
  active?: boolean;
  payload?: Row[];
  label?: string | number;
  format?: (v: number) => string;
  names?: Record<string, string>;
  hideZero?: boolean;
  total?: boolean;
}) {
  const t = useT("charts");
  if (!active || !payload?.length) return null;
  const rows = payload.filter((p) => p.value != null && (!hideZero || Number(p.value) !== 0)).slice().reverse();
  const sum = payload.reduce((s, p) => s + (Number(p.value) || 0), 0);
  return (
    <div className="min-w-[140px] rounded-[3px] border border-line bg-surface-raised px-3 py-2 text-xs shadow-overlay">
      <div className="mb-1 text-ink-subtle">{label}</div>
      {rows.length === 0 && <div className="text-ink-subtle">{t("noData")}</div>}
      {rows.map((p) => (
        <div key={String(p.dataKey)} className="flex items-center gap-2 py-0.5">
          <span className="inline-block h-[2px] w-3 shrink-0 rounded-full" style={{ backgroundColor: p.color }} />
          <span className="font-semibold tabular-nums text-ink">{format(Number(p.value))}</span>
          <span className="truncate text-ink-subtle">{names?.[String(p.dataKey)] ?? p.name}</span>
        </div>
      ))}
      {total && rows.length > 1 && (
        <div className="mt-1 flex items-center gap-2 border-t border-line pt-1">
          <span className="inline-block w-3" />
          <span className="font-semibold tabular-nums text-ink">{format(sum)}</span>
          <span className="text-ink-subtle">{t("total")}</span>
        </div>
      )}
    </div>
  );
}
