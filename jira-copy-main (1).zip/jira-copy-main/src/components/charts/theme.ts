// Qrafik tokenləri — CSS dəyişənləri kimi (işıqlı/qaranlıq rejim .dark sinfi ilə avtomatik dəyişir).
// var() həm HTML stillərində, həm də SVG atributlarında (recharts fill/stroke) işləyir — server komponentləri də
// bu sətirləri ötürə bilər, tema dəyişəndə yenidən render lazım deyil.
//
// Rənglər dataviz validatoru ilə yoxlanılıb:
//  - SERIES: kateqorial palitra, sabit sıra. İşıqlı: ağ fonda bütün yoxlamalar PASS (3 açıq slot <3:1 → hər qrafikdə
//    legend + "Cədvəl" görünüşü var). Qaranlıq: eyni 8 çalar qaranlıq fon (#22272B) üçün pillələnib — bütün yoxlamalar PASS.
//  - STATUS_RAMP: ordinal mavi pillə. İşıqlı: Görüləcək açıq → Hazırdır tünd. Qaranlıq: tərsinə (Hazırdır ən parlaq),
//    ən tünd pillə fonla 2.37:1 (≥2:1), addımlar bərabər aralıqlı — --ordinal yoxlaması PASS.
//  - HEAT: ardıcıl mavi pillələr; 0 = boş xana.
import type { Status } from "@/lib/constants";

type Mode = { [name: string]: string };

const LIGHT: Mode = {
  s1: "#2a78d6", s2: "#eb6834", s3: "#1baf7a", s4: "#eda100", s5: "#e87ba4", s6: "#008300", s7: "#6250d6", s8: "#e34948",
  other: "#8590A2",
  muted: "#B3B9C4",
  "st-todo": "#86b6ef", "st-progress": "#3987e5", "st-review": "#1c5cab", "st-done": "#0d366b",
  "heat-0": "#EBECF0", "heat-1": "#cde2fb", "heat-2": "#86b6ef", "heat-3": "#3987e5", "heat-4": "#1c5cab", "heat-5": "#0d366b",
  surface: "#FFFFFF", grid: "#EBECF0", axis: "#C1C7D0", tick: "#626F86", ink: "#172B4D", "ink-muted": "#44546F",
  hover: "rgba(9,30,66,.04)", good: "#216E4E", bad: "#AE2E24",
  "bar-track": "#F1F2F4", "bar-epic": "#6E5DC6", today: "#E56910",
};

const DARK: Mode = {
  s1: "#3987e5", s2: "#d95926", s3: "#199e70", s4: "#c98500", s5: "#d55181", s6: "#008300", s7: "#9085e9", s8: "#e66767",
  other: "#8C9BAB",
  muted: "#596773",
  "st-todo": "#1f5fae", "st-progress": "#4a8fe6", "st-review": "#86b6ef", "st-done": "#cde2fb",
  "heat-0": "#2C333A", "heat-1": "#184f95", "heat-2": "#256abf", "heat-3": "#3987e5", "heat-4": "#6da7ec", "heat-5": "#b7d3f6",
  surface: "#22272B", grid: "#2C333A", axis: "#454F59", tick: "#8C9BAB", ink: "#B6C2CF", "ink-muted": "#9FADBC",
  hover: "rgba(161,189,217,.08)", good: "#7EE2B8", bad: "#FD9891",
  "bar-track": "#2C333A", "bar-epic": "#9085e9", today: "#F38A3F",
};

const block = (m: Mode) =>
  Object.entries(m)
    .map(([k, v]) => `--chart-${k}:${v};`)
    .join("");

/** <ChartVars /> bu CSS-i bir dəfə <head>-ə qoyur */
export const CHART_VARS_CSS = `:root{${block(LIGHT)}}.dark{${block(DARK)}}`;

const v = (name: string) => `var(--chart-${name})`;

export const SERIES_COLORS = ["s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8"].map(v);
export const OTHER_COLOR = v("other");

/** Tək seriyalı qrafiklər üçün vurğu rəngi (slot 1) */
export const ACCENT = SERIES_COLORS[0]!;
/** İkinci dərəcəli seriya (plan, öhdəlik, ideal xətt) */
export const MUTED_SERIES = v("muted");

export const STATUS_RAMP: Record<Status, string> = {
  TODO: v("st-todo"),
  IN_PROGRESS: v("st-progress"),
  IN_REVIEW: v("st-review"),
  DONE: v("st-done"),
};

/** Ardıcıl (sequential) mavi pillələr — aktivlik xəritəsi üçün; 0 = boş xana */
export const HEAT_EMPTY = v("heat-0");
export const HEAT_RAMP = [1, 2, 3, 4, 5].map((i) => v(`heat-${i}`));

export const CHART = {
  surface: v("surface"),
  grid: v("grid"),
  axis: v("axis"),
  tick: v("tick"),
  ink: v("ink"),
  inkMuted: v("ink-muted"),
  hover: v("hover"),
  good: v("good"),
  bad: v("bad"),
  barTrack: v("bar-track"),
  epic: v("bar-epic"),
  today: v("today"),
};

/** Dəqiqəni bir onluq rəqəmli saata çevirir (format: f.num(minutesToHours(m), 1)) */
export const minutesToHours = (minutes: number) => Math.round((minutes / 60) * 10) / 10;
