"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { BarChart3, ChevronsLeft, ChevronsRight, GanttChartSquare, KanbanSquare, List, ListTodo, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { ProjectAvatar } from "@/components/ui/misc";
import { useT } from "@/i18n/client";

type P = { key: string; name: string; color: string; type: string };

export function ProjectSidebar({ project }: { project: P }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const t = useT("nav");
  const tc = useT("common");
  const base = `/projects/${project.key}`;

  const items = [
    { href: `${base}/board`, label: tc("board"), icon: KanbanSquare },
    ...(project.type === "SCRUM" ? [{ href: `${base}/backlog`, label: tc("backlog"), icon: ListTodo }] : []),
    { href: `${base}/list`, label: t("list"), icon: List },
    { href: `${base}/timeline`, label: t("timeline"), icon: GanttChartSquare },
    { href: `${base}/reports`, label: t("reports"), icon: BarChart3 },
  ];

  if (collapsed) {
    return (
      <aside className="flex w-4 shrink-0 flex-col border-r border-line bg-surface-sunken">
        <button
          onClick={() => setCollapsed(false)}
          className="mt-4 -mr-3 ml-auto flex h-6 w-6 items-center justify-center rounded-full border border-line bg-surface-raised text-ink-muted shadow-card hover:bg-brand-50"
          aria-label={t("expandSidebar")}
        >
          <ChevronsRight className="h-4 w-4" />
        </button>
      </aside>
    );
  }

  return (
    <aside className="group relative flex w-60 shrink-0 flex-col border-r border-line bg-surface-sunken">
      <div className="flex items-center gap-2.5 px-4 pb-4 pt-5">
        <ProjectAvatar project={project} size="lg" />
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold text-ink">{project.name}</div>
          <div className="text-xs text-ink-subtle">{project.type === "KANBAN" ? t("kanbanProject") : t("scrumProject")}</div>
        </div>
      </div>
      <nav className="flex flex-col gap-0.5 px-2">
        <div className="px-2 pb-1 pt-2 text-[11px] font-bold uppercase text-ink-subtle">{t("planning")}</div>
        {items.map((it) => {
          const active = pathname === it.href || pathname.startsWith(it.href + "/");
          return (
            <Link
              key={it.href}
              href={it.href}
              className={cn(
                "flex h-9 items-center gap-3 rounded-[3px] px-2 text-sm text-ink-muted hover:bg-tint-1",
                active && "bg-brand-50 font-medium text-brand-700 hover:bg-brand-50",
              )}
            >
              <it.icon className="h-4 w-4" />
              {it.label}
            </Link>
          );
        })}
        <div className="my-2 border-t border-line" />
        <Link
          href={`${base}/settings`}
          className={cn(
            "flex h-9 items-center gap-3 rounded-[3px] px-2 text-sm text-ink-muted hover:bg-tint-1",
            pathname.startsWith(`${base}/settings`) && "bg-brand-50 font-medium text-brand-700",
          )}
        >
          <Settings className="h-4 w-4" />
          {t("projectSettings")}
        </Link>
      </nav>
      <button
        onClick={() => setCollapsed(true)}
        className="absolute -right-3 top-5 hidden h-6 w-6 items-center justify-center rounded-full border border-line bg-surface-raised text-ink-muted shadow-card hover:bg-brand-50 group-hover:flex"
        aria-label={t("collapseSidebar")}
      >
        <ChevronsLeft className="h-4 w-4" />
      </button>
    </aside>
  );
}
