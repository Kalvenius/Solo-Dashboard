"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Search } from "lucide-react";
import { quickSearch, type QuickSearchResult } from "@/lib/actions/search";
import { cn } from "@/lib/utils";
import { StatusLozenge } from "@/components/ui/lozenge";
import { ProjectAvatar } from "@/components/ui/misc";
import { IssueTypeIcon } from "@/components/issue/icons";
import { useT } from "@/i18n/client";

type Item = { href: string; kind: "issue" | "project"; key: string };

const EMPTY: QuickSearchResult = { issues: [], projects: [] };

/** Yuxarı paneldəki axtarış: "/" ilə fokuslanır, açar və ya başlıq üzrə tapır */
export function GlobalSearch() {
  const router = useRouter();
  const t = useT("search");
  const tc = useT("common");
  const te = useT("enums");
  const inputRef = useRef<HTMLInputElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const [q, setQ] = useState("");
  const [focused, setFocused] = useState(false);
  const [result, setResult] = useState<QuickSearchResult>(EMPTY);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(-1);
  const reqId = useRef(0);

  // "/" qısayolu
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "/" || e.metaKey || e.ctrlKey || e.altKey) return;
      const el = e.target as HTMLElement | null;
      if (el && (el.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(el.tagName))) return;
      e.preventDefault();
      inputRef.current?.focus();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  // kənara klikdə bağla
  useEffect(() => {
    if (!focused) return;
    const onDown = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setFocused(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [focused]);

  // debounce ilə axtarış
  useEffect(() => {
    const term = q.trim();
    if (!term) {
      setResult(EMPTY);
      setLoading(false);
      return;
    }
    setLoading(true);
    const id = ++reqId.current;
    const timer = setTimeout(async () => {
      try {
        const r = await quickSearch(term);
        if (id === reqId.current) {
          setResult(r);
          setActive(-1);
        }
      } finally {
        if (id === reqId.current) setLoading(false);
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [q]);

  const items: Item[] = [
    ...result.issues.map((i) => ({ href: `/browse/${i.key}`, kind: "issue" as const, key: i.key })),
    ...result.projects.map((p) => ({ href: `/projects/${p.key}/board`, kind: "project" as const, key: p.key })),
  ];

  const go = (href: string) => {
    setFocused(false);
    setQ("");
    setResult(EMPTY);
    inputRef.current?.blur();
    router.push(href);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Escape") {
      setFocused(false);
      inputRef.current?.blur();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive((a) => (items.length ? (a + 1) % items.length : -1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => (items.length ? (a <= 0 ? items.length - 1 : a - 1) : -1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const term = q.trim();
      if (active >= 0 && items[active]) go(items[active]!.href);
      else if (term) go(`/issues?q=${encodeURIComponent(term)}`);
    }
  };

  const showPanel = focused && q.trim().length > 0;
  let idx = -1;

  return (
    <div ref={boxRef} className="relative hidden lg:block">
      <Search className="pointer-events-none absolute left-2 top-1/2 z-10 h-4 w-4 -translate-y-1/2 text-ink-subtle" />
      <input
        ref={inputRef}
        value={q}
        onChange={(e) => setQ(e.target.value)}
        onFocus={() => setFocused(true)}
        onKeyDown={onKeyDown}
        placeholder={t("placeholder")}
        aria-label={t("placeholder")}
        className={cn(
          "h-8 rounded-[3px] border-2 border-line bg-input pl-8 pr-8 text-sm text-ink transition-[width] duration-150 placeholder:text-ink-faint focus:border-brand-500 focus:bg-surface-raised focus:outline-none",
          focused ? "w-96" : "w-52",
        )}
      />
      {!focused && !q && (
        <kbd className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 rounded border border-line px-1 text-[10px] text-ink-subtle">/</kbd>
      )}
      {loading && <span className="absolute right-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />}

      {showPanel && (
        <div className="absolute right-0 z-50 mt-1 w-[440px] rounded-[3px] border border-line bg-surface-overlay py-1 shadow-overlay">
          {result.issues.length > 0 && (
            <>
              <div className="px-3 pb-1 pt-2 text-[11px] font-bold uppercase text-ink-subtle">{tc("issues")}</div>
              {result.issues.map((i) => {
                idx++;
                const my = idx;
                return (
                  <button
                    key={i.key}
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => go(`/browse/${i.key}`)}
                    onMouseEnter={() => setActive(my)}
                    className={cn("flex w-full items-center gap-2.5 px-3 py-1.5 text-left", active === my ? "bg-brand-50" : "hover:bg-surface-hover")}
                  >
                    <IssueTypeIcon type={i.type} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm text-ink">{i.title}</div>
                      <div className="truncate text-xs text-ink-subtle">
                        {i.key} · {i.projectName}
                      </div>
                    </div>
                    <StatusLozenge status={i.status} />
                  </button>
                );
              })}
            </>
          )}
          {result.projects.length > 0 && (
            <>
              <div className="px-3 pb-1 pt-2 text-[11px] font-bold uppercase text-ink-subtle">{tc("projects")}</div>
              {result.projects.map((p) => {
                idx++;
                const my = idx;
                return (
                  <button
                    key={p.key}
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => go(`/projects/${p.key}/board`)}
                    onMouseEnter={() => setActive(my)}
                    className={cn("flex w-full items-center gap-2.5 px-3 py-1.5 text-left", active === my ? "bg-brand-50" : "hover:bg-surface-hover")}
                  >
                    <ProjectAvatar project={p} size="sm" />
                    <span className="flex-1 truncate text-sm text-ink">{p.name}</span>
                    <span className="text-xs text-ink-subtle">{te(p.type === "KANBAN" ? "projectType.KANBAN" : "projectType.SCRUM")}</span>
                  </button>
                );
              })}
            </>
          )}
          {!loading && items.length === 0 && <div className="px-3 py-3 text-sm text-ink-subtle">{t("nothingFound", { q: q.trim() })}</div>}
          <div className="mt-1 border-t border-line">
            <button
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => go(`/issues?q=${encodeURIComponent(q.trim())}`)}
              className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-brand-600 hover:bg-surface-hover"
            >
              <Search className="h-4 w-4" /> {t("searchAll", { q: q.trim() })}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
