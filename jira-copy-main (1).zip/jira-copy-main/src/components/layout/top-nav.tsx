"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronDown, LogOut, Settings, UserRound, Users } from "lucide-react";
import type { CurrentUser } from "@/lib/auth";
import { logoutAction } from "@/lib/actions/auth";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { Popover } from "@/components/ui/popover";
import { ProjectAvatar } from "@/components/ui/misc";
import { CreateIssueButton } from "@/components/issue/create-issue-button";
import { NotificationsBell } from "./notifications-bell";
import { GlobalSearch } from "./global-search";
import { LanguageSwitch, ThemeSwitch } from "./preferences";
import { useT } from "@/i18n/client";

export type NavProject = { id: string; key: string; name: string; color: string; type: string };

export function TopNav({ user, projects, unread }: { user: CurrentUser; projects: NavProject[]; unread: number }) {
  const pathname = usePathname();
  const t = useT("nav");
  const te = useT("enums");
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");

  const link = (href: string, label: string) => (
    <Link
      href={href}
      className={cn(
        "relative flex h-full items-center px-2 text-sm font-medium text-ink-muted hover:text-brand-600",
        isActive(href) && "text-brand-600 after:absolute after:inset-x-1 after:bottom-0 after:h-[3px] after:rounded-t after:bg-brand-600",
      )}
    >
      {label}
    </Link>
  );

  return (
    <header className="z-30 flex h-14 shrink-0 items-center gap-2 border-b border-line bg-surface px-3">
      <Link href="/your-work" className="mr-2 flex items-center gap-1.5 rounded px-1.5 py-1 hover:bg-surface-hover">
        <img src="/icon.svg" alt="" className="h-6 w-6" />
        <span className="text-[17px] font-bold text-ink">Solo</span>
      </Link>

      <nav className="hidden h-full items-center gap-1 md:flex">
        {link("/your-work", t("yourWork"))}
        <Popover
          className="w-72"
          trigger={({ toggle, open }) => (
            <button
              onClick={toggle}
              className={cn(
                "relative flex h-14 items-center gap-1 px-2 text-sm font-medium text-ink-muted hover:text-brand-600",
                (isActive("/projects") || open) &&
                  "text-brand-600 after:absolute after:inset-x-1 after:bottom-0 after:h-[3px] after:rounded-t after:bg-brand-600",
              )}
            >
              {t("projects")} <ChevronDown className="h-4 w-4" />
            </button>
          )}
        >
          {(close) => (
            <div>
              <div className="px-3 pb-1 pt-2 text-[11px] font-bold uppercase text-ink-subtle">{t("projects")}</div>
              {projects.length === 0 && <div className="px-3 py-2 text-sm text-ink-subtle">{t("noProjectsYet")}</div>}
              {projects.slice(0, 8).map((p) => (
                <Link key={p.id} href={`/projects/${p.key}/board`} onClick={close} className="flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-surface-hover">
                  <ProjectAvatar project={p} size="sm" />
                  <span className="flex-1 truncate">{p.name}</span>
                  <span className="text-xs text-ink-subtle">{te(p.type === "KANBAN" ? "projectType.KANBAN" : "projectType.SCRUM")}</span>
                </Link>
              ))}
              <div className="my-1 border-t border-line" />
              <Link href="/projects" onClick={close} className="block px-3 py-1.5 text-sm hover:bg-surface-hover">
                {t("allProjects")}
              </Link>
            </div>
          )}
        </Popover>
        {link("/issues", t("filters"))}
        {link("/people", t("people"))}
        {user.role === "ADMIN" && link("/admin", t("admin"))}
      </nav>

      <div className="ml-2">
        <CreateIssueButton projects={projects} />
      </div>

      <div className="ml-auto flex items-center gap-1">
        <GlobalSearch />
        <NotificationsBell unread={unread} />
        <Popover
          align="right"
          className="w-72"
          trigger={({ toggle }) => (
            <button onClick={toggle} className="ml-1 rounded-full p-0.5 hover:ring-4 hover:ring-tint-1" aria-label={t("profileMenu")}>
              <Avatar user={user} size="md" />
            </button>
          )}
        >
          {(close) => (
            <div>
              <div className="flex items-center gap-3 px-3 py-2">
                <Avatar user={user} size="md" />
                <div className="min-w-0">
                  <div className="truncate text-sm font-semibold text-ink">{user.name}</div>
                  <div className="truncate text-xs text-ink-subtle">{user.email}</div>
                </div>
              </div>
              <div className="my-1 border-t border-line" />
              <Link href={`/people/${user.id}`} onClick={close} className="flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-surface-hover">
                <UserRound className="h-4 w-4 text-ink-subtle" /> {t("myDashboard")}
              </Link>
              <Link href="/profile" onClick={close} className="flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-surface-hover">
                <Settings className="h-4 w-4 text-ink-subtle" /> {t("profileSettings")}
              </Link>
              {user.role === "ADMIN" && (
                <Link href="/admin/users" onClick={close} className="flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-surface-hover">
                  <Users className="h-4 w-4 text-ink-subtle" /> {t("users")}
                </Link>
              )}
              <div className="my-1 border-t border-line" />
              <div className="space-y-2 px-3 py-2">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold text-ink-subtle">{t("language")}</span>
                  <LanguageSwitch className="w-36" />
                </div>
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold text-ink-subtle">{t("theme")}</span>
                  <ThemeSwitch className="w-36" />
                </div>
              </div>
              <div className="my-1 border-t border-line" />
              <form action={logoutAction}>
                <button type="submit" className="flex w-full items-center gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-hover">
                  <LogOut className="h-4 w-4 text-ink-subtle" /> {t("logout")}
                </button>
              </form>
            </div>
          )}
        </Popover>
      </div>
    </header>
  );
}
