"use client";

import { Monitor, Moon, Sun } from "lucide-react";
import { LOCALES, LOCALE_LABEL, LOCALE_SHORT } from "@/i18n/config";
import { useLocale, useSetLocale, useT } from "@/i18n/client";
import { cn } from "@/lib/utils";
import type { Theme } from "@/lib/theme";
import { useTheme } from "./theme";

const seg = "flex h-7 flex-1 items-center justify-center gap-1 rounded-[3px] text-xs font-medium transition-colors";

/** Dil seçimi: AZ / EN / RU */
export function LanguageSwitch({ className }: { className?: string }) {
  const locale = useLocale();
  const setLocale = useSetLocale();
  return (
    <div className={cn("flex gap-0.5 rounded-[3px] bg-tint-1 p-0.5", className)} role="radiogroup">
      {LOCALES.map((l) => (
        <button
          key={l}
          type="button"
          role="radio"
          aria-checked={l === locale}
          title={LOCALE_LABEL[l]}
          onClick={() => l !== locale && setLocale(l)}
          className={cn(seg, l === locale ? "bg-surface-raised text-brand-600 shadow-card" : "text-ink-muted hover:text-ink")}
        >
          {LOCALE_SHORT[l]}
        </button>
      ))}
    </div>
  );
}

/** Görünüş seçimi: Açıq / Qaranlıq / Sistem */
export function ThemeSwitch({ className, withLabels }: { className?: string; withLabels?: boolean }) {
  const { theme, setTheme } = useTheme();
  const t = useT("nav");
  const items: { value: Theme; label: string; icon: typeof Sun }[] = [
    { value: "light", label: t("themeLight"), icon: Sun },
    { value: "dark", label: t("themeDark"), icon: Moon },
    { value: "system", label: t("themeSystem"), icon: Monitor },
  ];
  return (
    <div className={cn("flex gap-0.5 rounded-[3px] bg-tint-1 p-0.5", className)} role="radiogroup">
      {items.map((it) => (
        <button
          key={it.value}
          type="button"
          role="radio"
          aria-checked={theme === it.value}
          title={it.label}
          onClick={() => setTheme(it.value)}
          className={cn(seg, "px-2", theme === it.value ? "bg-surface-raised text-brand-600 shadow-card" : "text-ink-muted hover:text-ink")}
        >
          <it.icon className="h-3.5 w-3.5" />
          {withLabels && <span>{it.label}</span>}
        </button>
      ))}
    </div>
  );
}
