"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Bell } from "lucide-react";
import { listNotifications, markAllRead, markNotificationRead, unreadCount } from "@/lib/actions/notifications";
import { cn } from "@/lib/utils";
import { STATUSES, type Status } from "@/lib/constants";
import { useFormat, useT } from "@/i18n/client";
import type { Translator } from "@/i18n/types";
import { Avatar } from "@/components/ui/avatar";
import { Popover } from "@/components/ui/popover";

type Item = {
  id: string;
  message: string;
  read: boolean;
  createdAt: Date;
  actor: { id: string; name: string; avatarColor: string } | null;
  issue: { key: string; title: string; type: string } | null;
};

const KINDS = ["assigned", "status", "commented", "mentioned"] as const;
type Kind = (typeof KINDS)[number];

/**
 * Bildiriş mətni bazada JSON kimi saxlanılır: {"k":"status","p":{"key":"WEB-5","status":"DONE"}} (notifMessage).
 * Köhnə (mətn) bildirişlər olduğu kimi göstərilir.
 */
function renderMessage(n: Item, t: Translator<"notifications">, te: Translator<"enums">): string {
  try {
    const parsed = JSON.parse(n.message) as { k?: string; p?: Record<string, string> };
    if (!parsed.k || !(KINDS as readonly string[]).includes(parsed.k)) return n.message;
    const p = { ...(parsed.p ?? {}) };
    const params: Record<string, string> = { ...p, actor: n.actor?.name ?? t("someone"), key: p.key ?? n.issue?.key ?? "" };
    if (parsed.k === "status" && p.status && (STATUSES as readonly string[]).includes(p.status)) params.status = te(`status.${p.status as Status}`);
    return t(`notif.${parsed.k as Kind}`, params);
  } catch {
    return n.message;
  }
}

export function NotificationsBell({ unread }: { unread: number }) {
  const t = useT("notifications");
  const te = useT("enums");
  const f = useFormat();
  const router = useRouter();
  const [count, setCount] = useState(unread);
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Item[] | null>(null);

  useEffect(() => setCount(unread), [unread]);

  // hər dəqiqə oxunmamış sayını yenilə
  useEffect(() => {
    const t = setInterval(async () => {
      if (document.visibilityState !== "visible") return;
      const r = await unreadCount();
      if (r.ok && typeof r.data === "number") setCount(r.data);
    }, 60_000);
    return () => clearInterval(t);
  }, []);

  const load = useCallback(async () => {
    const [list, c] = await Promise.all([listNotifications(), unreadCount()]);
    if (list.ok && list.data) setItems(list.data);
    if (c.ok && typeof c.data === "number") setCount(c.data);
  }, []);

  const onOpenChange = (o: boolean) => {
    setOpen(o);
    if (o) load();
  };

  const openItem = async (n: Item) => {
    setOpen(false);
    if (!n.read) {
      setItems((prev) => prev?.map((x) => (x.id === n.id ? { ...x, read: true } : x)) ?? null);
      setCount((c) => Math.max(0, c - 1));
      await markNotificationRead(n.id);
    }
    if (n.issue) router.push(`/browse/${n.issue.key}`);
  };

  const readAll = async () => {
    setItems((prev) => prev?.map((x) => ({ ...x, read: true })) ?? null);
    setCount(0);
    await markAllRead();
  };

  return (
    <Popover
      align="right"
      open={open}
      onOpenChange={onOpenChange}
      className="w-[380px] max-w-[calc(100vw-24px)] py-0"
      trigger={({ toggle }) => (
        <button
          type="button"
          onClick={toggle}
          className={cn("relative rounded-full p-2 text-ink-muted hover:bg-surface-hover", open && "bg-brand-50 text-brand-600")}
          aria-label={count ? t("unreadAria", { n: count }) : t("title")}
          title={t("title")}
        >
          <Bell className="h-5 w-5" />
          {count > 0 && (
            <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger-bold px-1 text-[10px] font-bold leading-none text-white ring-2 ring-surface">
              {count > 9 ? "9+" : count}
            </span>
          )}
        </button>
      )}
    >
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <h3 className="text-base font-semibold text-ink">{t("title")}</h3>
        {items?.some((n) => !n.read) && (
          <button type="button" onClick={readAll} className="text-xs font-medium text-brand-600 hover:underline">
            {t("markAllRead")}
          </button>
        )}
      </div>
      <div className="max-h-[420px] overflow-y-auto">
        {items === null && (
          <div className="flex justify-center py-8">
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-brand-600 border-t-transparent" />
          </div>
        )}
        {items?.length === 0 && (
          <div className="px-4 py-10 text-center">
            <Bell className="mx-auto h-8 w-8 text-ink-faint" />
            <p className="mt-2 text-sm text-ink-subtle">{t("empty")}</p>
          </div>
        )}
        {items?.map((n) => (
          <button
            key={n.id}
            type="button"
            onClick={() => openItem(n)}
            className={cn("flex w-full gap-3 border-b border-line px-4 py-3 text-left last:border-b-0 hover:bg-surface-hover", !n.read && "bg-brand-50/60")}
          >
            <Avatar user={n.actor} size="md" />
            <div className="min-w-0 flex-1">
              <div className="text-sm text-ink">{renderMessage(n, t, te)}</div>
              {n.issue && <div className="mt-0.5 truncate text-xs text-ink-subtle">{n.issue.key} · {n.issue.title}</div>}
              <div className="mt-0.5 text-xs text-ink-subtle" suppressHydrationWarning>
                {f.relative(n.createdAt)}
              </div>
            </div>
            {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand-600" aria-label={t("unread")} />}
          </button>
        ))}
      </div>
    </Popover>
  );
}
