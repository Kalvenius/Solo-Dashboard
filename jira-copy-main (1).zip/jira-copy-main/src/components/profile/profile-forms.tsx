"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { changePassword, updateProfile } from "@/lib/actions/users";
import { AVATAR_COLORS } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input } from "@/components/ui/input";
import { LanguageSwitch, ThemeSwitch } from "@/components/layout/preferences";
import { useT } from "@/i18n/client";

type P = { name: string; title: string | null; department: string | null; avatarColor: string };

function Saved({ show, text }: { show: boolean; text: string }) {
  return show ? <span className="text-sm text-success">{text}</span> : null;
}

/** Dil və görünüş seçimi (cookie-də, bu brauzer üçün saxlanılır) */
export function PreferencesSection() {
  const t = useT("profile");
  return (
    <section>
      <h2 className="mb-1 border-b border-line pb-2 text-base font-semibold text-ink">{t("preferences")}</h2>
      <p className="mb-4 text-sm text-ink-subtle">{t("preferencesHint")}</p>
      <div className="grid max-w-md grid-cols-[120px_1fr] items-center gap-x-4 gap-y-3">
        <span className="text-sm font-medium text-ink-muted">{t("language")}</span>
        <LanguageSwitch className="w-56" />
        <span className="text-sm font-medium text-ink-muted">{t("theme")}</span>
        <ThemeSwitch withLabels className="w-fit" />
      </div>
    </section>
  );
}

export function ProfileForm({ user }: { user: P }) {
  const router = useRouter();
  const t = useT("profile");
  const tc = useT("common");
  const [name, setName] = useState(user.name);
  const [title, setTitle] = useState(user.title ?? "");
  const [department, setDepartment] = useState(user.department ?? "");
  const [avatarColor, setColor] = useState(user.avatarColor);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [pending, start] = useTransition();

  const dirty = name !== user.name || title !== (user.title ?? "") || department !== (user.department ?? "") || avatarColor !== user.avatarColor;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaved(false);
    start(async () => {
      const res = await updateProfile({ name, title, department, avatarColor });
      if (!res.ok) return setError(res.error);
      setSaved(true);
      router.refresh();
    });
  };

  return (
    <section>
      <h2 className="mb-3 border-b border-line pb-2 text-base font-semibold text-ink">{t("personalInfo")}</h2>
      <form onSubmit={submit} className="space-y-4">
        <FormError message={error} />
        <div className="flex items-center gap-5">
          <Avatar user={{ name: name || "?", avatarColor }} size="xl" />
          <div>
            <div className="mb-1.5 text-xs font-semibold text-ink-subtle">{t("avatarColor")}</div>
            <div className="flex max-w-[300px] flex-wrap gap-1.5">
              {AVATAR_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  style={{ backgroundColor: c }}
                  className={cn("h-7 w-7 rounded-full ring-offset-2 ring-offset-surface", avatarColor === c && "ring-2 ring-brand-500")}
                  aria-label={c}
                />
              ))}
            </div>
          </div>
        </div>
        <Field label={t("fullName")} htmlFor="pf-name" required>
          <Input id="pf-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("jobTitle")} htmlFor="pf-title">
            <Input id="pf-title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={80} />
          </Field>
          <Field label={t("department")} htmlFor="pf-dep">
            <Input id="pf-dep" value={department} onChange={(e) => setDepartment(e.target.value)} maxLength={80} />
          </Field>
        </div>
        <div className="flex items-center gap-3">
          <Button type="submit" variant="primary" loading={pending} disabled={!dirty}>
            {tc("save")}
          </Button>
          <Saved show={saved && !dirty} text={t("saved")} />
        </div>
      </form>
    </section>
  );
}

export function PasswordForm() {
  const t = useT("profile");
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [repeat, setRepeat] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [pending, start] = useTransition();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaved(false);
    if (next !== repeat) return setError(t("passwordMismatch"));
    start(async () => {
      const res = await changePassword({ current, next });
      if (!res.ok) return setError(res.error);
      setCurrent("");
      setNext("");
      setRepeat("");
      setSaved(true);
    });
  };

  return (
    <section>
      <h2 className="mb-3 border-b border-line pb-2 text-base font-semibold text-ink">{t("changePassword")}</h2>
      <form onSubmit={submit} className="max-w-sm space-y-4">
        <FormError message={error} />
        <Field label={t("currentPassword")} htmlFor="pw-cur" required>
          <Input id="pw-cur" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} />
        </Field>
        <Field label={t("newPassword")} htmlFor="pw-new" required hint={t("passwordHint")}>
          <Input id="pw-new" type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} />
        </Field>
        <Field label={t("repeatPassword")} htmlFor="pw-rep" required>
          <Input id="pw-rep" type="password" autoComplete="new-password" value={repeat} onChange={(e) => setRepeat(e.target.value)} />
        </Field>
        <div className="flex items-center gap-3">
          <Button type="submit" variant="primary" loading={pending} disabled={!current || !next || !repeat}>
            {t("changePassword")}
          </Button>
          <Saved show={saved} text={t("passwordChanged")} />
        </div>
      </form>
    </section>
  );
}
