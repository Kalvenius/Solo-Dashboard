"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  addDays,
  addMonths,
  addQuarters,
  addWeeks,
  differenceInCalendarDays,
  endOfMonth,
  endOfQuarter,
  max as maxDate,
  min as minDate,
  startOfDay,
  startOfMonth,
  startOfQuarter,
  startOfWeek,
} from "date-fns";
import { ChevronDown, ChevronRight } from "lucide-react";
import { useOpenIssue } from "@/components/issue/use-open-issue";
import { IssueTypeIcon } from "@/components/issue/icons";
import { Avatar } from "@/components/ui/avatar";
import { StatusLozenge } from "@/components/ui/lozenge";
import { cn } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import { CHART } from "@/components/charts/theme";

type Child = {
  id: string;
  key: string;
  title: string;
  type: string;
  status: string;
  startDate: string | null;
  dueDate: string | null;
  createdAt: string;
  assignee: { id: string; name: string; avatarColor: string } | null;
};
export type TimelineEpicData = {
  id: string;
  key: string;
  title: string;
  status: string;
  startDate: string | null;
  dueDate: string | null;
  createdAt: string;
  assignee: { id: string; name: string; avatarColor: string } | null;
  progress: number;
  doneCount: number;
  children: Child[];
};

type Zoom = "weeks" | "months" | "quarters";
const PX: Record<Zoom, number> = { weeks: 16, months: 4, quarters: 1.6 };
const LEFT = 340;
const TODAY_COLOR = CHART.today;

const d = (s: string | null) => (s ? startOfDay(new Date(s)) : null);

export function TimelineView({ epics, color }: { epics: TimelineEpicData[]; color: string }) {
  const { open } = useOpenIssue();
  const t = useT("timeline");
  const f = useFormat();
  const fmtDate = f.date;
  const [zoom, setZoom] = useState<Zoom>("months");
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set());
  const scroller = useRef<HTMLDivElement>(null);
  const today = useMemo(() => startOfDay(new Date()), []);
  const px = PX[zoom];

  // Görünən aralıq: bütün tarixlər + bu gündən 1 ay əvvəl / 2 ay sonra
  const { start, end } = useMemo(() => {
    const dates: Date[] = [addDays(today, -30), addDays(today, 60)];
    for (const e of epics) {
      for (const x of [e.startDate, e.dueDate]) if (x) dates.push(d(x)!);
      for (const c of e.children) for (const x of [c.startDate, c.dueDate]) if (x) dates.push(d(x)!);
    }
    const lo = minDate(dates);
    const hi = maxDate(dates);
    return zoom === "quarters" ? { start: startOfQuarter(lo), end: endOfQuarter(hi) } : { start: startOfMonth(lo), end: endOfMonth(hi) };
  }, [epics, today, zoom]);

  const totalDays = differenceInCalendarDays(end, start) + 1;
  const width = totalDays * px;
  const x = (date: Date) => differenceInCalendarDays(date, start) * px;

  // Başlıq: yuxarı sətir (böyük vahid) və aşağı sətir (kiçik vahid)
  const { top, bottom } = useMemo(() => {
    const top: { x: number; w: number; label: string }[] = [];
    const bottom: { x: number; w: number; label: string }[] = [];
    if (zoom === "weeks") {
      for (let m = startOfMonth(start); m <= end; m = addMonths(m, 1)) {
        const s = maxDate([m, start]);
        const e = minDate([endOfMonth(m), end]);
        top.push({ x: x(s), w: (differenceInCalendarDays(e, s) + 1) * px, label: f.pattern(m, "LLLL yyyy") });
      }
      for (let w = startOfWeek(start, { weekStartsOn: 1 }); w <= end; w = addWeeks(w, 1)) {
        bottom.push({ x: x(w), w: 7 * px, label: f.dateShort(w) });
      }
    } else if (zoom === "months") {
      for (let y = start.getFullYear(); y <= end.getFullYear(); y++) {
        const s = maxDate([new Date(y, 0, 1), start]);
        const e = minDate([new Date(y, 11, 31), end]);
        top.push({ x: x(s), w: (differenceInCalendarDays(e, s) + 1) * px, label: String(y) });
      }
      for (let m = startOfMonth(start); m <= end; m = addMonths(m, 1)) {
        bottom.push({ x: x(m), w: (differenceInCalendarDays(endOfMonth(m), m) + 1) * px, label: f.pattern(m, "LLL") });
      }
    } else {
      for (let y = start.getFullYear(); y <= end.getFullYear(); y++) {
        const s = maxDate([new Date(y, 0, 1), start]);
        const e = minDate([new Date(y, 11, 31), end]);
        top.push({ x: x(s), w: (differenceInCalendarDays(e, s) + 1) * px, label: String(y) });
      }
      for (let q = startOfQuarter(start); q <= end; q = addQuarters(q, 1)) {
        bottom.push({ x: x(q), w: (differenceInCalendarDays(endOfQuarter(q), q) + 1) * px, label: t("quarter", { n: Math.floor(q.getMonth() / 3) + 1 }) });
      }
    }
    return { top, bottom };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [start, end, zoom, px, f, t]);

  const todayX = x(today);
  useEffect(() => {
    if (scroller.current) scroller.current.scrollLeft = Math.max(0, todayX - 240);
  }, [todayX, zoom]);

  const toggle = (id: string) =>
    setExpanded((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  const allOpen = epics.length > 0 && epics.every((e) => expanded.has(e.id));

  const span = (startS: string | null, dueS: string | null, created: string) => {
    const due = d(dueS);
    if (!due) return null;
    let s = d(startS) ?? d(created)!;
    if (s > due) s = due;
    return { s, e: due, left: x(s), w: Math.max(px * 2, (differenceInCalendarDays(due, s) + 1) * px) };
  };

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="flex rounded-[3px] border border-line bg-surface-raised p-0.5" role="radiogroup" aria-label={t("zoom")}>
          {(Object.keys(PX) as Zoom[]).map((z) => (
            <button
              key={z}
              role="radio"
              aria-checked={zoom === z}
              onClick={() => setZoom(z)}
              className={cn("h-7 rounded-[2px] px-2.5 text-[13px] font-medium", zoom === z ? "bg-brand-50 text-brand-700" : "text-ink-muted hover:bg-surface-hover")}
            >
              {t(z)}
            </button>
          ))}
        </div>
        <button
          onClick={() => setExpanded(allOpen ? new Set() : new Set(epics.map((e) => e.id)))}
          className="h-8 rounded-[3px] px-2.5 text-[13px] font-medium text-ink-muted hover:bg-surface-hover"
        >
          {allOpen ? t("collapseAll") : t("expandAll")}
        </button>
        <button
          onClick={() => scroller.current && (scroller.current.scrollLeft = Math.max(0, todayX - 240))}
          className="h-8 rounded-[3px] px-2.5 text-[13px] font-medium text-ink-muted hover:bg-surface-hover"
        >
          {t("goToday")}
        </button>
        <span className="ml-auto flex items-center gap-3 text-xs text-ink-subtle">
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-5 rounded-[2px]" style={{ backgroundColor: color, opacity: 0.3 }} />
            {t("plan")}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-5 rounded-[2px]" style={{ backgroundColor: color }} />
            {t("doneShare")}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-3 w-[2px]" style={{ backgroundColor: TODAY_COLOR }} />
            {t("today")}
          </span>
        </span>
      </div>

      <div ref={scroller} className="overflow-x-auto rounded-[3px] border border-line bg-surface-raised">
        <div style={{ width: LEFT + width }} className="relative min-w-full">
          {/* Başlıq */}
          <div className="sticky top-0 z-20 flex border-b border-line bg-surface-raised">
            <div style={{ width: LEFT }} className="sticky left-0 z-30 flex shrink-0 items-end border-r border-line bg-surface-raised px-3 pb-1.5 text-xs font-semibold text-ink-subtle">
              {t("epicCount", { n: epics.length })}
            </div>
            <div className="relative flex-1" style={{ minWidth: width, height: 44 }}>
              {top.map((t, i) => (
                <div key={i} className="absolute top-0 h-5 truncate border-l border-line px-1.5 text-[11px] font-semibold capitalize leading-5 text-ink" style={{ left: t.x, width: t.w }}>
                  {t.label}
                </div>
              ))}
              {bottom.map((b, i) => (
                <div key={i} className="absolute top-5 h-6 truncate border-l border-t border-line px-1 text-[11px] capitalize leading-6 text-ink-subtle" style={{ left: b.x, width: b.w }}>
                  {b.label}
                </div>
              ))}
              {/* bu gün işarəsi: başlığın alt kənarında kiçik üçbucaq (etiketləri örtmür) */}
              <span
                title={t("todayTitle", { date: fmtDate(today) })}
                className="absolute bottom-0 z-10 h-0 w-0 -translate-x-1/2 border-x-[5px] border-b-[6px] border-x-transparent"
                style={{ left: todayX + px / 2, borderBottomColor: TODAY_COLOR }}
              />
            </div>
          </div>

          {/* Şəbəkə xətləri + bu gün xətti */}
          <div className="pointer-events-none absolute bottom-0 top-[45px] z-0" style={{ left: LEFT, width }}>
            {bottom.map((b, i) => (
              <div key={i} className="absolute bottom-0 top-0 border-l border-surface-hover" style={{ left: b.x }} />
            ))}
            <div className="absolute bottom-0 top-0 w-[2px]" style={{ left: todayX + px / 2 - 1, backgroundColor: TODAY_COLOR }} />
          </div>

          {epics.map((e) => {
            const sp = span(e.startDate, e.dueDate, e.createdAt);
            const isOpen = expanded.has(e.id);
            return (
              <div key={e.id}>
                <div className="relative z-[1] flex h-10 border-b border-line hover:bg-surface-sunken/70">
                  <div style={{ width: LEFT }} className="sticky left-0 z-10 flex shrink-0 items-center gap-1.5 border-r border-line bg-surface-raised px-2">
                    <button
                      onClick={() => toggle(e.id)}
                      disabled={!e.children.length}
                      className="rounded p-0.5 text-ink-subtle hover:bg-surface-hover disabled:invisible"
                      aria-label={isOpen ? t("collapse") : t("expand")}
                      aria-expanded={isOpen}
                    >
                      {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                    </button>
                    <IssueTypeIcon type="EPIC" />
                    <button onClick={() => open(e.key)} className="min-w-0 flex-1 truncate text-left text-[13px] text-ink hover:text-brand-600 hover:underline" title={e.title}>
                      <span className="mr-1.5 text-ink-subtle">{e.key}</span>
                      {e.title}
                    </button>
                    <span className="shrink-0 text-xs tabular-nums text-ink-subtle" title={t("childrenDone", { done: e.doneCount, total: e.children.length })}>
                      {e.progress}%
                    </span>
                  </div>
                  <div className="relative flex-1" style={{ minWidth: width }}>
                    {sp ? (
                      <button
                        onClick={() => open(e.key)}
                        title={t("barTitle", { key: e.key, from: fmtDate(sp.s), to: fmtDate(sp.e), p: e.progress })}
                        className="absolute top-2.5 h-5 overflow-hidden rounded-[4px] hover:ring-2 hover:ring-brand-200"
                        style={{ left: sp.left, width: sp.w, backgroundColor: `${color}4D` }}
                      >
                        <span className="absolute inset-y-0 left-0" style={{ width: `${e.progress}%`, backgroundColor: color }} />
                      </button>
                    ) : (
                      <span className="sticky left-[calc(340px+12px)] top-0 inline-block pl-3 text-xs italic leading-10 text-ink-faint">{t("noDates")}</span>
                    )}
                  </div>
                </div>

                {isOpen &&
                  e.children.map((c) => {
                    const cs = c.startDate ? span(c.startDate, c.dueDate, c.createdAt) : null;
                    const due = d(c.dueDate);
                    const done = c.status === "DONE";
                    return (
                      <div key={c.id} className="relative z-[1] flex h-8 border-b border-line bg-surface-sunken/40 hover:bg-surface-sunken">
                        <div style={{ width: LEFT }} className="sticky left-0 z-10 flex shrink-0 items-center gap-1.5 border-r border-line bg-input pl-9 pr-2">
                          <IssueTypeIcon type={c.type} />
                          <button onClick={() => open(c.key)} className="min-w-0 flex-1 truncate text-left text-[13px] text-ink hover:text-brand-600 hover:underline" title={c.title}>
                            <span className={cn("mr-1.5 text-ink-subtle", done && "line-through")}>{c.key}</span>
                            {c.title}
                          </button>
                          <StatusLozenge status={c.status} className="shrink-0" />
                          {c.assignee && <Avatar user={c.assignee} size="xs" />}
                        </div>
                        <div className="relative flex-1" style={{ minWidth: width }}>
                          {cs ? (
                            <button
                              onClick={() => open(c.key)}
                              title={`${c.key} · ${fmtDate(cs.s)} – ${fmtDate(cs.e)}`}
                              className="absolute top-2.5 h-3 rounded-[4px] hover:ring-2 hover:ring-brand-200"
                              style={{ left: cs.left, width: cs.w, backgroundColor: done ? color : `${color}66` }}
                            />
                          ) : due ? (
                            <button
                              onClick={() => open(c.key)}
                              title={t("childDue", { key: c.key, date: fmtDate(due) })}
                              className="absolute top-3 h-2.5 w-2.5 -translate-x-1/2 rounded-full ring-2 ring-surface-raised hover:ring-brand-200"
                              style={{ left: x(due) + px / 2, backgroundColor: done ? color : `${color}99` }}
                            />
                          ) : null}
                        </div>
                      </div>
                    );
                  })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
