"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Trash2, UserPlus } from "lucide-react";
import { addProjectMember, removeProjectMember, updateProjectMemberRole } from "@/lib/actions/projects";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { FormError, Select } from "@/components/ui/input";
import { Lozenge } from "@/components/ui/lozenge";
import { Modal } from "@/components/ui/modal";
import { Picker } from "@/components/ui/picker";
import { useT } from "@/i18n/client";
import { NAME_MARK, WithName } from "./rich";

type Member = { id: string; name: string; email: string; avatarColor: string; title: string | null; active: boolean; role: string };
type U = { id: string; name: string; email: string; avatarColor: string };

export function ProjectMembers({
  projectId,
  members,
  allUsers,
  canManage,
  meId,
  leadId,
}: {
  projectId: string;
  members: Member[];
  allUsers: U[];
  canManage: boolean;
  meId: string;
  leadId: string | null;
}) {
  const router = useRouter();
  const t = useT("projects");
  const tc = useT("common");
  const te = useT("enums");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const [removing, setRemoving] = useState<Member | null>(null);
  const memberIds = new Set(members.map((m) => m.id));
  const candidates = allUsers.filter((u) => !memberIds.has(u.id));
  const adminCount = members.filter((m) => m.role === "ADMIN").length;

  const run = (fn: () => Promise<{ ok: boolean; error?: string }>, after?: () => void) => {
    setError(null);
    start(async () => {
      const res = await fn();
      if (!res.ok) return setError(res.error ?? tc("unknownError"));
      after?.();
      router.refresh();
    });
  };

  return (
    <section>
      <div className="mb-3 flex items-center justify-between border-b border-line pb-2">
        <h2 className="text-base font-semibold text-ink">
          {t("members")} <span className="ml-1 text-sm font-normal text-ink-subtle">{members.length}</span>
        </h2>
        {canManage && (
          <Picker
            searchable
            align="right"
            value={null}
            onChange={(id) => id && run(() => addProjectMember(projectId, id, "MEMBER"))}
            options={candidates.map((u) => ({ value: u.id, label: u.name, hint: u.email, icon: <Avatar user={u} size="xs" /> }))}
            renderTrigger={() => (
              <span className="inline-flex h-8 items-center gap-1.5 rounded-[3px] bg-brand-600 px-3 text-sm font-medium text-on-brand hover:bg-brand-700">
                <UserPlus className="h-4 w-4" /> {t("addMember")}
              </span>
            )}
          />
        )}
      </div>
      <FormError message={error} />
      <div className="mt-2 overflow-hidden rounded-[3px] border border-line bg-surface-raised">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line bg-surface-sunken text-left text-xs font-semibold text-ink-subtle">
              <th className="px-3 py-2">{t("colMemberName")}</th>
              <th className="px-3 py-2">{t("colEmail")}</th>
              <th className="w-40 px-3 py-2">{t("colRole")}</th>
              {canManage && <th className="w-12 px-3 py-2" />}
            </tr>
          </thead>
          <tbody>
            {members.map((m) => {
              const lastAdmin = m.role === "ADMIN" && adminCount <= 1;
              return (
                <tr key={m.id} className="border-b border-line last:border-b-0">
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-2.5">
                      <Avatar user={m} size="md" />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 font-medium text-ink">
                          {m.name}
                          {m.id === meId && <span className="text-xs font-normal text-ink-subtle">{t("you")}</span>}
                          {m.id === leadId && <Lozenge tone="purple">{t("leadBadge")}</Lozenge>}
                          {!m.active && <Lozenge tone="danger">{t("deactivatedBadge")}</Lozenge>}
                        </div>
                        {m.title && <div className="text-xs text-ink-subtle">{m.title}</div>}
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-2 text-ink-muted">{m.email}</td>
                  <td className="px-3 py-2">
                    {canManage ? (
                      <Select
                        value={m.role}
                        disabled={pending || lastAdmin}
                        title={lastAdmin ? t("lastAdminHint") : undefined}
                        onChange={(e) => run(() => updateProjectMemberRole(projectId, m.id, e.target.value))}
                        className="h-8"
                      >
                        <option value="ADMIN">{te("role.ADMIN")}</option>
                        <option value="MEMBER">{te("role.MEMBER")}</option>
                      </Select>
                    ) : (
                      <Lozenge tone={m.role === "ADMIN" ? "progress" : "todo"}>{te(m.role === "ADMIN" ? "role.ADMIN" : "role.MEMBER")}</Lozenge>
                    )}
                  </td>
                  {canManage && (
                    <td className="px-3 py-2 text-right">
                      <button
                        disabled={pending || lastAdmin}
                        onClick={() => setRemoving(m)}
                        className="rounded p-1.5 text-ink-subtle hover:bg-danger-subtle hover:text-danger disabled:opacity-30 disabled:hover:bg-transparent"
                        title={lastAdmin ? t("lastAdminRemoveHint") : t("removeFromProject")}
                        aria-label={t("removeFromProject")}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Modal
        open={!!removing}
        onClose={() => setRemoving(null)}
        title={t("removeTitle")}
        width="sm"
        footer={
          <>
            <Button variant="subtle" onClick={() => setRemoving(null)}>
              {tc("cancel")}
            </Button>
            <Button variant="danger" loading={pending} onClick={() => removing && run(() => removeProjectMember(projectId, removing.id), () => setRemoving(null))}>
              {t("removeAction")}
            </Button>
          </>
        }
      >
        <p className="text-sm text-ink-muted">
          <WithName text={t("removeConfirm", { name: NAME_MARK })} name={removing?.name} />
        </p>
      </Modal>
    </section>
  );
}
