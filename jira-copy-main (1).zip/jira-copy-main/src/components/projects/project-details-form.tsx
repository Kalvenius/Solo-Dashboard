"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { updateProject } from "@/lib/actions/projects";
import { PROJECT_COLORS } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input, Select, Textarea } from "@/components/ui/input";
import { ProjectAvatar } from "@/components/ui/misc";
import { Picker } from "@/components/ui/picker";
import { useT } from "@/i18n/client";

type P = { id: string; key: string; name: string; description: string | null; type: string; color: string; leadId: string | null };
type M = { id: string; name: string; avatarColor: string };

export function ProjectDetailsForm({ project, members, canManage }: { project: P; members: M[]; canManage: boolean }) {
  const router = useRouter();
  const t = useT("projects");
  const tc = useT("common");
  const te = useT("enums");
  const [name, setName] = useState(project.name);
  const [description, setDescription] = useState(project.description ?? "");
  const [type, setType] = useState(project.type);
  const [color, setColor] = useState(project.color);
  const [leadId, setLeadId] = useState<string | null>(project.leadId);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [pending, start] = useTransition();

  const dirty =
    name !== project.name || description !== (project.description ?? "") || type !== project.type || color !== project.color || leadId !== project.leadId;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaved(false);
    start(async () => {
      const res = await updateProject(project.id, { name, description, type: type as "SCRUM" | "KANBAN", color, leadId });
      if (!res.ok) return setError(res.error);
      setSaved(true);
      router.refresh();
    });
  };

  return (
    <section>
      <h2 className="mb-3 border-b border-line pb-2 text-base font-semibold text-ink">{t("details")}</h2>
      <form onSubmit={submit} className="space-y-4">
        <FormError message={error} />
        <div className="flex items-center gap-4">
          <ProjectAvatar project={{ name, key: project.key, color }} size="lg" />
          <div className="flex gap-1.5">
            {PROJECT_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                disabled={!canManage}
                onClick={() => setColor(c)}
                style={{ backgroundColor: c }}
                className={cn("h-6 w-6 rounded-[3px] ring-offset-2 ring-offset-surface disabled:cursor-default", color === c && "ring-2 ring-brand-500")}
                aria-label={c}
              />
            ))}
          </div>
        </div>
        <div className="grid grid-cols-[1fr_160px] gap-3">
          <Field label={t("name")} htmlFor="s-name" required>
            <Input id="s-name" value={name} onChange={(e) => setName(e.target.value)} disabled={!canManage} maxLength={80} />
          </Field>
          <Field label={t("key")} htmlFor="s-key" hint={t("keyHint")}>
            <Input id="s-key" value={project.key} disabled readOnly />
          </Field>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label={tc("type")} htmlFor="s-type" hint={type === "KANBAN" && project.type === "SCRUM" ? t("kanbanHint") : undefined}>
            <Select id="s-type" value={type} onChange={(e) => setType(e.target.value)} disabled={!canManage}>
              <option value="SCRUM">{te("projectType.SCRUM")}</option>
              <option value="KANBAN">{te("projectType.KANBAN")}</option>
            </Select>
          </Field>
          <Field label={t("lead")}>
            <Picker
              searchable
              disabled={!canManage}
              value={leadId}
              onChange={setLeadId}
              emptyLabel={t("noLead")}
              options={members.map((u) => ({ value: u.id, label: u.name, icon: <Avatar user={u} size="xs" /> }))}
              renderTrigger={(sel) => (
                <span
                  className={cn(
                    "flex h-9 w-full min-w-[260px] items-center gap-2 rounded-[3px] border-2 border-neutral bg-input px-2 text-sm",
                    canManage && "hover:bg-input-hover",
                  )}
                >
                  {sel ? (
                    <>
                      {sel.icon} {sel.label}
                    </>
                  ) : (
                    <span className="text-ink-faint">{t("noLead")}</span>
                  )}
                </span>
              )}
            />
          </Field>
        </div>
        <Field label={t("description")} htmlFor="s-desc">
          <Textarea id="s-desc" value={description} onChange={(e) => setDescription(e.target.value)} disabled={!canManage} rows={4} />
        </Field>
        {canManage && (
          <div className="flex items-center gap-3">
            <Button type="submit" variant="primary" loading={pending} disabled={!dirty}>
              {tc("save")}
            </Button>
            {saved && !dirty && <span className="text-sm text-success">{t("saved")}</span>}
          </div>
        )}
      </form>
    </section>
  );
}
