/** Tərcümədəki {name} yerinə qalın ad qoymaq üçün işarə: t("removeConfirm", { name: NAME_MARK }) */
export const NAME_MARK = "\u0001";

/** Dillərdə söz sırası fərqli olduğu üçün adın yeri tərcümədən götürülür */
export function WithName({ text, name }: { text: string; name: string | null | undefined }) {
  const [before, after] = text.split(NAME_MARK);
  return (
    <>
      {before}
      <b className="font-semibold text-ink">{name}</b>
      {after}
    </>
  );
}
