"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Check, KanbanSquare, Repeat } from "lucide-react";
import { createProject } from "@/lib/actions/projects";
import { PROJECT_COLORS } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input, Textarea } from "@/components/ui/input";
import { ProjectAvatar } from "@/components/ui/misc";
import { Modal } from "@/components/ui/modal";
import { Picker } from "@/components/ui/picker";
import { suggestKey } from "./project-key";
import { useT } from "@/i18n/client";

type U = { id: string; name: string; avatarColor: string };

export function CreateProjectModal({ open, onClose, users, me, existingKeys }: { open: boolean; onClose: () => void; users: U[]; me: string; existingKeys: string[] }) {
  const router = useRouter();
  const t = useT("projects");
  const tc = useT("common");
  const te = useT("enums");
  const [name, setName] = useState("");
  const [key, setKey] = useState("");
  const [keyTouched, setKeyTouched] = useState(false);
  const [type, setType] = useState<"SCRUM" | "KANBAN">("SCRUM");
  const [color, setColor] = useState(PROJECT_COLORS[0]!);
  const [description, setDescription] = useState("");
  const [leadId, setLeadId] = useState<string | null>(me);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const reset = () => {
    setName("");
    setKey("");
    setKeyTouched(false);
    setType("SCRUM");
    setColor(PROJECT_COLORS[0]!);
    setDescription("");
    setLeadId(me);
    setError(null);
  };
  const close = () => {
    reset();
    onClose();
  };

  const keyTaken = existingKeys.includes(key);
  const keyValid = /^[A-Z][A-Z0-9]{1,9}$/.test(key);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    start(async () => {
      const res = await createProject({ name, key, type, color, description, leadId });
      if (!res.ok) return setError(res.error);
      const k = res.data!.key;
      reset();
      onClose();
      router.push(`/projects/${k}/board`);
    });
  };

  const types = [
    { id: "SCRUM" as const, label: te("projectType.SCRUM"), icon: Repeat, text: t("scrumDesc") },
    { id: "KANBAN" as const, label: te("projectType.KANBAN"), icon: KanbanSquare, text: t("kanbanDesc") },
  ];

  return (
    <Modal
      open={open}
      onClose={close}
      title={t("createProject")}
      width="md"
      footer={
        <>
          <Button variant="subtle" onClick={close}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" type="submit" form="create-project" loading={pending} disabled={!name.trim() || !keyValid || keyTaken}>
            {tc("create")}
          </Button>
        </>
      }
    >
      <form id="create-project" onSubmit={submit} className="space-y-4">
        <FormError message={error} />
        <div className="grid grid-cols-[1fr_140px] gap-3">
          <Field label={t("name")} htmlFor="p-name" required>
            <Input
              id="p-name"
              autoFocus
              value={name}
              maxLength={80}
              onChange={(e) => {
                setName(e.target.value);
                if (!keyTouched) setKey(suggestKey(e.target.value));
              }}
              placeholder={t("namePlaceholder")}
            />
          </Field>
          <Field label={t("key")} htmlFor="p-key" required>
            <Input
              id="p-key"
              value={key}
              maxLength={10}
              onChange={(e) => {
                setKeyTouched(true);
                setKey(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""));
              }}
              className={cn(key && (!keyValid || keyTaken) && "border-danger-bold focus:border-danger-bold")}
            />
          </Field>
        </div>
        <p className="-mt-2 text-xs text-ink-subtle">
          {keyTaken ? (
            <span className="text-danger">{t("keyTaken", { key })}</span>
          ) : (
            <>
              {t("keyPreview")} <span className="font-semibold text-ink-muted">{key || "KEY"}-1</span>, {key || "KEY"}-2 …
            </>
          )}
        </p>

        <div>
          <div className="mb-1 text-xs font-semibold text-ink-subtle">{t("template")}</div>
          <div className="grid grid-cols-2 gap-3">
            {types.map((tp) => (
              <button
                key={tp.id}
                type="button"
                onClick={() => setType(tp.id)}
                className={cn(
                  "relative rounded-[3px] border-2 p-3 text-left transition-colors",
                  type === tp.id ? "border-brand-500 bg-brand-50" : "border-line hover:bg-surface-hover",
                )}
              >
                <div className="mb-1 flex items-center gap-2 font-semibold text-ink">
                  <tp.icon className="h-4 w-4 text-brand-600" /> {tp.label}
                </div>
                <p className="text-xs leading-relaxed text-ink-subtle">{tp.text}</p>
                {type === tp.id && <Check className="absolute right-2 top-2 h-4 w-4 text-brand-600" />}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-end gap-4">
          <div>
            <div className="mb-1 text-xs font-semibold text-ink-subtle">{t("color")}</div>
            <div className="flex gap-1.5">
              {PROJECT_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  style={{ backgroundColor: c }}
                  className={cn("h-7 w-7 rounded-[3px] ring-offset-2 ring-offset-surface-overlay", color === c && "ring-2 ring-brand-500")}
                  aria-label={c}
                />
              ))}
            </div>
          </div>
          <ProjectAvatar project={{ name: name || t("defaultName"), key: key || "PR", color }} size="lg" />
        </div>

        <Field label={t("lead")}>
          <Picker
            searchable
            value={leadId}
            onChange={setLeadId}
            options={users.map((u) => ({ value: u.id, label: u.name, icon: <Avatar user={u} size="xs" /> }))}
            renderTrigger={(sel) => (
              <span className="flex h-9 w-72 items-center gap-2 rounded-[3px] border-2 border-neutral bg-input px-2 text-sm hover:bg-input-hover">
                {sel ? (
                  <>
                    {sel.icon} {sel.label}
                  </>
                ) : (
                  <span className="text-ink-faint">{t("chooseLead")}</span>
                )}
              </span>
            )}
          />
        </Field>

        <Field label={t("description")} htmlFor="p-desc">
          <Textarea id="p-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder={t("descriptionPlaceholder")} />
        </Field>
      </form>
    </Modal>
  );
}
