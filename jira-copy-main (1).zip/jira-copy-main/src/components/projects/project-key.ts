// Azərbaycan və kiril hərflərini latın ASCII-yə çevirir (layihə açarı təklifi üçün)
const MAP: Record<string, string> = {
  Ə: "E", ə: "E", Ü: "U", ü: "U", Ö: "O", ö: "O", Ğ: "G", ğ: "G", ı: "I", İ: "I", Ş: "S", ş: "S", Ç: "C", ç: "C",
  а: "A", б: "B", в: "V", г: "G", д: "D", е: "E", ё: "E", ж: "ZH", з: "Z", и: "I", й: "Y", к: "K", л: "L", м: "M",
  н: "N", о: "O", п: "P", р: "R", с: "S", т: "T", у: "U", ф: "F", х: "KH", ц: "TS", ч: "CH", ш: "SH", щ: "SCH",
  ъ: "", ы: "Y", ь: "", э: "E", ю: "YU", я: "YA",
};

export function translit(s: string) {
  return s
    .replace(/[ƏəÜüÖöĞğıİŞşÇç]/g, (c) => MAP[c] ?? c)
    .replace(/[А-ЯЁа-яё]/g, (c) => MAP[c.toLowerCase()] ?? c)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "");
}

/** "Veb Platforma" → "VP", "Marketinq" → "MARK", "Мобильное приложение" → "MP" (2–6 simvol) */
export function suggestKey(name: string) {
  const words = translit(name)
    .toUpperCase()
    .split(/[^A-Z0-9]+/)
    .filter(Boolean);
  if (!words.length) return "";
  let key = words.length >= 2 ? words.map((w) => w[0]).join("") : words[0]!.slice(0, 4);
  if (key.length < 2) key = (words[0]! + (words[1] ?? "")).slice(0, 3);
  key = key.replace(/^[0-9]+/, "");
  return key.slice(0, 6);
}
