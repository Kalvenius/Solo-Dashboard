"use client";

import Link from "next/link";
import { useState } from "react";
import { FolderKanban, Search } from "lucide-react";
import { Avatar, AvatarStack } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader, ProjectAvatar } from "@/components/ui/misc";
import { CreateProjectModal } from "./create-project-modal";
import { useT } from "@/i18n/client";

export type ProjectRow = {
  id: string;
  key: string;
  name: string;
  type: string;
  color: string;
  description: string | null;
  lead: { id: string; name: string; avatarColor: string } | null;
  members: { id: string; name: string; avatarColor: string }[];
  total: number;
  open: number;
};

export function ProjectsTable({
  projects,
  canCreate,
  users,
  me,
}: {
  projects: ProjectRow[];
  canCreate: boolean;
  users: { id: string; name: string; avatarColor: string }[];
  me: string;
}) {
  const t = useT("projects");
  const tc = useT("common");
  const te = useT("enums");
  const [q, setQ] = useState("");
  const [creating, setCreating] = useState(false);
  const term = q.trim().toLowerCase();
  const list = term ? projects.filter((p) => p.name.toLowerCase().includes(term) || p.key.toLowerCase().includes(term)) : projects;

  return (
    <>
      <PageHeader
        title={t("title")}
        actions={
          canCreate && (
            <Button variant="primary" onClick={() => setCreating(true)}>
              {t("createProject")}
            </Button>
          )
        }
      />

      {projects.length === 0 ? (
        <div className="rounded-[3px] border border-line">
          <EmptyState
            icon={<FolderKanban className="h-12 w-12" />}
            title={t("emptyTitle")}
            description={canCreate ? t("emptyAdmin") : t("emptyMember")}
            action={
              canCreate && (
                <Button variant="primary" onClick={() => setCreating(true)}>
                  {t("createProject")}
                </Button>
              )
            }
          />
        </div>
      ) : (
        <>
          <div className="relative mb-4 w-64">
            <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-subtle" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("searchPlaceholder")}
              className="h-8 w-full rounded-[3px] border-2 border-line bg-input pl-8 pr-2 text-sm text-ink placeholder:text-ink-faint focus:border-brand-500 focus:bg-surface-raised focus:outline-none"
            />
          </div>
          <div className="overflow-x-auto rounded-[3px] border border-line bg-surface-raised">
            <table className="w-full min-w-[800px] text-sm">
              <thead>
                <tr className="border-b-2 border-line text-left text-xs font-semibold text-ink-subtle">
                  <th className="px-3 py-2">{t("colName")}</th>
                  <th className="w-24 px-3 py-2">{t("colKey")}</th>
                  <th className="w-28 px-3 py-2">{t("colType")}</th>
                  <th className="w-52 px-3 py-2">{t("colLead")}</th>
                  <th className="w-36 px-3 py-2">{t("colMembers")}</th>
                  <th className="w-36 px-3 py-2 text-right">{t("colOpenTotal")}</th>
                  <th className="w-36 px-3 py-2" />
                </tr>
              </thead>
              <tbody>
                {list.map((p) => (
                  <tr key={p.id} className="border-b border-line last:border-b-0 hover:bg-surface-hover">
                    <td className="px-3 py-2">
                      <Link href={`/projects/${p.key}/board`} className="flex items-center gap-2.5">
                        <ProjectAvatar project={p} size="md" />
                        <div className="min-w-0">
                          <div className="truncate font-medium text-brand-600 hover:underline">{p.name}</div>
                          {p.description && <div className="max-w-md truncate text-xs text-ink-subtle">{p.description}</div>}
                        </div>
                      </Link>
                    </td>
                    <td className="px-3 py-2 font-medium text-ink-muted">{p.key}</td>
                    <td className="px-3 py-2 text-ink-muted">{te(p.type === "KANBAN" ? "projectType.KANBAN" : "projectType.SCRUM")}</td>
                    <td className="px-3 py-2">
                      {p.lead ? (
                        <span className="flex items-center gap-2">
                          <Avatar user={p.lead} size="sm" />
                          <span className="truncate">{p.lead.name}</span>
                        </span>
                      ) : (
                        <span className="text-ink-faint">—</span>
                      )}
                    </td>
                    <td className="px-3 py-2">
                      <AvatarStack users={p.members} max={5} />
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums text-ink-muted">
                      <span className="font-semibold text-ink">{p.open}</span> / {p.total}
                    </td>
                    <td className="px-3 py-2 text-right">
                      <div className="flex justify-end gap-1 text-xs">
                        <Link href={`/projects/${p.key}/board`} className="rounded px-1.5 py-1 text-ink-muted hover:bg-tint-1">
                          {tc("board")}
                        </Link>
                        {p.type === "SCRUM" && (
                          <Link href={`/projects/${p.key}/backlog`} className="rounded px-1.5 py-1 text-ink-muted hover:bg-tint-1">
                            {tc("backlog")}
                          </Link>
                        )}
                        <Link href={`/projects/${p.key}/settings`} className="rounded px-1.5 py-1 text-ink-muted hover:bg-tint-1">
                          {t("settingsLink")}
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
                {list.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-3 py-8 text-center text-sm text-ink-subtle">
                      {t("notFound", { q })}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}

      {canCreate && <CreateProjectModal open={creating} onClose={() => setCreating(false)} users={users} me={me} existingKeys={projects.map((p) => p.key)} />}
    </>
  );
}
