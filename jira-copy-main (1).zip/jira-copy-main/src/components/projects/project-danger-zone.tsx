"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { deleteProject } from "@/lib/actions/projects";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input } from "@/components/ui/input";
import { Modal } from "@/components/ui/modal";
import { useT } from "@/i18n/client";
import { NAME_MARK, WithName } from "./rich";

export function ProjectDangerZone({ projectId, projectKey, projectName, issueCount }: { projectId: string; projectKey: string; projectName: string; issueCount: number }) {
  const router = useRouter();
  const t = useT("projects");
  const tc = useT("common");
  const [open, setOpen] = useState(false);
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const close = () => {
    setOpen(false);
    setConfirm("");
    setError(null);
  };

  const submit = () =>
    start(async () => {
      const res = await deleteProject(projectId, confirm);
      // uğurlu olduqda server /projects-ə yönləndirir
      if (res && !res.ok) return setError(res.error);
      router.push("/projects");
    });

  return (
    <section>
      <h2 className="mb-3 border-b border-line pb-2 text-base font-semibold text-danger">{t("dangerZone")}</h2>
      <div className="flex items-center justify-between gap-4 rounded-[3px] border border-danger-border bg-danger-subtle p-4">
        <div>
          <div className="font-semibold text-ink">{t("deleteProject")}</div>
          <p className="text-sm text-ink-subtle">{t("deleteDesc", { n: issueCount })}</p>
        </div>
        <Button variant="danger" onClick={() => setOpen(true)}>
          {t("deleteProject")}
        </Button>
      </div>

      <Modal
        open={open}
        onClose={close}
        title={t("deleteConfirmTitle")}
        width="sm"
        footer={
          <>
            <Button variant="subtle" onClick={close}>
              {tc("cancel")}
            </Button>
            <Button variant="danger" onClick={submit} loading={pending} disabled={confirm.trim().toUpperCase() !== projectKey}>
              {t("deleteForever")}
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <FormError message={error} />
          <p className="text-sm text-ink-muted">
            <WithName text={t("deleteConfirmText", { name: NAME_MARK })} name={projectName} />
          </p>
          <Field label={t("typeKeyToConfirm", { key: projectKey })} htmlFor="confirm-key">
            <Input id="confirm-key" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoFocus autoComplete="off" />
          </Field>
        </div>
      </Modal>
    </section>
  );
}
