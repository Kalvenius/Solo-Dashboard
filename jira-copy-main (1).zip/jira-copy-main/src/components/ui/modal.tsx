"use client";

import { useEffect, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";

export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  width = "md",
  className,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  width?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  const t = useT("common");
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;
  const w = { sm: "max-w-[400px]", md: "max-w-[600px]", lg: "max-w-[800px]", xl: "max-w-[1100px]" }[width];

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-backdrop p-4 pt-[6vh]" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        className={cn("relative w-full rounded-[3px] bg-surface-overlay shadow-overlay", w, className)}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {title !== undefined && (
          <div className="flex items-center justify-between gap-4 px-6 pb-2 pt-5">
            <h2 className="text-xl font-medium text-ink">{title}</h2>
            <button onClick={onClose} className="rounded p-1 text-ink-subtle hover:bg-surface-hover" aria-label={t("close")}>
              <X className="h-5 w-5" />
            </button>
          </div>
        )}
        <div className={cn(title !== undefined ? "px-6 py-3" : "")}>{children}</div>
        {footer && <div className="flex justify-end gap-2 px-6 pb-5 pt-3">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}
