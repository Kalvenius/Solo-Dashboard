"use client";

import { useMemo, useState, type ReactNode } from "react";
import { Check, ChevronDown } from "lucide-react";
import { Popover } from "./popover";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";

export type PickerOption = { value: string; label: string; icon?: ReactNode; hint?: string };

/**
 * Axtarışlı seçici (icraçı, status, prioritet və s. üçün).
 * renderTrigger verilməsə standart düymə göstərilir.
 */
export function Picker({
  options,
  value,
  onChange,
  placeholder,
  searchable,
  renderTrigger,
  align,
  disabled,
  className,
  emptyLabel,
}: {
  options: PickerOption[];
  value: string | null;
  onChange: (v: string | null) => void;
  placeholder?: string;
  searchable?: boolean;
  renderTrigger?: (selected: PickerOption | undefined, open: boolean) => ReactNode;
  align?: "left" | "right";
  disabled?: boolean;
  className?: string;
  /** null dəyəri üçün seçim (məs. "Təyin edilməyib") */
  emptyLabel?: string;
}) {
  const t = useT("common");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.value === value);
  const all = useMemo(() => (emptyLabel ? [{ value: "__none__", label: emptyLabel } as PickerOption, ...options] : options), [options, emptyLabel]);
  const filtered = q ? all.filter((o) => o.label.toLowerCase().includes(q.toLowerCase())) : all;

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) setQ("");
      }}
      align={align}
      className={cn("max-h-80 w-64 overflow-y-auto", className)}
      trigger={({ toggle }) => (
        <button type="button" disabled={disabled} onClick={toggle} className="max-w-full text-left disabled:cursor-default">
          {renderTrigger ? (
            renderTrigger(selected, open)
          ) : (
            <span className="inline-flex h-8 items-center gap-2 rounded-[3px] px-2 text-sm text-ink hover:bg-surface-hover">
              {selected?.icon}
              <span className="truncate">{selected?.label ?? placeholder ?? t("select")}</span>
              <ChevronDown className="h-4 w-4 text-ink-subtle" />
            </span>
          )}
        </button>
      )}
    >
      {(close) => (
        <>
          {(searchable ?? options.length > 7) && (
            <div className="px-2 pb-1 pt-1">
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("searchPlaceholder")}
                className="h-8 w-full rounded-[3px] border-2 border-line px-2 text-sm focus:border-brand-500 focus:outline-none"
              />
            </div>
          )}
          {filtered.length === 0 && <div className="px-3 py-2 text-sm text-ink-subtle">{t("noResults")}</div>}
          {filtered.map((o) => {
            const isSel = o.value === "__none__" ? value === null : o.value === value;
            return (
              <button
                key={o.value}
                type="button"
                onClick={() => {
                  onChange(o.value === "__none__" ? null : o.value);
                  close();
                }}
                className={cn("flex w-full items-center gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-hover", isSel && "bg-brand-50")}
              >
                {o.icon}
                <span className="flex-1 truncate">
                  {o.label}
                  {o.hint && <span className="ml-1 text-xs text-ink-subtle">{o.hint}</span>}
                </span>
                {isSel && <Check className="h-4 w-4 text-brand-600" />}
              </button>
            );
          })}
        </>
      )}
    </Popover>
  );
}
