"use client";

import { STATUS_META, type Status } from "@/lib/constants";
import { useT } from "@/i18n/client";
import { cn } from "@/lib/utils";

const tones = {
  todo: "bg-neutral text-ink-muted",
  progress: "bg-info-subtle text-info",
  done: "bg-success-subtle text-success",
  danger: "bg-danger-subtle text-danger",
  purple: "bg-discovery-subtle text-discovery",
  warning: "bg-warning-subtle text-ink",
};

export type Tone = keyof typeof tones;

export function Lozenge({ tone = "todo", children, className }: { tone?: Tone; children: React.ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex max-w-full items-center truncate rounded-[3px] px-1 py-px text-[11px] font-bold uppercase leading-4", tones[tone], className)}>
      {children}
    </span>
  );
}

export function StatusLozenge({ status, className }: { status: string; className?: string }) {
  const te = useT("enums");
  const s = (status in STATUS_META ? status : "TODO") as Status;
  return (
    <Lozenge tone={STATUS_META[s].category} className={className}>
      {te(`status.${s}`)}
    </Lozenge>
  );
}
