import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "default" | "subtle" | "danger" | "link" | "warning";
type Size = "sm" | "md" | "icon";

const variants: Record<Variant, string> = {
  primary: "bg-brand-600 text-on-brand hover:bg-brand-700 active:bg-brand-800",
  default: "bg-tint-1 text-ink hover:bg-tint-2 active:bg-tint-3",
  subtle: "bg-transparent text-ink-muted hover:bg-tint-1 active:bg-tint-2",
  danger: "bg-danger-bold text-white hover:bg-danger",
  warning: "bg-[#F5CD47] text-[#172B4D] hover:bg-[#E2B203]",
  link: "bg-transparent text-brand-600 hover:underline px-0",
};
const sizes: Record<Size, string> = {
  sm: "h-7 px-2 text-[13px]",
  md: "h-8 px-3 text-sm",
  icon: "h-8 w-8 justify-center",
};

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: Size; loading?: boolean };

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = "default", size = "md", loading, className, children, disabled, type = "button", ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled || loading}
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-[3px] font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 focus-visible:ring-offset-1",
        variants[variant],
        sizes[size],
        className,
      )}
      {...rest}
    >
      {loading && <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" />}
      {children}
    </button>
  );
});
