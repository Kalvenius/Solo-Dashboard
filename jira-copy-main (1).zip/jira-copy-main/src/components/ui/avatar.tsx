"use client";

import { cn, initials } from "@/lib/utils";
import { useT } from "@/i18n/client";

const sizes = { xs: "h-5 w-5 text-[9px]", sm: "h-6 w-6 text-[10px]", md: "h-8 w-8 text-xs", lg: "h-12 w-12 text-base", xl: "h-24 w-24 text-3xl" };

export type AvatarUser = { name: string; avatarColor?: string | null } | null | undefined;

export function Avatar({ user, size = "sm", className, title }: { user: AvatarUser; size?: keyof typeof sizes; className?: string; title?: string }) {
  const t = useT("common");
  if (!user) {
    return (
      <span
        title={title ?? t("unassigned")}
        className={cn("inline-flex shrink-0 items-center justify-center rounded-full bg-neutral text-ink-subtle", sizes[size], className)}
      >
        <svg viewBox="0 0 24 24" className="h-[60%] w-[60%]" fill="currentColor" aria-hidden>
          <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 2c-4.42 0-8 2.24-8 5v1h16v-1c0-2.76-3.58-5-8-5Z" />
        </svg>
      </span>
    );
  }
  return (
    <span
      title={title ?? user.name}
      style={{ backgroundColor: user.avatarColor ?? "#0C66E4" }}
      className={cn("inline-flex shrink-0 select-none items-center justify-center rounded-full font-semibold text-white", sizes[size], className)}
    >
      {initials(user.name)}
    </span>
  );
}

export function AvatarStack({ users, max = 4, size = "sm" }: { users: { id: string; name: string; avatarColor?: string | null }[]; max?: number; size?: keyof typeof sizes }) {
  const shown = users.slice(0, max);
  const rest = users.length - shown.length;
  return (
    <div className="flex -space-x-1.5">
      {shown.map((u) => (
        <Avatar key={u.id} user={u} size={size} className="ring-2 ring-surface-raised" />
      ))}
      {rest > 0 && (
        <span className={cn("inline-flex items-center justify-center rounded-full bg-neutral font-semibold text-ink-muted ring-2 ring-surface-raised", sizes[size])}>
          +{rest}
        </span>
      )}
    </div>
  );
}
