import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PageHeader({ title, breadcrumbs, actions, children }: { title: ReactNode; breadcrumbs?: ReactNode; actions?: ReactNode; children?: ReactNode }) {
  return (
    <div className="mb-4">
      {breadcrumbs && <div className="mb-2 text-sm text-ink-subtle">{breadcrumbs}</div>}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold text-ink">{title}</h1>
        {actions && <div className="flex items-center gap-2">{actions}</div>}
      </div>
      {children}
    </div>
  );
}

export function EmptyState({ title, description, action, icon }: { title: string; description?: string; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-[3px] px-6 py-14 text-center">
      {icon && <div className="mb-3 text-ink-faint">{icon}</div>}
      <h3 className="text-base font-semibold text-ink">{title}</h3>
      {description && <p className="mt-1 max-w-md text-sm text-ink-subtle">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Card({ children, className, title, actions }: { children: ReactNode; className?: string; title?: ReactNode; actions?: ReactNode }) {
  return (
    <section className={cn("rounded-[3px] border border-line bg-surface-raised", className)}>
      {title && (
        <header className="flex items-center justify-between gap-2 border-b border-line px-4 py-3">
          <h2 className="text-sm font-semibold text-ink">{title}</h2>
          {actions}
        </header>
      )}
      <div className={title ? "p-4" : ""}>{children}</div>
    </section>
  );
}

export function StatCard({ label, value, sub, tone, icon }: { label: string; value: ReactNode; sub?: ReactNode; tone?: "default" | "good" | "bad" | "brand"; icon?: ReactNode }) {
  const color = { default: "text-ink", good: "text-success", bad: "text-danger", brand: "text-brand-600" }[tone ?? "default"];
  return (
    <div className="rounded-[3px] border border-line bg-surface-raised p-4">
      <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-ink-subtle">
        <span>{label}</span>
        {icon}
      </div>
      <div className={cn("mt-2 text-2xl font-semibold tabular-nums", color)}>{value}</div>
      {sub && <div className="mt-1 text-xs text-ink-subtle">{sub}</div>}
    </div>
  );
}

export function ProgressBar({ segments, className }: { segments: { value: number; color: string; label?: string }[]; className?: string }) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  return (
    <div className={cn("flex h-2 w-full overflow-hidden rounded-full bg-neutral", className)}>
      {total > 0 &&
        segments.map((s, i) => (
          <div key={i} title={s.label ? `${s.label}: ${s.value}` : undefined} style={{ width: `${(s.value / total) * 100}%`, backgroundColor: s.color }} />
        ))}
    </div>
  );
}

export function ProjectAvatar({ project, size = "md" }: { project: { name: string; color: string; key: string }; size?: "sm" | "md" | "lg" }) {
  const s = { sm: "h-5 w-5 text-[10px]", md: "h-8 w-8 text-xs", lg: "h-10 w-10 text-sm" }[size];
  return (
    <span style={{ backgroundColor: project.color }} className={cn("inline-flex shrink-0 items-center justify-center rounded-[3px] font-bold text-white", s)} title={project.name}>
      {project.key.slice(0, 2)}
    </span>
  );
}
