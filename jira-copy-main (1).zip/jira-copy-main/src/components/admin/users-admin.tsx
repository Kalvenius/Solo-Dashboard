"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { KeyRound, MoreHorizontal, Pencil, Search, UserCheck, UserPlus, UserX } from "lucide-react";
import { createUser, resetUserPassword, setUserActive, updateUser } from "@/lib/actions/users";
import { AVATAR_COLORS } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import { NAME_MARK, WithName } from "@/components/projects/rich";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input, Select } from "@/components/ui/input";
import { Lozenge } from "@/components/ui/lozenge";
import { PageHeader, ProjectAvatar } from "@/components/ui/misc";
import { Modal } from "@/components/ui/modal";
import { MenuItem, Popover } from "@/components/ui/popover";

export type AdminUser = {
  id: string;
  name: string;
  email: string;
  title: string | null;
  department: string | null;
  role: string;
  active: boolean;
  avatarColor: string;
  lastSeenAt: Date | null;
  createdAt: Date;
  projects: number;
};
type Project = { id: string; key: string; name: string; color: string };

function randomPassword() {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const arr = new Uint32Array(10);
  crypto.getRandomValues(arr);
  return Array.from(arr, (n) => chars[n % chars.length]).join("");
}

export function UsersAdmin({ users, projects, meId }: { users: AdminUser[]; projects: Project[]; meId: string }) {
  const router = useRouter();
  const t = useT("admin");
  const tc = useT("common");
  const tn = useT("nav");
  const te = useT("enums");
  const f = useFormat();
  const [q, setQ] = useState("");
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<AdminUser | null>(null);
  const [resetting, setResetting] = useState<AdminUser | null>(null);
  const [toggling, setToggling] = useState<AdminUser | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const term = q.trim().toLowerCase();
  const list = term
    ? users.filter((u) => [u.name, u.email, u.title, u.department].some((v) => v?.toLowerCase().includes(term)))
    : users;
  const activeCount = users.filter((u) => u.active).length;

  const toggleActive = (u: AdminUser) =>
    start(async () => {
      setError(null);
      const res = await setUserActive(u.id, !u.active);
      if (!res.ok) setError(res.error);
      setToggling(null);
      router.refresh();
    });

  return (
    <>
      <PageHeader
        title={tn("users")}
        breadcrumbs={tn("admin")}
        actions={
          <Button variant="primary" onClick={() => setAdding(true)}>
            <UserPlus className="h-4 w-4" /> {t("addUser")}
          </Button>
        }
      >
        <p className="mt-1 text-sm text-ink-subtle">{t("summary", { active: activeCount, inactive: users.length - activeCount })}</p>
      </PageHeader>

      <div className="mb-3 flex items-center gap-3">
        <div className="relative w-80">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-subtle" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("searchPlaceholder")}
            className="h-8 w-full rounded-[3px] border-2 border-line bg-input pl-8 pr-2 text-sm text-ink placeholder:text-ink-faint focus:border-brand-500 focus:bg-surface-raised focus:outline-none"
          />
        </div>
      </div>
      <FormError message={error} />

      <div className="mt-2 overflow-x-auto rounded-[3px] border border-line bg-surface-raised">
        <table className="w-full min-w-[1000px] text-sm">
          <thead>
            <tr className="border-b-2 border-line text-left text-xs font-semibold text-ink-subtle">
              <th className="px-3 py-2">{t("colUser")}</th>
              <th className="px-3 py-2">{t("colTitle")}</th>
              <th className="px-3 py-2">{t("colDepartment")}</th>
              <th className="w-28 px-3 py-2">{t("colRole")}</th>
              <th className="w-28 px-3 py-2">{t("colStatus")}</th>
              <th className="w-24 px-3 py-2 text-right">{t("colProjects")}</th>
              <th className="w-40 px-3 py-2">{t("colLastSeen")}</th>
              <th className="w-12 px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {list.map((u) => (
              <tr key={u.id} className={cn("border-b border-line last:border-b-0 hover:bg-surface-hover", !u.active && "opacity-60")}>
                <td className="px-3 py-2">
                  <div className="flex items-center gap-2.5">
                    <Avatar user={u} size="md" />
                    <div className="min-w-0">
                      <div className="font-medium text-ink">
                        {u.name} {u.id === meId && <span className="text-xs font-normal text-ink-subtle">{t("you")}</span>}
                      </div>
                      <div className="truncate text-xs text-ink-subtle">{u.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-3 py-2 text-ink-muted">{u.title ?? "—"}</td>
                <td className="px-3 py-2 text-ink-muted">{u.department ?? "—"}</td>
                <td className="px-3 py-2">
                  <Lozenge tone={u.role === "ADMIN" ? "purple" : "todo"}>{te(u.role === "ADMIN" ? "role.ADMIN" : "role.MEMBER")}</Lozenge>
                </td>
                <td className="px-3 py-2">
                  <Lozenge tone={u.active ? "done" : "danger"}>{u.active ? t("active") : t("inactive")}</Lozenge>
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-muted">{u.projects}</td>
                <td className="px-3 py-2 text-ink-muted" title={u.lastSeenAt ? f.dateTime(u.lastSeenAt) : undefined} suppressHydrationWarning>
                  {u.lastSeenAt ? f.relative(u.lastSeenAt) : t("never")}
                </td>
                <td className="px-3 py-2 text-right">
                  <Popover
                    align="right"
                    trigger={({ toggle }) => (
                      <button onClick={toggle} className="rounded p-1 text-ink-subtle hover:bg-tint-2" aria-label={t("actions")}>
                        <MoreHorizontal className="h-4 w-4" />
                      </button>
                    )}
                  >
                    {(close) => (
                      <>
                        <MenuItem
                          onClick={() => {
                            close();
                            setEditing(u);
                          }}
                        >
                          <Pencil className="h-4 w-4 text-ink-subtle" /> {tc("edit")}
                        </MenuItem>
                        <MenuItem
                          onClick={() => {
                            close();
                            setResetting(u);
                          }}
                        >
                          <KeyRound className="h-4 w-4 text-ink-subtle" /> {t("resetPassword")}
                        </MenuItem>
                        {u.id !== meId && (
                          <MenuItem
                            danger={u.active}
                            onClick={() => {
                              close();
                              if (u.active) setToggling(u);
                              else toggleActive(u);
                            }}
                          >
                            {u.active ? <UserX className="h-4 w-4" /> : <UserCheck className="h-4 w-4 text-ink-subtle" />}
                            {u.active ? t("deactivate") : t("activate")}
                          </MenuItem>
                        )}
                      </>
                    )}
                  </Popover>
                </td>
              </tr>
            ))}
            {list.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-8 text-center text-ink-subtle">
                  {t("notFound")}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <AddUserModal open={adding} onClose={() => setAdding(false)} projects={projects} />
      {editing && <EditUserModal user={editing} isMe={editing.id === meId} onClose={() => setEditing(null)} />}
      {resetting && <ResetPasswordModal user={resetting} onClose={() => setResetting(null)} />}

      <Modal
        open={!!toggling}
        onClose={() => setToggling(null)}
        title={t("deactivateTitle")}
        width="sm"
        footer={
          <>
            <Button variant="subtle" onClick={() => setToggling(null)}>
              {tc("cancel")}
            </Button>
            <Button variant="danger" loading={pending} onClick={() => toggling && toggleActive(toggling)}>
              {t("deactivate")}
            </Button>
          </>
        }
      >
        <p className="text-sm text-ink-muted">
          <WithName text={t("deactivateText", { name: NAME_MARK })} name={toggling?.name} />
        </p>
      </Modal>
    </>
  );
}

function ColorSwatches({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {AVATAR_COLORS.map((c) => (
        <button
          key={c}
          type="button"
          onClick={() => onChange(c)}
          style={{ backgroundColor: c }}
          className={cn("h-6 w-6 rounded-full ring-offset-2 ring-offset-surface-overlay", value === c && "ring-2 ring-brand-500")}
          aria-label={c}
        />
      ))}
    </div>
  );
}

function AddUserModal({ open, onClose, projects }: { open: boolean; onClose: () => void; projects: Project[] }) {
  const router = useRouter();
  const t = useT("admin");
  const tc = useT("common");
  const te = useT("enums");
  const [copied, setCopied] = useState(false);
  const blank = () => ({
    name: "",
    email: "",
    title: "",
    department: "",
    role: "MEMBER" as "ADMIN" | "MEMBER",
    password: randomPassword(),
    avatarColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)]!,
    projectIds: [] as string[],
  });
  const [form, setForm] = useState(blank);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<{ email: string; password: string } | null>(null);
  const [pending, start] = useTransition();
  const set = <K extends keyof ReturnType<typeof blank>>(k: K, v: ReturnType<typeof blank>[K]) => setForm((f) => ({ ...f, [k]: v }));

  const close = () => {
    setForm(blank());
    setError(null);
    setCreated(null);
    setCopied(false);
    onClose();
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    start(async () => {
      const res = await createUser(form);
      if (!res.ok) return setError(res.error);
      setCreated({ email: form.email.trim().toLowerCase(), password: form.password });
      router.refresh();
    });
  };

  if (created) {
    return (
      <Modal
        open={open}
        onClose={close}
        title={t("createdTitle")}
        width="sm"
        footer={
          <Button variant="primary" onClick={close}>
            {t("done")}
          </Button>
        }
      >
        <p className="text-sm text-ink-muted">{t("createdText")}</p>
        <div className="mt-3 space-y-1 rounded-[3px] bg-surface-sunken p-3 font-mono text-sm text-ink">
          <div>
            <span className="text-ink-subtle">{t("email")}:</span> {created.email}
          </div>
          <div>
            <span className="text-ink-subtle">{t("password")}:</span> {created.password}
          </div>
        </div>
        <Button
          variant="default"
          size="sm"
          className="mt-2"
          onClick={() => {
            navigator.clipboard
              ?.writeText(`${t("email")}: ${created.email}\n${t("password")}: ${created.password}\n${t("loginUrl")}: ${location.origin}/login`)
              .then(() => setCopied(true));
          }}
        >
          {copied ? t("copied") : t("copy")}
        </Button>
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={close}
      title={t("addUser")}
      footer={
        <>
          <Button variant="subtle" onClick={close}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" type="submit" form="add-user" loading={pending}>
            {tc("add")}
          </Button>
        </>
      }
    >
      <form id="add-user" onSubmit={submit} className="space-y-4">
        <FormError message={error} />
        <div className="flex items-center gap-3">
          <Avatar user={{ name: form.name || "?", avatarColor: form.avatarColor }} size="lg" />
          <ColorSwatches value={form.avatarColor} onChange={(c) => set("avatarColor", c)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("fullName")} htmlFor="u-name" required>
            <Input id="u-name" autoFocus value={form.name} onChange={(e) => set("name", e.target.value)} />
          </Field>
          <Field label={t("email")} htmlFor="u-email" required>
            <Input id="u-email" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} />
          </Field>
          <Field label={t("jobTitle")} htmlFor="u-title">
            <Input id="u-title" value={form.title} onChange={(e) => set("title", e.target.value)} placeholder={t("jobTitlePlaceholder")} />
          </Field>
          <Field label={t("department")} htmlFor="u-dep">
            <Input id="u-dep" value={form.department} onChange={(e) => set("department", e.target.value)} placeholder={t("departmentPlaceholder")} />
          </Field>
          <Field label={t("role")} htmlFor="u-role">
            <Select id="u-role" value={form.role} onChange={(e) => set("role", e.target.value as "ADMIN" | "MEMBER")}>
              <option value="MEMBER">{te("role.MEMBER")}</option>
              <option value="ADMIN">{te("role.ADMIN")}</option>
            </Select>
          </Field>
          <Field label={t("initialPassword")} htmlFor="u-pw" required hint={t("passwordHint")}>
            <div className="flex gap-1.5">
              <Input id="u-pw" value={form.password} onChange={(e) => set("password", e.target.value)} className="font-mono" />
              <Button variant="default" onClick={() => set("password", randomPassword())} className="h-9">
                {t("generate")}
              </Button>
            </div>
          </Field>
        </div>
        {projects.length > 0 && (
          <div>
            <div className="mb-1 text-xs font-semibold text-ink-subtle">{t("addToProjects")}</div>
            <div className="grid max-h-40 grid-cols-2 gap-1 overflow-y-auto rounded-[3px] border border-line p-2">
              {projects.map((p) => (
                <label key={p.id} className="flex cursor-pointer items-center gap-2 rounded px-1.5 py-1 text-sm hover:bg-surface-hover">
                  <input
                    type="checkbox"
                    className="h-4 w-4 accent-brand-600"
                    checked={form.projectIds.includes(p.id)}
                    onChange={(e) => set("projectIds", e.target.checked ? [...form.projectIds, p.id] : form.projectIds.filter((x) => x !== p.id))}
                  />
                  <ProjectAvatar project={p} size="sm" />
                  <span className="truncate">{p.name}</span>
                </label>
              ))}
            </div>
          </div>
        )}
      </form>
    </Modal>
  );
}

function EditUserModal({ user, isMe, onClose }: { user: AdminUser; isMe: boolean; onClose: () => void }) {
  const router = useRouter();
  const t = useT("admin");
  const tc = useT("common");
  const te = useT("enums");
  const [form, setForm] = useState({
    name: user.name,
    email: user.email,
    title: user.title ?? "",
    department: user.department ?? "",
    role: user.role as "ADMIN" | "MEMBER",
    avatarColor: user.avatarColor,
  });
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    start(async () => {
      const res = await updateUser(user.id, form);
      if (!res.ok) return setError(res.error);
      onClose();
      router.refresh();
    });
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={t("editTitle")}
      footer={
        <>
          <Button variant="subtle" onClick={onClose}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" type="submit" form="edit-user" loading={pending}>
            {tc("save")}
          </Button>
        </>
      }
    >
      <form id="edit-user" onSubmit={submit} className="space-y-4">
        <FormError message={error} />
        <div className="flex items-center gap-3">
          <Avatar user={{ name: form.name || "?", avatarColor: form.avatarColor }} size="lg" />
          <ColorSwatches value={form.avatarColor} onChange={(c) => set("avatarColor", c)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("fullName")} htmlFor="e-name" required>
            <Input id="e-name" value={form.name} onChange={(e) => set("name", e.target.value)} />
          </Field>
          <Field label={t("email")} htmlFor="e-email" required>
            <Input id="e-email" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} />
          </Field>
          <Field label={t("jobTitle")} htmlFor="e-title">
            <Input id="e-title" value={form.title} onChange={(e) => set("title", e.target.value)} />
          </Field>
          <Field label={t("department")} htmlFor="e-dep">
            <Input id="e-dep" value={form.department} onChange={(e) => set("department", e.target.value)} />
          </Field>
          <Field label={t("role")} htmlFor="e-role" hint={isMe ? t("cantChangeOwnRole") : undefined}>
            <Select id="e-role" value={form.role} disabled={isMe} onChange={(e) => set("role", e.target.value as "ADMIN" | "MEMBER")}>
              <option value="MEMBER">{te("role.MEMBER")}</option>
              <option value="ADMIN">{te("role.ADMIN")}</option>
            </Select>
          </Field>
        </div>
      </form>
    </Modal>
  );
}

function ResetPasswordModal({ user, onClose }: { user: AdminUser; onClose: () => void }) {
  const t = useT("admin");
  const tc = useT("common");
  const [pw, setPw] = useState(randomPassword);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [pending, start] = useTransition();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    start(async () => {
      const res = await resetUserPassword(user.id, pw);
      if (!res.ok) return setError(res.error);
      setDone(true);
    });
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={t("resetTitle")}
      width="sm"
      footer={
        done ? (
          <Button variant="primary" onClick={onClose}>
            {t("done")}
          </Button>
        ) : (
          <>
            <Button variant="subtle" onClick={onClose}>
              {tc("cancel")}
            </Button>
            <Button variant="primary" type="submit" form="reset-pw" loading={pending}>
              {t("changePassword")}
            </Button>
          </>
        )
      }
    >
      {done ? (
        <div className="space-y-2 text-sm text-ink-muted">
          <p>
            <WithName text={t("newPasswordSet", { name: NAME_MARK })} name={user.name} />
          </p>
          <div className="rounded-[3px] bg-surface-sunken p-3 font-mono text-ink">{pw}</div>
        </div>
      ) : (
        <form id="reset-pw" onSubmit={submit} className="space-y-3">
          <FormError message={error} />
          <p className="text-sm text-ink-muted">
            <WithName text={t("newPasswordFor", { name: NAME_MARK })} name={user.name} />
          </p>
          <Field label={t("newPassword")} htmlFor="r-pw" hint={t("passwordHint")}>
            <div className="flex gap-1.5">
              <Input id="r-pw" value={pw} onChange={(e) => setPw(e.target.value)} className="font-mono" autoFocus />
              <Button variant="default" onClick={() => setPw(randomPassword())} className="h-9">
                {t("generate")}
              </Button>
            </div>
          </Field>
        </form>
      )}
    </Modal>
  );
}
