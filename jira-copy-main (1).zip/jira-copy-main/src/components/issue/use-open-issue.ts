"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useCallback } from "react";

/**
 * Tapşırığı cari səhifənin üstündə modal kimi açır (Jira-dakı ?selectedIssue=KEY kimi).
 * Səhifə serverdə <IssueModalSlot issueKey={searchParams.selectedIssue} /> render etməlidir.
 */
export function useOpenIssue() {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();

  const open = useCallback(
    (key: string) => {
      const sp = new URLSearchParams(params.toString());
      sp.set("selectedIssue", key);
      router.push(`${pathname}?${sp.toString()}`, { scroll: false });
    },
    [router, pathname, params],
  );

  const close = useCallback(() => {
    const sp = new URLSearchParams(params.toString());
    sp.delete("selectedIssue");
    const q = sp.toString();
    router.push(q ? `${pathname}?${q}` : pathname, { scroll: false });
  }, [router, pathname, params]);

  return { open, close };
}
