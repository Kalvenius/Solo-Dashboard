"use client";

import { ISSUE_TYPE_META, PRIORITY_META, type IssueType, type Priority } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";

/** Jira tipli tapşırıq növü ikonu (16x16 rəngli kvadrat) */
export function IssueTypeIcon({ type, className }: { type: string; className?: string }) {
  const te = useT("enums");
  const tp = (type in ISSUE_TYPE_META ? type : "TASK") as IssueType;
  const meta = ISSUE_TYPE_META[tp];
  return (
    <span
      title={te(`type.${tp}`)}
      style={{ backgroundColor: meta.color }}
      className={cn("inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-[3px] text-white", className)}
    >
      <svg viewBox="0 0 16 16" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        {type === "EPIC" && <path d="M9 2 4 9h4l-1 5 5-7H8l1-5Z" fill="currentColor" stroke="none" />}
        {type === "STORY" && <path d="M5 2.5h6v11L8 11l-3 2.5v-11Z" fill="currentColor" stroke="none" />}
        {type === "TASK" && <path d="m4.5 8.5 2.5 2.5 4.5-5.5" />}
        {type === "BUG" && <circle cx="8" cy="8" r="3.2" fill="currentColor" stroke="none" />}
        {type === "SUBTASK" && (
          <>
            <rect x="3" y="3" width="6" height="6" rx="1" strokeWidth="1.6" />
            <rect x="7" y="7" width="6" height="6" rx="1" fill="currentColor" stroke="none" />
          </>
        )}
      </svg>
    </span>
  );
}

/** Prioritet oxları (Jira kimi) */
export function PriorityIcon({ priority, className, withLabel }: { priority: string; className?: string; withLabel?: boolean }) {
  const te = useT("enums");
  const p = (priority in PRIORITY_META ? priority : "MEDIUM") as Priority;
  const meta = PRIORITY_META[p];
  const label = te(`priority.${p}`);
  const icon = (
    <svg viewBox="0 0 16 16" className={cn("h-4 w-4 shrink-0", className)} fill="none" stroke={meta.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-label={label}>
      <title>{label}</title>
      {priority === "HIGHEST" && (
        <>
          <path d="m3.5 8 4.5-4 4.5 4" />
          <path d="m3.5 12 4.5-4 4.5 4" />
        </>
      )}
      {priority === "HIGH" && <path d="m3.5 10 4.5-4.5 4.5 4.5" />}
      {priority === "MEDIUM" && (
        <>
          <path d="M3.5 6h9" />
          <path d="M3.5 10h9" />
        </>
      )}
      {priority === "LOW" && <path d="m3.5 6 4.5 4.5 4.5-4.5" />}
      {priority === "LOWEST" && (
        <>
          <path d="m3.5 4 4.5 4 4.5-4" />
          <path d="m3.5 8 4.5 4 4.5-4" />
        </>
      )}
    </svg>
  );
  if (!withLabel) return icon;
  return (
    <span className="inline-flex items-center gap-1.5">
      {icon}
      <span>{label}</span>
    </span>
  );
}

/** Story point dairəsi */
export function PointsBadge({ points, className }: { points: number | null | undefined; className?: string }) {
  const t = useT("common");
  if (points == null) return null;
  return (
    <span title={t("storyPoints")} className={cn("inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-neutral px-1.5 text-[11px] font-semibold text-ink-muted", className)}>
      {points}
    </span>
  );
}

/** Epic adı nişanı */
export function EpicTag({ title, className }: { title: string; className?: string }) {
  return (
    <span className={cn("inline-block max-w-[140px] truncate rounded-[3px] bg-discovery-subtle px-1.5 text-[11px] font-semibold uppercase leading-5 text-discovery", className)}>
      {title}
    </span>
  );
}
