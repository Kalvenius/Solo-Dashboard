"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, Info, X, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";

export type ToastInput = { message: string; tone?: "info" | "success" | "error"; href?: string; actionLabel?: string };
type ToastItem = ToastInput & { id: number };

const EVENT = "solo:toast";
let counter = 0;
let owner: symbol | null = null;

/** Hər yerdən çağırmaq olar: toast({ message: "Saxlanıldı", tone: "success" }) */
export function toast(t: ToastInput) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent<ToastInput>(EVENT, { detail: t }));
}

/** Bir dəfə mount olunur (TopNav-dakı "Yarat" düyməsi ilə). Təkrar mount olunsa, yalnız birincisi işləyir. */
export function Toaster() {
  const tc = useT("common");
  const [items, setItems] = useState<ToastItem[]>([]);
  const [active, setActive] = useState(false);

  useEffect(() => {
    const me = Symbol("toaster");
    if (owner) return;
    owner = me;
    setActive(true);
    const onToast = (e: Event) => {
      const detail = (e as CustomEvent<ToastInput>).detail;
      const id = ++counter;
      setItems((prev) => [...prev.slice(-3), { ...detail, id }]);
      setTimeout(() => setItems((prev) => prev.filter((x) => x.id !== id)), detail.tone === "error" ? 7000 : 5000);
    };
    window.addEventListener(EVENT, onToast);
    return () => {
      window.removeEventListener(EVENT, onToast);
      if (owner === me) owner = null;
    };
  }, []);

  if (!active || typeof document === "undefined") return null;
  return createPortal(
    <div className="pointer-events-none fixed bottom-6 left-6 z-[70] flex w-[360px] max-w-[calc(100vw-48px)] flex-col gap-2">
      {items.map((t) => (
        <div key={t.id} className="pointer-events-auto flex items-start gap-3 rounded-[3px] bg-surface-overlay px-4 py-3 text-sm text-ink shadow-overlay">
          {t.tone === "error" ? (
            <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-danger-bold" />
          ) : t.tone === "success" ? (
            <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-success-bold" />
          ) : (
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
          )}
          <div className="min-w-0 flex-1">
            <div className={cn("break-words", t.tone === "error" && "text-danger")}>{t.message}</div>
            {t.href && (
              <Link href={t.href} className="mt-1 inline-block font-medium text-brand-600 hover:underline">
                {t.actionLabel ?? tc("view")}
              </Link>
            )}
          </div>
          <button onClick={() => setItems((prev) => prev.filter((x) => x.id !== t.id))} className="rounded p-0.5 text-ink-subtle hover:bg-surface-hover" aria-label={tc("close")}>
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>,
    document.body,
  );
}
