import { requireUser } from "@/lib/auth";
import { loadIssueDetail } from "@/lib/issue-detail-query";
import { IssueDetail } from "./issue-detail";
import { IssueModalShell } from "./issue-detail/modal-shell";
import { NotFoundBody } from "./issue-detail/not-found";

/**
 * Səhifənin üstündə tapşırıq modalı. İstifadə (server səhifədə):
 *   <IssueModalSlot issueKey={(await searchParams).selectedIssue} />
 * Açmaq üçün client tərəfdə useOpenIssue().open(KEY).
 */
export async function IssueModalSlot({ issueKey }: { issueKey?: string }) {
  if (!issueKey) return null;
  const user = await requireUser();
  const data = await loadIssueDetail(issueKey, user);
  if (!data) {
    return (
      <IssueModalShell width="sm">
        <NotFoundBody issueKey={issueKey} />
      </IssueModalShell>
    );
  }
  return (
    <IssueModalShell>
      <IssueDetail key={data.issue.id} data={data} variant="modal" />
    </IssueModalShell>
  );
}
