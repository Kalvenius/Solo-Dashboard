"use client";

import { useState, type ReactNode } from "react";
import { ArrowRight } from "lucide-react";
import { ISSUE_TYPES, PRIORITIES } from "@/lib/constants";
import type { IssueDetailData } from "@/lib/issue-detail-query";
import { addComment, deleteComment, deleteWorklog, updateComment } from "@/lib/actions/issues";
import { cn } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import type { Formatters } from "@/i18n/fmt";
import type { Translator } from "@/i18n/types";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { StatusLozenge } from "@/components/ui/lozenge";
import { Markdown } from "../markdown";
import { rich, useDetail, useRun } from "./hooks";

type Data = IssueDetailData;
type Issue = Data["issue"];
type Comment = Issue["comments"][number];
type Act = Issue["activities"][number];
type Worklog = Issue["worklogs"][number];

const TABS = [
  { id: "all", label: "tabAll" },
  { id: "comments", label: "tabComments" },
  { id: "history", label: "tabHistory" },
  { id: "worklog", label: "tabWorklog" },
] as const;
type Tab = (typeof TABS)[number]["id"];

type T = { t: Translator<"issue">; tc: Translator<"common">; te: Translator<"enums">; f: Formatters };

function useTr(): T {
  return { t: useT("issue"), tc: useT("common"), te: useT("enums"), f: useFormat() };
}

const HISTORY_FIELDS = ["status", "assignee", "reporter", "priority", "title", "description", "type", "sprint", "parent", "storyPoints", "dueDate", "startDate", "labels", "estimate"] as const;

// ---------- tarixçə mətnləri ----------

function fmtValue({ tc, te, f }: T, field: string, v: string | null): ReactNode {
  if (v == null || v === "") return <span className="text-ink-subtle">{tc("none")}</span>;
  switch (field) {
    case "priority":
      return (PRIORITIES as readonly string[]).includes(v) ? te(`priority.${v as (typeof PRIORITIES)[number]}`) : v;
    case "type":
      return (ISSUE_TYPES as readonly string[]).includes(v) ? te(`type.${v as (typeof ISSUE_TYPES)[number]}`) : v;
    case "estimate":
      return f.minutes(Number(v));
    case "startDate":
    case "dueDate":
      return f.date(`${v}T12:00:00`);
    case "labels":
      return v.split(",").join(", ");
    default:
      return v;
  }
}

function fieldLabel({ te }: T, field: string) {
  return (HISTORY_FIELDS as readonly string[]).includes(field) ? te(`field.${field as (typeof HISTORY_FIELDS)[number]}`) : field;
}

function HistoryItem({ a }: { a: Act }) {
  const tr = useTr();
  const { t, tc, f } = tr;
  const b = (v: ReactNode) => <span className="font-medium">{v}</span>;
  let text: ReactNode;
  let detail: ReactNode = null;
  if (a.action === "CREATED") text = t("hCreated");
  else if (a.action === "ATTACHED") text = rich((p) => t("hAttached", p), { file: b(a.toValue) });
  else if (a.action === "LOGGED_WORK") text = rich((p) => t("hLogged", p), { time: b(f.minutes(Number(a.toValue))) });
  else if (a.field === "description") text = t("hDescription");
  else if (a.field === "link")
    text = a.toValue ? rich((p) => t("hLinkAdded", p), { key: b(a.toValue) }) : rich((p) => t("hLinkRemoved", p), { key: b(a.fromValue) });
  else if (a.field) {
    text = rich((p) => t("hChanged", p), { field: b(fieldLabel(tr, a.field)) });
    detail =
      a.field === "status" ? (
        <span className="flex items-center gap-2">
          {a.fromValue ? <StatusLozenge status={a.fromValue} /> : <span className="text-ink-subtle">{tc("none")}</span>}
          <ArrowRight className="h-3.5 w-3.5 text-ink-subtle" />
          {a.toValue ? <StatusLozenge status={a.toValue} /> : <span className="text-ink-subtle">{tc("none")}</span>}
        </span>
      ) : (
        <span className="flex flex-wrap items-center gap-2 text-sm text-ink">
          <span className={a.field !== "title" ? "" : "line-through decoration-ink-faint"}>{fmtValue(tr, a.field, a.fromValue)}</span>
          <ArrowRight className="h-3.5 w-3.5 text-ink-subtle" />
          <span>{fmtValue(tr, a.field, a.toValue)}</span>
        </span>
      );
  } else text = t("hGeneric");

  return (
    <div className="flex gap-3 py-2">
      <Avatar user={a.actor} size="md" />
      <div className="min-w-0 flex-1">
        <div className="text-sm text-ink">
          <span className="font-semibold">{a.actor.name}</span> {text}{" "}
          <span className="text-xs text-ink-subtle" title={f.dateTime(a.createdAt)} suppressHydrationWarning>
            {f.relative(a.createdAt)}
          </span>
        </div>
        {detail && <div className="mt-1">{detail}</div>}
      </div>
    </div>
  );
}

// ---------- şərhlər ----------

function CommentComposer({ me }: { me: Data["me"] }) {
  const { issueId } = useDetail();
  const [open, setOpen] = useState(false);
  const [body, setBody] = useState("");
  const { pending, run } = useRun();
  const { t, tc } = useTr();
  const submit = () => {
    if (!body.trim()) return;
    run(
      () => addComment(issueId, body),
      () => {
        setBody("");
        setOpen(false);
      },
    );
  };
  return (
    <div className="flex gap-3 py-2">
      <Avatar user={me.user} size="md" />
      <div className="min-w-0 flex-1">
        {open ? (
          <>
            <Textarea
              autoFocus
              value={body}
              onChange={(e) => setBody(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit();
                if (e.key === "Escape") {
                  e.preventDefault();
                  if (!body.trim()) setOpen(false);
                }
              }}
              placeholder={t("addComment")}
              className="min-h-[90px]"
            />
            <div className="mt-2 flex items-center gap-2">
              <Button variant="primary" onClick={submit} loading={pending} disabled={!body.trim()}>
                {tc("save")}
              </Button>
              <Button
                variant="subtle"
                onClick={() => {
                  setBody("");
                  setOpen(false);
                }}
              >
                {tc("cancel")}
              </Button>
              <span className="ml-auto text-xs text-ink-subtle">{t("commentHint")}</span>
            </div>
          </>
        ) : (
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="h-10 w-full rounded-[3px] border border-line px-3 text-left text-sm text-ink-subtle hover:bg-surface-sunken"
          >
            {t("addComment")}
          </button>
        )}
      </div>
    </div>
  );
}

function CommentItem({ c, me }: { c: Comment; me: Data["me"] }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(c.body);
  const [confirm, setConfirm] = useState(false);
  const { pending, run } = useRun();
  const edited = new Date(c.updatedAt).getTime() - new Date(c.createdAt).getTime() > 2000;
  const own = c.authorId === me.id;
  const { t, tc, f } = useTr();

  return (
    <div className="flex gap-3 py-2">
      <Avatar user={c.author} size="md" />
      <div className="min-w-0 flex-1">
        <div className="text-sm">
          <span className="font-semibold text-ink">{c.author.name}</span>{" "}
          <span className="text-xs text-ink-subtle" title={f.dateTime(c.createdAt)} suppressHydrationWarning>
            {f.relative(c.createdAt)}
          </span>
          {edited && <span className="ml-1 text-xs text-ink-subtle">{t("edited")}</span>}
        </div>
        {editing ? (
          <div className="mt-1">
            <Textarea autoFocus value={draft} onChange={(e) => setDraft(e.target.value)} className="min-h-[80px]" />
            <div className="mt-2 flex gap-2">
              <Button variant="primary" loading={pending} disabled={!draft.trim()} onClick={() => run(() => updateComment(c.id, draft), () => setEditing(false))}>
                {tc("save")}
              </Button>
              <Button variant="subtle" onClick={() => setEditing(false)}>
                {tc("cancel")}
              </Button>
            </div>
          </div>
        ) : (
          <>
            <Markdown text={c.body} className="mt-0.5" />
            <div className="mt-1 flex items-center gap-3 text-xs font-medium text-ink-subtle">
              {own && (
                <button
                  type="button"
                  onClick={() => {
                    setDraft(c.body);
                    setEditing(true);
                  }}
                  className="hover:text-ink hover:underline"
                >
                  {tc("edit")}
                </button>
              )}
              {(own || me.canManage) &&
                (confirm ? (
                  <span className="flex items-center gap-2">
                    <span className="text-ink">{t("deleteConfirm")}</span>
                    <button type="button" onClick={() => run(() => deleteComment(c.id))} className="text-danger-bold hover:underline">
                      {tc("yes")}
                    </button>
                    <button type="button" onClick={() => setConfirm(false)} className="hover:underline">
                      {tc("no")}
                    </button>
                  </span>
                ) : (
                  <button type="button" onClick={() => setConfirm(true)} className="hover:text-ink hover:underline">
                    {tc("delete")}
                  </button>
                ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function WorklogItem({ w, me }: { w: Worklog; me: Data["me"] }) {
  const { run } = useRun();
  const { t, tc, f } = useTr();
  return (
    <div className="group flex gap-3 py-2">
      <Avatar user={w.user} size="md" />
      <div className="min-w-0 flex-1">
        <div className="text-sm text-ink">
          <span className="font-semibold">{w.user.name}</span> {rich((p) => t("hLogged", p), { time: <span className="font-medium">{f.minutes(w.minutes)}</span> })}{" "}
          <span className="text-xs text-ink-subtle">· {f.date(w.startedAt)}</span>
        </div>
        {w.note && <div className="mt-0.5 text-sm text-ink-muted">{w.note}</div>}
      </div>
      {(w.userId === me.id || me.canManage) && (
        <button
          type="button"
          onClick={() => run(() => deleteWorklog(w.id))}
          className="self-start text-xs font-medium text-ink-subtle opacity-0 hover:text-danger-bold hover:underline group-hover:opacity-100"
        >
          {tc("delete")}
        </button>
      )}
    </div>
  );
}

// ---------- əsas komponent ----------

export function ActivitySection({ data }: { data: Data }) {
  const [tab, setTab] = useState<Tab>("comments");
  const { issue, me } = data;
  const { t, f } = useTr();

  type Entry = { at: number; key: string; node: ReactNode };
  const commentEntries: Entry[] = issue.comments.map((c) => ({ at: new Date(c.createdAt).getTime(), key: `c-${c.id}`, node: <CommentItem key={`c-${c.id}`} c={c} me={me} /> }));
  const worklogEntries: Entry[] = issue.worklogs.map((w) => ({ at: new Date(w.startedAt).getTime(), key: `w-${w.id}`, node: <WorklogItem key={`w-${w.id}`} w={w} me={me} /> }));
  const historyEntries = (excludeWork: boolean): Entry[] =>
    issue.activities
      .filter((a) => !(excludeWork && a.action === "LOGGED_WORK"))
      .map((a) => ({ at: new Date(a.createdAt).getTime(), key: `a-${a.id}`, node: <HistoryItem key={`a-${a.id}`} a={a} /> }));

  let entries: Entry[];
  if (tab === "comments") entries = commentEntries;
  else if (tab === "history") entries = historyEntries(false);
  else if (tab === "worklog") entries = worklogEntries;
  else entries = [...commentEntries, ...worklogEntries, ...historyEntries(true)].sort((a, b) => b.at - a.at);

  const total = issue.worklogs.reduce((s, w) => s + w.minutes, 0);
  const empty = t(({ comments: "emptyComments", history: "emptyHistory", worklog: "emptyWorklog", all: "emptyAll" } as const)[tab]);

  return (
    <section>
      <h3 className="mb-2 text-sm font-semibold text-ink">{t("activity")}</h3>
      <div className="mb-2 flex items-center gap-1">
        <span className="mr-1 text-sm text-ink-subtle">{t("show")}</span>
        {TABS.map((x) => (
          <button
            key={x.id}
            type="button"
            onClick={() => setTab(x.id)}
            className={cn(
              "h-7 rounded-[3px] px-2 text-sm font-medium",
              tab === x.id ? "bg-brand-50 text-brand-700" : "text-ink-muted hover:bg-tint-1",
            )}
          >
            {t(x.label)}
            {x.id === "comments" && issue.comments.length > 0 && <span className="ml-1 text-xs">({issue.comments.length})</span>}
          </button>
        ))}
        {tab === "worklog" && total > 0 && <span className="ml-auto text-xs text-ink-subtle">{t("total", { time: f.minutes(total) })}</span>}
      </div>
      {(tab === "comments" || tab === "all") && <CommentComposer me={me} />}
      <div className="divide-y divide-transparent">
        {entries.length === 0 ? <p className="py-4 text-sm text-ink-subtle">{empty}</p> : entries.map((e) => e.node)}
      </div>
    </section>
  );
}
