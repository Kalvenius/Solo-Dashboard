"use client";

import { useEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useOpenIssue } from "../use-open-issue";

/** ?selectedIssue=KEY modalının örtüyü. İçində IssueDetail (variant="modal") göstərilir. */
export function IssueModalShell({ children, width = "xl" }: { children: ReactNode; width?: "sm" | "xl" }) {
  const { close } = useOpenIssue();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape" || e.defaultPrevented) return;
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
      // içəridə başqa dialoq (məs. silmə təsdiqi) açıqdırsa, əvvəlcə o bağlanır
      if (document.querySelectorAll('[role="dialog"]').length > 1) return;
      close();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [close]);

  if (!mounted) return null;
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-backdrop p-4 pt-[4vh]" onMouseDown={close}>
      <div
        role="dialog"
        aria-modal="true"
        className={width === "xl" ? "relative mb-10 w-full max-w-[1100px] rounded-[3px] bg-surface-overlay shadow-overlay" : "relative w-full max-w-[420px] rounded-[3px] bg-surface-overlay shadow-overlay"}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>,
    document.body,
  );
}
