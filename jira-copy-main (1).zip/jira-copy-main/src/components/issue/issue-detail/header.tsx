"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Clock, Eye, Link2, Maximize2, MoreHorizontal, Trash2, X } from "lucide-react";
import type { IssueDetailData } from "@/lib/issue-detail-query";
import { deleteIssue, toggleWatch } from "@/lib/actions/issues";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { MenuItem, Popover } from "@/components/ui/popover";
import { ProjectAvatar } from "@/components/ui/misc";
import { IssueTypeIcon } from "../icons";
import { toast } from "../toast";
import { useOpenIssue } from "../use-open-issue";
import { IssueRefLink, useDetail, useRun, useSynced } from "./hooks";
import { LogWorkModal } from "./sidebar";
import { useT } from "@/i18n/client";

function Crumb({ children }: { children: React.ReactNode }) {
  return <span className="flex min-w-0 items-center gap-1.5">{children}</span>;
}

export function IssueHeader({ data }: { data: IssueDetailData }) {
  const { issue, me } = data;
  const { variant } = useDetail();
  const { close } = useOpenIssue();
  const router = useRouter();
  const { pending, run } = useRun();
  const [watching, setWatching] = useSynced(me.watching);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [logOpen, setLogOpen] = useState(false);
  const t = useT("issue");
  const tc = useT("common");

  const watcherCount = issue.watchers.length + (watching === me.watching ? 0 : watching ? 1 : -1);
  const epic = issue.parent?.type === "EPIC" ? issue.parent : issue.parent?.parent?.type === "EPIC" ? issue.parent.parent : null;
  const directParent = issue.type === "SUBTASK" ? issue.parent : null;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/browse/${issue.key}`);
      toast({ message: tc("linkCopied"), tone: "success" });
    } catch {
      toast({ message: t("copyFailed"), tone: "error" });
    }
  };

  const doDelete = () =>
    run(
      () => deleteIssue(issue.id),
      (d) => {
        setConfirmDelete(false);
        toast({ message: t("deleted", { key: issue.key }), tone: "success" });
        if (variant === "modal") close();
        else router.push(`/projects/${d?.projectKey ?? issue.project.key}/board`);
      },
    );

  return (
    <div className="flex items-center justify-between gap-3">
      <nav className="flex min-w-0 flex-wrap items-center gap-1.5 text-sm text-ink-subtle">
        <Crumb>
          <ProjectAvatar project={issue.project} size="sm" />
          <Link href={`/projects/${issue.project.key}/board`} className="truncate hover:underline">
            {issue.project.name}
          </Link>
        </Crumb>
        {epic && (
          <>
            <span>/</span>
            <Crumb>
              <IssueTypeIcon type="EPIC" />
              <IssueRefLink issueKey={epic.key} className="truncate">
                {epic.key}
              </IssueRefLink>
            </Crumb>
          </>
        )}
        {directParent && (
          <>
            <span>/</span>
            <Crumb>
              <IssueTypeIcon type={directParent.type} />
              <IssueRefLink issueKey={directParent.key}>{directParent.key}</IssueRefLink>
            </Crumb>
          </>
        )}
        <span>/</span>
        <Crumb>
          <IssueTypeIcon type={issue.type} />
          <Link href={`/browse/${issue.key}`} className="font-medium text-ink-muted hover:underline">
            {issue.key}
          </Link>
        </Crumb>
      </nav>

      <div className="flex shrink-0 items-center gap-1">
        <Button
          variant="subtle"
          size="sm"
          title={
            (watching ? t("unwatch") : t("watch")) +
            (issue.watchers.length ? `\n${t("watchers", { names: issue.watchers.map((w) => w.user.name).join(", ") })}` : "")
          }
          onClick={() => {
            const next = !watching;
            setWatching(next);
            run(() => toggleWatch(issue.id), undefined, () => setWatching(!next));
          }}
          className={cn(watching && "bg-brand-50 text-brand-700 hover:bg-brand-100")}
        >
          <Eye className="h-4 w-4" />
          <span className="tabular-nums">{Math.max(0, watcherCount)}</span>
        </Button>
        <Popover
          align="right"
          className="w-52"
          trigger={({ toggle }) => (
            <Button variant="subtle" size="icon" onClick={toggle} title={t("actions")}>
              <MoreHorizontal className="h-5 w-5" />
            </Button>
          )}
        >
          {(closeMenu) => (
            <>
              <MenuItem
                onClick={() => {
                  closeMenu();
                  copyLink();
                }}
              >
                <Link2 className="h-4 w-4 text-ink-subtle" /> {tc("copyLink")}
              </MenuItem>
              <MenuItem
                onClick={() => {
                  closeMenu();
                  setLogOpen(true);
                }}
              >
                <Clock className="h-4 w-4 text-ink-subtle" /> {t("logTime")}
              </MenuItem>
              {me.canDelete && (
                <>
                  <div className="my-1 border-t border-line" />
                  <MenuItem
                    danger
                    onClick={() => {
                      closeMenu();
                      setConfirmDelete(true);
                    }}
                  >
                    <Trash2 className="h-4 w-4" /> {tc("delete")}
                  </MenuItem>
                </>
              )}
            </>
          )}
        </Popover>
        {variant === "modal" && (
          <>
            <Link href={`/browse/${issue.key}`} className="rounded-[3px] p-2 text-ink-muted hover:bg-tint-1" title={tc("openFullPage")}>
              <Maximize2 className="h-4 w-4" />
            </Link>
            <button type="button" onClick={close} className="rounded-[3px] p-1.5 text-ink-muted hover:bg-tint-1" aria-label={tc("close")} title={t("closeEsc")}>
              <X className="h-5 w-5" />
            </button>
          </>
        )}
      </div>

      <LogWorkModal open={logOpen} onClose={() => setLogOpen(false)} />
      <Modal
        open={confirmDelete}
        onClose={() => setConfirmDelete(false)}
        title={t("deleteTitle", { key: issue.key })}
        width="sm"
        footer={
          <>
            <Button variant="subtle" onClick={() => setConfirmDelete(false)}>
              {tc("cancel")}
            </Button>
            <Button variant="danger" onClick={doDelete} loading={pending}>
              {tc("delete")}
            </Button>
          </>
        }
      >
        <p className="text-sm text-ink">
          {issue.type !== "EPIC" && issue.children.length ? t("deleteBodySubtasks") : t("deleteBody")}
        </p>
        {issue.type === "EPIC" && issue.children.length > 0 && (
          <p className="mt-2 text-sm text-ink-subtle">{t("deleteEpicNote", { n: issue.children.length })}</p>
        )}
      </Modal>
    </div>
  );
}
