"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { FileText, Link2, Paperclip, Plus, Trash2, X } from "lucide-react";
import { LINK_TYPES, STATUSES, STATUS_META, type LinkType } from "@/lib/constants";
import type { IssueDetailData } from "@/lib/issue-detail-query";
import { addLink, createIssue, deleteAttachment, refreshAfterUpload, removeLink, searchIssuesForLink, updateIssue } from "@/lib/actions/issues";
import { cn, pct } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import type { Translator } from "@/i18n/types";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Select, Textarea } from "@/components/ui/input";
import { StatusLozenge } from "@/components/ui/lozenge";
import { ProgressBar } from "@/components/ui/misc";
import { Picker } from "@/components/ui/picker";
import { IssueTypeIcon, PriorityIcon } from "../icons";
import { Markdown } from "../markdown";
import { toast } from "../toast";
import { IssueRefLink, SectionTitle, fmtBytes, useDetail, useField, useRun, useSynced } from "./hooks";

type Issue = IssueDetailData["issue"];

// ---------- Başlıq ----------

export function TitleEditor({ title }: { title: string }) {
  const f = useField(title, (v) => ({ title: v }));
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(title);
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (editing && ref.current) {
      ref.current.style.height = "auto";
      ref.current.style.height = `${ref.current.scrollHeight}px`;
    }
  }, [editing, draft]);

  if (!editing) {
    return (
      <h1
        onClick={() => {
          setDraft(f.value);
          setEditing(true);
        }}
        className="-mx-1.5 cursor-text rounded-[3px] px-1.5 py-1 text-2xl font-medium leading-tight text-ink hover:bg-tint-1"
      >
        {f.value}
      </h1>
    );
  }
  const commit = () => {
    setEditing(false);
    const t = draft.trim();
    if (t && t !== f.value) f.save(t);
  };
  return (
    <textarea
      ref={ref}
      autoFocus
      rows={1}
      value={draft}
      onChange={(e) => setDraft(e.target.value.replace(/\n/g, ""))}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          commit();
        }
        if (e.key === "Escape") {
          e.preventDefault();
          setEditing(false);
        }
      }}
      className="-mx-1.5 w-[calc(100%+12px)] resize-none overflow-hidden rounded-[3px] border-2 border-brand-500 px-1 py-0.5 text-2xl font-medium leading-tight text-ink focus:outline-none"
    />
  );
}

// ---------- Təsvir ----------

export function DescriptionEditor({ description }: { description: string | null }) {
  const { issueId } = useDetail();
  const [value, setValue] = useSynced(description ?? "");
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const { pending, run } = useRun();
  const t = useT("issue");
  const tc = useT("common");

  const save = () =>
    run(
      () => updateIssue(issueId, { description: draft }),
      () => {
        setValue(draft.trim());
        setEditing(false);
      },
    );

  return (
    <section>
      <SectionTitle>{t("description")}</SectionTitle>
      {editing ? (
        <div>
          <Textarea
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) save();
              if (e.key === "Escape") {
                e.preventDefault();
                setEditing(false);
              }
            }}
            className="min-h-[160px]"
            placeholder={t("addDescription")}
          />
          <div className="mt-2 flex items-center gap-2">
            <Button variant="primary" onClick={save} loading={pending}>
              {tc("save")}
            </Button>
            <Button variant="subtle" onClick={() => setEditing(false)}>
              {tc("cancel")}
            </Button>
            <span className="ml-auto text-xs text-ink-subtle">{t("markdownHint")}</span>
          </div>
        </div>
      ) : (
        <div
          onClick={(e) => {
            if ((e.target as HTMLElement).closest("a")) return;
            setDraft(value);
            setEditing(true);
          }}
          className="-mx-1.5 min-h-[40px] cursor-text rounded-[3px] px-1.5 py-1 hover:bg-tint-1"
        >
          {value ? <Markdown text={value} /> : <p className="text-sm text-ink-subtle">{t("addDescription")}</p>}
        </div>
      )}
    </section>
  );
}

// ---------- Alt tapşırıqlar / Epic tapşırıqları ----------

function ChildStatus({ id, status }: { id: string; status: string }) {
  const { run } = useRun();
  const te = useT("enums");
  const [v, setV] = useSynced(status);
  return (
    <Picker
      options={STATUSES.map((s) => ({ value: s, label: te(`status.${s}`) }))}
      value={v}
      align="right"
      className="w-48"
      onChange={(s) => {
        if (!s || s === v) return;
        const prev = v;
        setV(s);
        run(() => updateIssue(id, { status: s }), undefined, () => setV(prev));
      }}
      renderTrigger={() => <StatusLozenge status={v} className="cursor-pointer hover:opacity-80" />}
    />
  );
}

export function ChildIssues({ issue, adding, setAdding }: { issue: Issue; adding: boolean; setAdding: (v: boolean) => void }) {
  const isEpic = issue.type === "EPIC";
  const children = issue.children;
  const done = children.filter((c) => c.status === "DONE").length;
  const [title, setTitle] = useState("");
  const [type, setType] = useState(isEpic ? "STORY" : "SUBTASK");
  const { pending, run } = useRun();
  const t = useT("issue");
  const tc = useT("common");
  const te = useT("enums");

  if (issue.type === "SUBTASK") return null;
  if (!children.length && !adding) return null;

  const submit = () => {
    const t = title.trim();
    if (!t) return;
    run(
      () =>
        createIssue({
          projectId: issue.projectId,
          type,
          title: t,
          parentId: issue.id,
          sprintId: null,
          assigneeId: isEpic ? null : issue.assigneeId,
        }),
      () => setTitle(""),
    );
  };

  return (
    <section>
      <SectionTitle
        actions={
          <Button size="icon" variant="subtle" onClick={() => setAdding(true)} title={tc("add")} className="h-7 w-7">
            <Plus className="h-4 w-4" />
          </Button>
        }
      >
        {isEpic ? t("epicChildren") : t("subtasks")}
      </SectionTitle>
      {children.length > 0 && (
        <div className="mb-2 flex items-center gap-3">
          <ProgressBar
            className="flex-1"
            segments={[
              { value: done, color: "rgb(var(--c-success-bold))", label: te("status.DONE") },
              { value: children.filter((c) => STATUS_META[c.status as keyof typeof STATUS_META]?.category === "progress").length, color: "rgb(var(--c-brand-600))", label: te("status.IN_PROGRESS") },
              { value: children.filter((c) => c.status === "TODO").length, color: "rgb(var(--c-neutral-strong))", label: te("status.TODO") },
            ]}
          />
          <span className="text-xs font-medium text-ink-subtle">{t("percentDone", { n: pct(done, children.length) })}</span>
        </div>
      )}
      <div className="divide-y divide-line overflow-hidden rounded-[3px] border border-line">
        {children.map((c) => (
          <div key={c.id} className="flex items-center gap-2 px-2.5 py-1.5 hover:bg-surface-sunken">
            <IssueTypeIcon type={c.type} />
            <IssueRefLink issueKey={c.key} className={cn("shrink-0 text-sm font-medium text-brand-600", c.status === "DONE" && "line-through")}>
              {c.key}
            </IssueRefLink>
            <IssueRefLink issueKey={c.key} className="min-w-0 flex-1 truncate text-sm text-ink">
              {c.title}
            </IssueRefLink>
            <PriorityIcon priority={c.priority} />
            <Avatar user={c.assignee} size="xs" />
            <ChildStatus id={c.id} status={c.status} />
          </div>
        ))}
        {adding && (
          <div className="flex items-center gap-2 bg-surface-raised px-2 py-1.5">
            {isEpic ? (
              <Select value={type} onChange={(e) => setType(e.target.value)} className="h-8 w-28">
                <option value="STORY">{te("type.STORY")}</option>
                <option value="TASK">{te("type.TASK")}</option>
                <option value="BUG">{te("type.BUG")}</option>
              </Select>
            ) : (
              <IssueTypeIcon type="SUBTASK" className="ml-1" />
            )}
            <input
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submit();
                if (e.key === "Escape") {
                  e.preventDefault();
                  setAdding(false);
                }
              }}
              placeholder={isEpic ? t("whatNeedsDoing") : t("subtaskSummary")}
              className="h-8 min-w-0 flex-1 rounded-[3px] border-2 border-brand-500 bg-input px-2 text-sm text-ink focus:outline-none"
            />
            <Button variant="primary" size="sm" onClick={submit} loading={pending} disabled={!title.trim()}>
              {tc("create")}
            </Button>
            <Button variant="subtle" size="sm" onClick={() => setAdding(false)}>
              {tc("cancel")}
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}

// ---------- Əlaqəli tapşırıqlar ----------

// RELATES simmetrikdir — yalnız bir istiqamət göstərilir. Ad: enums "linkOut.X" / "linkIn.X"
const LINK_CHOICES: { value: string; type: LinkType; direction: "out" | "in" }[] = [
  { value: "BLOCKS:out", type: "BLOCKS", direction: "out" },
  { value: "BLOCKS:in", type: "BLOCKS", direction: "in" },
  { value: "RELATES:out", type: "RELATES", direction: "out" },
  { value: "DUPLICATES:out", type: "DUPLICATES", direction: "out" },
  { value: "DUPLICATES:in", type: "DUPLICATES", direction: "in" },
];

function linkLabel(te: Translator<"enums">, type: string, direction: "out" | "in") {
  const tp = ((LINK_TYPES as readonly string[]).includes(type) ? type : "RELATES") as LinkType;
  return direction === "out" ? te(`linkOut.${tp}`) : te(`linkIn.${tp}`);
}

type SearchHit = { id: string; key: string; title: string; type: string; status: string; project: { name: string } };

function LinkAdder({ issueId, onDone }: { issueId: string; onDone: () => void }) {
  const [choice, setChoice] = useState(LINK_CHOICES[2]!.value);
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [target, setTarget] = useState<SearchHit | null>(null);
  const { pending, run } = useRun();
  const t = useT("issue");
  const tc = useT("common");
  const te = useT("enums");

  useEffect(() => {
    if (target) return;
    let alive = true;
    const t = setTimeout(async () => {
      const r = await searchIssuesForLink(q, issueId);
      if (alive && r.ok) setHits(r.data ?? []);
    }, 200);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [q, issueId, target]);

  const submit = () => {
    if (!target) return;
    const c = LINK_CHOICES.find((x) => x.value === choice)!;
    run(() => addLink(issueId, target.id, c.type, c.direction), onDone);
  };

  return (
    <div className="rounded-[3px] border border-line bg-surface-sunken p-3">
      <div className="flex flex-wrap items-start gap-2">
        <Select value={choice} onChange={(e) => setChoice(e.target.value)} className="h-9 w-40 bg-surface-raised">
          {LINK_CHOICES.map((c) => (
            <option key={c.value} value={c.value}>
              {linkLabel(te, c.type, c.direction)}
            </option>
          ))}
        </Select>
        <div className="relative min-w-[220px] flex-1">
          {target ? (
            <div className="flex h-9 items-center gap-2 rounded-[3px] border-2 border-brand-500 bg-surface-raised px-2 text-sm">
              <IssueTypeIcon type={target.type} />
              <span className="font-medium text-ink-muted">{target.key}</span>
              <span className="min-w-0 flex-1 truncate">{target.title}</span>
              <button type="button" onClick={() => setTarget(null)} className="text-ink-subtle hover:text-ink" aria-label={tc("clear")}>
                <X className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <>
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("linkSearchPlaceholder")}
                className="h-9 w-full rounded-[3px] border-2 border-line bg-input px-2 text-sm text-ink placeholder:text-ink-faint focus:border-brand-500 focus:outline-none"
              />
              {hits.length > 0 && (
                <div className="absolute left-0 right-0 z-30 mt-1 max-h-64 overflow-y-auto rounded-[3px] border border-line bg-surface-overlay py-1 shadow-overlay">
                  {hits.map((h) => (
                    <button
                      key={h.id}
                      type="button"
                      onClick={() => setTarget(h)}
                      className="flex w-full items-center gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-hover"
                    >
                      <IssueTypeIcon type={h.type} />
                      <span className="shrink-0 font-medium text-ink-muted">{h.key}</span>
                      <span className="min-w-0 flex-1 truncate">{h.title}</span>
                      <span className="shrink-0 text-xs text-ink-subtle">{h.project.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
      <div className="mt-3 flex justify-end gap-2">
        <Button variant="subtle" onClick={onDone}>
          {tc("cancel")}
        </Button>
        <Button variant="primary" onClick={submit} loading={pending} disabled={!target}>
          {t("linkAction")}
        </Button>
      </div>
    </div>
  );
}

export function LinkedIssues({ issue, adding, setAdding }: { issue: Issue; adding: boolean; setAdding: (v: boolean) => void }) {
  const { run } = useRun();
  const t = useT("issue");
  const te = useT("enums");
  if (!issue.links.length && !adding) return null;

  const groups = new Map<string, Issue["links"]>();
  for (const l of issue.links) {
    const label = linkLabel(te, l.type, l.direction === "out" ? "out" : "in");
    groups.set(label, [...(groups.get(label) ?? []), l]);
  }

  return (
    <section>
      <SectionTitle
        actions={
          <Button size="icon" variant="subtle" onClick={() => setAdding(true)} title={t("addLink")} className="h-7 w-7">
            <Plus className="h-4 w-4" />
          </Button>
        }
      >
        {t("linkedIssues")}
      </SectionTitle>
      <div className="space-y-3">
        {Array.from(groups.entries()).map(([label, links]) => (
          <div key={label}>
            <div className="mb-1 text-xs font-semibold text-ink-subtle">{label}</div>
            <div className="divide-y divide-line overflow-hidden rounded-[3px] border border-line">
              {links.map((l) => (
                <div key={l.id} className="group flex items-center gap-2 px-2.5 py-1.5 hover:bg-surface-sunken">
                  <IssueTypeIcon type={l.issue.type} />
                  <IssueRefLink issueKey={l.issue.key} className={cn("shrink-0 text-sm font-medium text-brand-600", l.issue.status === "DONE" && "line-through")}>
                    {l.issue.key}
                  </IssueRefLink>
                  <IssueRefLink issueKey={l.issue.key} className="min-w-0 flex-1 truncate text-sm text-ink">
                    {l.issue.title}
                  </IssueRefLink>
                  <PriorityIcon priority={l.issue.priority} />
                  <StatusLozenge status={l.issue.status} />
                  <button
                    type="button"
                    onClick={() => run(() => removeLink(l.id))}
                    className="rounded p-1 text-ink-subtle opacity-0 hover:bg-surface-hover hover:text-danger-bold group-hover:opacity-100"
                    title={t("removeLink")}
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
        {adding && <LinkAdder issueId={issue.id} onDone={() => setAdding(false)} />}
      </div>
    </section>
  );
}

// ---------- Fayllar ----------

export function useUploader(issueId: string) {
  const router = useRouter();
  const t = useT("issue");
  const [uploading, setUploading] = useState(0);
  const upload = async (files: FileList | File[]) => {
    const list = Array.from(files);
    if (!list.length) return;
    setUploading((n) => n + list.length);
    for (const file of list) {
      try {
        if (file.size > 10 * 1024 * 1024) throw new Error(`${file.name}: ${t("errFileTooLarge", { max: 10 })}`);
        const fd = new FormData();
        fd.set("issueId", issueId);
        fd.set("file", file);
        const res = await fetch("/api/attachments", { method: "POST", body: fd });
        if (!res.ok) {
          const j = (await res.json().catch(() => null)) as { error?: string } | null;
          throw new Error(j?.error ? `${file.name}: ${j.error}` : `${file.name}: ${t("errUploadFailed")}`);
        }
      } catch (e) {
        toast({ message: e instanceof Error ? e.message : t("errUploadFailed"), tone: "error" });
      } finally {
        setUploading((n) => n - 1);
      }
    }
    await refreshAfterUpload();
    router.refresh();
  };
  return { upload, uploading };
}

export function Attachments({
  issue,
  me,
  uploader,
  onPick,
}: {
  issue: Issue;
  me: IssueDetailData["me"];
  uploader: ReturnType<typeof useUploader>;
  onPick: () => void;
}) {
  const { run } = useRun();
  const [drag, setDrag] = useState(false);
  const t = useT("issue");
  const tc = useT("common");
  const f = useFormat();
  if (!issue.attachments.length && !uploader.uploading) return null;

  return (
    <section
      onDragOver={(e) => {
        e.preventDefault();
        setDrag(true);
      }}
      onDragLeave={() => setDrag(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDrag(false);
        if (e.dataTransfer.files.length) uploader.upload(e.dataTransfer.files);
      }}
    >
      <SectionTitle
        actions={
          <Button size="icon" variant="subtle" onClick={onPick} title={t("attachFile")} className="h-7 w-7">
            <Plus className="h-4 w-4" />
          </Button>
        }
      >
        {t("attachments")} <span className="ml-1 font-normal text-ink-subtle">({issue.attachments.length})</span>
      </SectionTitle>
      <div className={cn("grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-2 rounded-[3px]", drag && "outline-dashed outline-2 outline-brand-500")}>
        {issue.attachments.map((a) => {
          const isImage = a.mimeType.startsWith("image/") && a.mimeType !== "image/svg+xml";
          const url = `/api/attachments/${a.id}`;
          return (
            <div key={a.id} className="group relative overflow-hidden rounded-[3px] border border-line bg-surface-raised">
              <a href={url} target="_blank" rel="noopener noreferrer" className="block">
                <div className="flex h-24 items-center justify-center bg-surface-sunken">
                  {isImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={url} alt={a.filename} className="h-full w-full object-cover" />
                  ) : (
                    <FileText className="h-9 w-9 text-ink-faint" />
                  )}
                </div>
                <div className="px-2 py-1.5">
                  <div className="truncate text-xs font-medium text-ink" title={a.filename}>
                    {a.filename}
                  </div>
                  <div className="text-[11px] text-ink-subtle" suppressHydrationWarning>
                    {fmtBytes(a.size)} · {f.relative(a.createdAt)}
                  </div>
                </div>
              </a>
              {(a.uploaderId === me.id || me.canManage) && (
                <button
                  type="button"
                  onClick={() => run(() => deleteAttachment(a.id))}
                  className="absolute right-1 top-1 hidden rounded-[3px] bg-surface-raised/90 p-1 text-ink-muted shadow-card hover:text-danger-bold group-hover:block"
                  title={tc("delete")}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          );
        })}
        {uploader.uploading > 0 && (
          <div className="flex h-[148px] flex-col items-center justify-center gap-2 rounded-[3px] border border-dashed border-line text-xs text-ink-subtle">
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-brand-600 border-t-transparent" />
            {t("uploading")}
          </div>
        )}
      </div>
    </section>
  );
}

// ---------- Sürətli əməliyyat düymələri ----------

export function QuickActions({
  issue,
  onAddChild,
  onAddLink,
  onAttach,
}: {
  issue: Issue;
  onAddChild: () => void;
  onAddLink: () => void;
  onAttach: () => void;
}) {
  const t = useT("issue");
  return (
    <div className="flex flex-wrap gap-2">
      {issue.type !== "SUBTASK" && (
        <Button size="sm" onClick={onAddChild}>
          <Plus className="h-4 w-4" />
          {issue.type === "EPIC" ? t("addChildIssue") : t("addSubtask")}
        </Button>
      )}
      <Button size="sm" onClick={onAddLink}>
        <Link2 className="h-4 w-4" /> {t("addLink")}
      </Button>
      <Button size="sm" onClick={onAttach}>
        <Paperclip className="h-4 w-4" /> {t("attachFile")}
      </Button>
    </div>
  );
}

