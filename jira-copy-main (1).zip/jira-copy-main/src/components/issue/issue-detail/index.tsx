"use client";

import { useRef, useState } from "react";
import type { IssueDetailData } from "@/lib/issue-detail-query";
import { cn } from "@/lib/utils";
import { ActivitySection } from "./activity";
import { IssueHeader } from "./header";
import { DetailProvider } from "./hooks";
import { Attachments, ChildIssues, DescriptionEditor, LinkedIssues, QuickActions, TitleEditor, useUploader } from "./main-sections";
import { IssueSidebar } from "./sidebar";

/** Tapşırıq detalları — həm modalda (?selectedIssue=KEY), həm /browse/KEY səhifəsində istifadə olunur */
export function IssueDetail({ data, variant }: { data: IssueDetailData; variant: "modal" | "page" }) {
  const { issue, me } = data;
  const [addingChild, setAddingChild] = useState(false);
  const [addingLink, setAddingLink] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const uploader = useUploader(issue.id);
  const pickFile = () => fileRef.current?.click();

  return (
    <DetailProvider value={{ issueId: issue.id, variant }}>
      <div className={cn(variant === "modal" && "px-6 pb-8 pt-4")}>
        <IssueHeader data={data} />
        <div className="mt-4 grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(300px,360px)]">
          <div className="min-w-0 space-y-6">
            <div className="space-y-3">
              <TitleEditor title={issue.title} />
              <QuickActions issue={issue} onAddChild={() => setAddingChild(true)} onAddLink={() => setAddingLink(true)} onAttach={pickFile} />
            </div>
            <DescriptionEditor description={issue.description} />
            <ChildIssues issue={issue} adding={addingChild} setAdding={setAddingChild} />
            <LinkedIssues issue={issue} adding={addingLink} setAdding={setAddingLink} />
            <Attachments issue={issue} me={me} uploader={uploader} onPick={pickFile} />
            <ActivitySection data={data} />
          </div>
          <aside className="min-w-0 lg:sticky lg:top-4 lg:self-start">
            <IssueSidebar data={data} />
          </aside>
        </div>
        <input
          ref={fileRef}
          type="file"
          multiple
          hidden
          onChange={(e) => {
            if (e.target.files?.length) uploader.upload(e.target.files);
            e.target.value = "";
          }}
        />
      </div>
    </DetailProvider>
  );
}
