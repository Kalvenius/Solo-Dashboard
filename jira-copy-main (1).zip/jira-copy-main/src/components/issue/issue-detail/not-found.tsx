"use client";

import { SearchX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useOpenIssue } from "../use-open-issue";
import { useT } from "@/i18n/client";

export function NotFoundBody({ issueKey }: { issueKey: string }) {
  const { close } = useOpenIssue();
  const t = useT("issue");
  const tc = useT("common");
  return (
    <div className="flex flex-col items-center px-6 py-8 text-center">
      <SearchX className="h-10 w-10 text-ink-faint" />
      <h2 className="mt-3 text-base font-semibold text-ink">{t("notFoundTitle")}</h2>
      <p className="mt-1 text-sm text-ink-subtle">{t("notFoundText", { key: issueKey })}</p>
      <Button variant="primary" className="mt-4" onClick={close}>
        {tc("close")}
      </Button>
    </div>
  );
}
