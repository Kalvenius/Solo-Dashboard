"use client";

import { useState, type ReactNode } from "react";
import { ChevronDown, Clock, Plus, X } from "lucide-react";
import { PRIORITIES, PRIORITY_META, STATUSES, STATUS_META, type Status } from "@/lib/constants";
import type { IssueDetailData } from "@/lib/issue-detail-query";
import { logWork } from "@/lib/actions/issues";
import { cn, parseDuration, parseLabels, toDateInput } from "@/lib/utils";
import { useFormat, useT } from "@/i18n/client";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { StatusLozenge } from "@/components/ui/lozenge";
import { Modal } from "@/components/ui/modal";
import { Picker } from "@/components/ui/picker";
import { Popover } from "@/components/ui/popover";
import { PriorityIcon } from "../icons";
import { IssueRefLink, useDetail, useField, useRun } from "./hooks";
import { IssueTypeIcon } from "../icons";

type Props = { data: IssueDetailData };

const statusBtn: Record<string, string> = {
  todo: "bg-tint-1 text-ink hover:bg-tint-2",
  progress: "bg-brand-600 text-on-brand hover:bg-brand-700",
  done: "bg-success-bold text-on-brand hover:brightness-110",
};

export function StatusButton({ status }: { status: string }) {
  const f = useField(status, (v) => ({ status: v }));
  const te = useT("enums");
  const s = (f.value in STATUS_META ? f.value : "TODO") as Status;
  const meta = STATUS_META[s];
  return (
    <Popover
      className="w-56"
      trigger={({ toggle }) => (
        <button
          type="button"
          onClick={toggle}
          className={cn("inline-flex h-8 items-center gap-1.5 rounded-[3px] px-3 text-sm font-medium transition-colors", statusBtn[meta.category])}
        >
          {te(`status.${s}`)}
          <ChevronDown className="h-4 w-4" />
        </button>
      )}
    >
      {(close) =>
        STATUSES.filter((s) => s !== f.value).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => {
              f.save(s);
              close();
            }}
            className="flex w-full items-center px-3 py-2 text-left hover:bg-surface-hover"
          >
            <StatusLozenge status={s} />
          </button>
        ))
      }
    </Popover>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-[120px_minmax(0,1fr)] items-start gap-2 py-1.5">
      <div className="pt-1.5 text-sm font-medium text-ink-subtle">{label}</div>
      <div className="min-w-0">{children}</div>
    </div>
  );
}

const valueBox = "inline-flex min-h-8 max-w-full items-center gap-2 rounded-[3px] px-1.5 py-1 text-sm text-ink hover:bg-tint-1";

function UserField({ value, onChange, members, emptyLabel }: { value: string | null; onChange: (v: string | null) => void; members: IssueDetailData["options"]["members"]; emptyLabel?: string }) {
  const options = members.map((m) => ({ value: m.id, label: m.name, icon: <Avatar user={m} size="xs" /> }));
  const selected = members.find((m) => m.id === value);
  return (
    <Picker
      options={options}
      value={value}
      onChange={onChange}
      searchable
      emptyLabel={emptyLabel}
      renderTrigger={() => (
        <span className={valueBox}>
          <Avatar user={selected ?? null} size="sm" />
          <span className={cn("truncate", !selected && "text-ink-subtle")}>{selected?.name ?? emptyLabel ?? "—"}</span>
        </span>
      )}
    />
  );
}

function InlineText({
  value,
  display,
  onSave,
  placeholder,
  type = "text",
  className,
}: {
  value: string;
  display: ReactNode;
  onSave: (v: string) => void;
  placeholder?: string;
  type?: "text" | "number" | "date";
  className?: string;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  if (!editing) {
    return (
      <button
        type="button"
        onClick={() => {
          setDraft(value);
          setEditing(true);
        }}
        className={cn(valueBox, "w-full text-left", className)}
      >
        {display}
      </button>
    );
  }
  const commit = () => {
    setEditing(false);
    if (draft !== value) onSave(draft);
  };
  return (
    <Input
      autoFocus
      type={type}
      value={draft}
      placeholder={placeholder}
      min={type === "number" ? 0 : undefined}
      onChange={(e) => {
        setDraft(e.target.value);
        if (type === "date") {
          // tarix seçəndə dərhal saxla
          setEditing(false);
          if (e.target.value !== value) onSave(e.target.value);
        }
      }}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") commit();
        if (e.key === "Escape") {
          e.preventDefault();
          setEditing(false);
        }
      }}
      className="h-8"
    />
  );
}

function DateField({ value, field, danger }: { value: Date | null; field: "startDate" | "dueDate"; danger?: boolean }) {
  const f = useField<string>(toDateInput(value), (v) => ({ [field]: v || null }));
  const fmt = useFormat();
  const tc = useT("common");
  return (
    <div className="flex items-center gap-1">
      <InlineText
        type="date"
        value={f.value}
        onSave={f.save}
        display={f.value ? <span className={cn(danger && "font-medium text-danger-bold")}>{fmt.date(f.value + "T12:00:00")}</span> : <span className="text-ink-subtle">{tc("none")}</span>}
      />
      {f.value && (
        <button type="button" onClick={() => f.save("")} className="rounded p-1 text-ink-subtle hover:bg-surface-hover" title={tc("clear")}>
          <X className="h-3.5 w-3.5" />
        </button>
      )}
    </div>
  );
}

function LabelsField({ labels, suggestions }: { labels: string; suggestions: string[] }) {
  const f = useField<string[]>(parseLabels(labels), (v) => ({ labels: v }));
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState("");
  const t = useT("issue");
  const tc = useT("common");
  const listId = "label-suggestions";
  const add = () => {
    const l = draft.trim().replace(/,/g, "");
    setDraft("");
    setAdding(false);
    if (l && !f.value.includes(l)) f.save([...f.value, l]);
  };
  return (
    <div className="flex flex-wrap items-center gap-1 py-1">
      {f.value.map((l) => (
        <span key={l} className="inline-flex items-center gap-1 rounded-[3px] border border-line bg-surface-sunken px-1.5 py-0.5 text-xs text-ink">
          {l}
          <button type="button" onClick={() => f.save(f.value.filter((x) => x !== l))} className="text-ink-subtle hover:text-ink" aria-label={tc("remove")}>
            <X className="h-3 w-3" />
          </button>
        </span>
      ))}
      {adding ? (
        <>
          <input
            autoFocus
            list={listId}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={add}
            onKeyDown={(e) => {
              if (e.key === "Enter") add();
              if (e.key === "Escape") {
                e.preventDefault();
                setDraft("");
                setAdding(false);
              }
            }}
            placeholder={t("labelPlaceholder")}
            className="h-7 w-28 rounded-[3px] border-2 border-brand-500 bg-input px-1.5 text-xs text-ink focus:outline-none"
          />
          <datalist id={listId}>
            {suggestions.filter((s) => !f.value.includes(s)).map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </>
      ) : (
        <button type="button" onClick={() => setAdding(true)} className={cn(valueBox, "text-ink-subtle")}>
          {f.value.length ? <Plus className="h-3.5 w-3.5" /> : tc("none")}
        </button>
      )}
    </div>
  );
}

export function LogWorkModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { issueId } = useDetail();
  const [duration, setDuration] = useState("");
  const [date, setDate] = useState(toDateInput(new Date()));
  const [note, setNote] = useState("");
  const { pending, run } = useRun();
  const t = useT("issue");
  const tc = useT("common");
  const fmt = useFormat();
  const minutes = parseDuration(duration);
  const submit = () =>
    run(
      () => logWork(issueId, { duration, date, note }),
      () => {
        setDuration("");
        setNote("");
        onClose();
      },
    );
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={t("logTime")}
      width="sm"
      footer={
        <>
          <Button variant="subtle" onClick={onClose}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" onClick={submit} loading={pending} disabled={!minutes}>
            {tc("save")}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label={t("timeSpent")} required hint={minutes ? `= ${fmt.minutes(minutes)}` : t("durationHint")}>
          <Input autoFocus value={duration} onChange={(e) => setDuration(e.target.value)} placeholder={t("durationPlaceholder")} onKeyDown={(e) => e.key === "Enter" && minutes && submit()} />
        </Field>
        <Field label={t("date")}>
          <Input type="date" value={date} max={toDateInput(new Date())} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <Field label={t("note")}>
          <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder={t("notePlaceholder")} className="min-h-[60px]" />
        </Field>
      </div>
    </Modal>
  );
}

function TimeTracking({ logged, estimate }: { logged: number; estimate: number | null }) {
  const [open, setOpen] = useState(false);
  const t = useT("issue");
  const fmt = useFormat();
  const total = Math.max(logged, estimate ?? 0);
  const over = estimate != null && logged > estimate;
  return (
    <div>
      <button type="button" onClick={() => setOpen(true)} className="w-full rounded-[3px] px-1.5 py-1 text-left hover:bg-tint-1">
        <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-neutral">
          {total > 0 && <div className={over ? "bg-danger-bold" : "bg-brand-600"} style={{ width: `${(logged / total) * 100}%` }} />}
        </div>
        <div className="mt-1 flex flex-wrap justify-between gap-x-2 text-xs text-ink-subtle">
          <span className="whitespace-nowrap">{t("timeLogged", { time: fmt.minutes(logged) })}</span>
          <span className="whitespace-nowrap">
            {estimate != null
              ? over
                ? t("timeOver", { time: fmt.minutes(logged - estimate) })
                : t("timeRemaining", { time: fmt.minutes(estimate - logged) })
              : t("noEstimate")}
          </span>
        </div>
      </button>
      <LogWorkModal open={open} onClose={() => setOpen(false)} />
    </div>
  );
}

export function IssueSidebar({ data }: Props) {
  const { issue, options, me } = data;
  const assignee = useField<string | null>(issue.assigneeId, (v) => ({ assigneeId: v }));
  const reporter = useField<string | null>(issue.reporterId, (v) => ({ reporterId: v ?? undefined }));
  const priority = useField<string | null>(issue.priority, (v) => ({ priority: v ?? "MEDIUM" }));
  const sprint = useField<string | null>(issue.sprintId, (v) => ({ sprintId: v }));
  const parent = useField<string | null>(issue.parentId, (v) => ({ parentId: v }));
  const points = useField<string>(issue.storyPoints?.toString() ?? "", (v) => ({ storyPoints: v === "" ? null : Number(v) }));
  const estimate = useField<number | null>(issue.estimateMinutes, (v) => ({ estimateMinutes: v }));
  const t = useT("issue");
  const tc = useT("common");
  const te = useT("enums");
  const fmt = useFormat();

  const logged = issue.worklogs.reduce((s, w) => s + w.minutes, 0);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const overdue = !!issue.dueDate && issue.status !== "DONE" && new Date(issue.dueDate) < today;
  const isEpic = issue.type === "EPIC";
  const isSub = issue.type === "SUBTASK";

  // tamamlanmış sprintdədirsə də seçimdə görünsün
  const sprintOptions = options.sprints.map((s) => ({ value: s.id, label: s.name, hint: s.state === "ACTIVE" ? `· ${te("sprintState.ACTIVE")}` : undefined }));
  if (issue.sprint && !sprintOptions.some((s) => s.value === issue.sprint!.id))
    sprintOptions.unshift({ value: issue.sprint.id, label: issue.sprint.name, hint: `· ${te("sprintState.COMPLETED")}` });
  const selectedSprint = sprintOptions.find((s) => s.value === sprint.value);
  const selectedEpic = options.epics.find((e) => e.id === parent.value);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <StatusButton status={issue.status} />
      </div>

      <section className="rounded-[3px] border border-line">
        <header className="border-b border-line px-3 py-2.5 text-sm font-semibold text-ink">{t("details")}</header>
        <div className="px-3 py-1.5">
          <Row label={tc("assignee")}>
            <UserField value={assignee.value} onChange={assignee.save} members={options.members} emptyLabel={tc("unassigned")} />
            {assignee.value !== me.id && (
              <button type="button" onClick={() => assignee.save(me.id)} className="block px-1.5 text-xs font-medium text-brand-600 hover:underline">
                {tc("assignToMe")}
              </button>
            )}
          </Row>
          <Row label={tc("reporter")}>
            <UserField value={reporter.value} onChange={(v) => v && reporter.save(v)} members={options.members} />
          </Row>
          <Row label={tc("priority")}>
            <Picker
              options={PRIORITIES.map((p) => ({ value: p, label: te(`priority.${p}`), icon: <PriorityIcon priority={p} /> }))}
              value={priority.value}
              onChange={(v) => v && priority.save(v)}
              renderTrigger={() => (
                <span className={valueBox}>
                  <PriorityIcon priority={priority.value ?? "MEDIUM"} withLabel />
                </span>
              )}
            />
          </Row>
          <Row label={tc("labels")}>
            <LabelsField labels={issue.labels} suggestions={options.labels} />
          </Row>
          {!isEpic && !isSub && data.issue.project.type === "SCRUM" && (
            <Row label={tc("sprint")}>
              <Picker
                options={sprintOptions}
                value={sprint.value}
                onChange={sprint.save}
                emptyLabel={t("noneBacklog")}
                renderTrigger={() => <span className={cn(valueBox, !selectedSprint && "text-ink-subtle")}>{selectedSprint?.label ?? tc("none")}</span>}
              />
            </Row>
          )}
          {!isEpic && !isSub && (
            <Row label={tc("epic")}>
              <Picker
                options={options.epics.map((e) => ({ value: e.id, label: `${e.key} ${e.title}`, icon: <IssueTypeIcon type="EPIC" /> }))}
                value={parent.value}
                onChange={parent.save}
                searchable
                emptyLabel={tc("none")}
                renderTrigger={() =>
                  selectedEpic ? (
                    <span className={valueBox}>
                      <span className="inline-block max-w-[190px] truncate rounded-[3px] bg-discovery-subtle px-1.5 text-xs font-semibold uppercase leading-5 text-discovery" title={`${selectedEpic.key} ${selectedEpic.title}`}>{selectedEpic.title}</span>
                    </span>
                  ) : (
                    <span className={cn(valueBox, "text-ink-subtle")}>{tc("none")}</span>
                  )
                }
              />
            </Row>
          )}
          {isSub && issue.parent && (
            <Row label={te("field.parent")}>
              <span className={valueBox}>
                <IssueTypeIcon type={issue.parent.type} />
                <IssueRefLink issueKey={issue.parent.key} className="truncate text-brand-600">
                  {issue.parent.key} {issue.parent.title}
                </IssueRefLink>
              </span>
            </Row>
          )}
          {!isSub && (
            <Row label={tc("storyPoints")}>
              <InlineText
                type="number"
                value={points.value}
                onSave={points.save}
                display={points.value !== "" ? <span className="font-medium">{points.value}</span> : <span className="text-ink-subtle">{tc("none")}</span>}
              />
            </Row>
          )}
          <Row label={tc("startDate")}>
            <DateField value={issue.startDate} field="startDate" />
          </Row>
          <Row label={tc("dueDate")}>
            <DateField value={issue.dueDate} field="dueDate" danger={overdue} />
          </Row>
          <Row label={te("field.estimate")}>
            <InlineText
              value={estimate.value ? fmt.minutes(estimate.value) : ""}
              placeholder={t("estimatePlaceholder")}
              onSave={(v) => {
                if (!v.trim()) return estimate.save(null);
                const m = parseDuration(v);
                if (m) estimate.save(m);
              }}
              display={estimate.value ? fmt.minutes(estimate.value) : <span className="text-ink-subtle">{tc("none")}</span>}
            />
          </Row>
          <Row label={t("timeTracking")}>
            <TimeTracking logged={logged} estimate={estimate.value} />
          </Row>
        </div>
      </section>

      <div className="space-y-0.5 px-1 text-xs text-ink-subtle">
        <div className="flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5" /> {t("createdAt", { date: fmt.dateTime(issue.createdAt) })}
        </div>
        <div className="pl-5" suppressHydrationWarning>
          {t("updatedAt", { date: fmt.relative(issue.updatedAt) })}
        </div>
        {issue.resolvedAt && <div className="pl-5">{t("resolvedAt", { date: fmt.dateTime(issue.resolvedAt) })}</div>}
      </div>
    </div>
  );
}
