"use client";

import Link from "next/link";
import { Fragment, createContext, useCallback, useContext, useEffect, useState, useTransition, type ReactNode } from "react";
import type { ActionResult } from "@/lib/action-result";
import { updateIssue, type IssuePatchInput } from "@/lib/actions/issues";
import { cn } from "@/lib/utils";
import { toast } from "../toast";
import { useOpenIssue } from "../use-open-issue";

/** Server action-u transition içində işlədir; xəta olsa toast göstərir */
export function useRun() {
  const [pending, start] = useTransition();
  const run = useCallback(<T,>(fn: () => Promise<ActionResult<T>>, onOk?: (d: T | undefined) => void, onErr?: () => void) => {
    start(async () => {
      const r = await fn();
      if (!r.ok) {
        toast({ message: r.error, tone: "error" });
        onErr?.();
      } else onOk?.(r.data);
    });
  }, []);
  return { pending, run };
}

/** Prop dəyişəndə yenilənən lokal (optimistik) state */
export function useSynced<T>(value: T) {
  const [v, setV] = useState(value);
  // massiv/obyekt hər render-də yeni yaradılsa da sonsuz dövrə düşməsin deyə dəyərə görə müqayisə
  const dep = value !== null && typeof value === "object" ? JSON.stringify(value) : value;
  useEffect(() => setV(value), [dep]); // eslint-disable-line react-hooks/exhaustive-deps
  return [v, setV] as const;
}

type Ctx = { issueId: string; variant: "modal" | "page" };
const DetailCtx = createContext<Ctx | null>(null);

export function DetailProvider({ value, children }: { value: Ctx; children: ReactNode }) {
  return <DetailCtx.Provider value={value}>{children}</DetailCtx.Provider>;
}

export function useDetail() {
  const c = useContext(DetailCtx);
  if (!c) throw new Error("DetailProvider yoxdur");
  return c;
}

/** Bir sahəni yeniləyən hook: optimistik dəyər + server action */
export function useField<T>(serverValue: T, toPatch: (v: T) => IssuePatchInput) {
  const { issueId } = useDetail();
  const [value, setValue] = useSynced(serverValue);
  const { pending, run } = useRun();
  const save = (v: T) => {
    const prev = value;
    setValue(v);
    run(() => updateIssue(issueId, toPatch(v)), undefined, () => setValue(prev));
  };
  return { value, save, pending };
}

/** Başqa tapşırığa keçid: modalda modalı dəyişir, tam səhifədə /browse-a keçir */
export function IssueRefLink({ issueKey, className, children }: { issueKey: string; className?: string; children: ReactNode }) {
  const { variant } = useDetail();
  const { open } = useOpenIssue();
  if (variant === "page") {
    return (
      <Link href={`/browse/${issueKey}`} className={cn("hover:underline", className)}>
        {children}
      </Link>
    );
  }
  return (
    <button type="button" onClick={() => open(issueKey)} className={cn("text-left hover:underline", className)}>
      {children}
    </button>
  );
}

export function SectionTitle({ children, actions }: { children: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center justify-between gap-2">
      <h3 className="text-sm font-semibold text-ink">{children}</h3>
      {actions && <div className="flex items-center gap-1">{actions}</div>}
    </div>
  );
}

/**
 * Tərcümə olunmuş cümlənin içinə React elementləri qoyur (məs. qalın vaxt):
 *   rich((p) => t("hLogged", p), { time: <b>2h</b> })
 * Parametrlər əvvəlcə işarələrlə əvəz olunur, sonra həmin yerlərə elementlər qoyulur.
 */
export function rich(msg: (params: Record<string, string>) => string, nodes: Record<string, ReactNode>): ReactNode {
  const marks = Object.fromEntries(Object.keys(nodes).map((k) => [k, `\u0001${k}\u0001`]));
  const parts = msg(marks).split(/\u0001(\w+)\u0001/);
  return parts.map((p, i) => (i % 2 === 1 ? <Fragment key={i}>{nodes[p]}</Fragment> : p));
}

export function fmtBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}
