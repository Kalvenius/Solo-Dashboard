"use client";

import { useEffect, useState, useTransition } from "react";
import { PRIORITIES, type IssueType } from "@/lib/constants";
import { useT } from "@/i18n/client";
import { createIssue, getCreateIssueOptions } from "@/lib/actions/issues";
import type { NavProject } from "@/components/layout/top-nav";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input, Select, Textarea } from "@/components/ui/input";
import { Modal } from "@/components/ui/modal";
import { Picker } from "@/components/ui/picker";
import { IssueTypeIcon, PriorityIcon } from "./icons";
import { toast } from "./toast";

type Options = {
  members: { id: string; name: string; avatarColor: string }[];
  sprints: { id: string; name: string; state: string }[];
  epics: { id: string; key: string; title: string }[];
  labels: string[];
};

const EMPTY: Options = { members: [], sprints: [], epics: [], labels: [] };

export type CreateIssueModalProps = {
  open: boolean;
  onClose: () => void;
  projects: NavProject[];
  defaultProjectId?: string;
  defaultType?: string;
  defaultParentId?: string;
  defaultSprintId?: string;
  /** yaradıldıqdan sonra çağırılır */
  onCreated?: (issue: { id: string; key: string }) => void;
};

export function CreateIssueModal({ open, onClose, projects, defaultProjectId, defaultType, defaultParentId, defaultSprintId, onCreated }: CreateIssueModalProps) {
  const initialProject = defaultProjectId && projects.some((p) => p.id === defaultProjectId) ? defaultProjectId : (projects[0]?.id ?? "");
  const [projectId, setProjectId] = useState(initialProject);
  const [type, setType] = useState(defaultType ?? (defaultParentId ? "SUBTASK" : "TASK"));
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [assigneeId, setAssigneeId] = useState<string | null>(null);
  const [priority, setPriority] = useState("MEDIUM");
  const [labels, setLabels] = useState("");
  const [sprintId, setSprintId] = useState<string>(defaultSprintId ?? "");
  const [parentId, setParentId] = useState<string>(defaultParentId ?? "");
  const [points, setPoints] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [another, setAnother] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [options, setOptions] = useState<Options>(EMPTY);
  const [loadingOpts, setLoadingOpts] = useState(false);
  const [pending, start] = useTransition();
  const t = useT("createIssue");
  const tc = useT("common");
  const te = useT("enums");

  // modal açılanda standart dəyərləri bərpa et
  useEffect(() => {
    if (!open) return;
    setProjectId(initialProject);
    setType(defaultType ?? (defaultParentId ? "SUBTASK" : "TASK"));
    setSprintId(defaultSprintId ?? "");
    setParentId(defaultParentId ?? "");
    setError(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (!open || !projectId) return;
    let alive = true;
    setLoadingOpts(true);
    getCreateIssueOptions(projectId).then((r) => {
      if (!alive) return;
      setLoadingOpts(false);
      if (r.ok && r.data) {
        setOptions(r.data);
        setAssigneeId((a) => (a && r.data!.members.some((m) => m.id === a) ? a : null));
        setSprintId((s) => (s && r.data!.sprints.some((x) => x.id === s) ? s : ""));
        if (!defaultParentId) setParentId((p) => (p && r.data!.epics.some((e) => e.id === p) ? p : ""));
      } else if (!r.ok) setError(r.error);
    });
    return () => {
      alive = false;
    };
  }, [open, projectId, defaultParentId]);

  const project = projects.find((p) => p.id === projectId);
  const isScrum = project?.type === "SCRUM";
  const typeChoices: IssueType[] = defaultParentId ? ["SUBTASK"] : ["STORY", "TASK", "BUG", "EPIC"];

  const reset = () => {
    setTitle("");
    setDescription("");
    setPoints("");
    setDueDate("");
    setLabels("");
  };

  const submit = () => {
    setError(null);
    if (!title.trim()) return setError(t("summaryRequired"));
    if (!projectId) return setError(t("chooseProject"));
    start(async () => {
      const r = await createIssue({
        projectId,
        type,
        title,
        description,
        assigneeId,
        priority,
        labels,
        sprintId: type === "EPIC" || type === "SUBTASK" ? null : sprintId || null,
        parentId: type === "EPIC" ? null : parentId || null,
        storyPoints: points === "" ? null : Number(points),
        dueDate: dueDate || null,
      });
      if (!r.ok) return setError(r.error);
      const created = r.data!;
      toast({ message: t("created", { key: created.key }), tone: "success", href: `/browse/${created.key}`, actionLabel: tc("view") });
      onCreated?.(created);
      reset();
      if (!another) onClose();
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={t("title")}
      width="md"
      footer={
        <>
          <label className="mr-auto flex cursor-pointer items-center gap-2 text-sm text-ink-muted">
            <input type="checkbox" checked={another} onChange={(e) => setAnother(e.target.checked)} className="h-4 w-4 accent-brand-600" />
            {t("createAnother")}
          </label>
          <Button variant="subtle" onClick={onClose}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" onClick={submit} loading={pending}>
            {tc("create")}
          </Button>
        </>
      }
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        className="max-h-[62vh] space-y-4 overflow-y-auto pr-1"
      >
        <FormError message={error} />
        <div className="grid grid-cols-2 gap-3">
          <Field label={tc("project")} required>
            <Select value={projectId} onChange={(e) => setProjectId(e.target.value)} disabled={!!defaultParentId}>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.key})
                </option>
              ))}
            </Select>
          </Field>
          <Field label={tc("type")} required>
            <Picker
              options={typeChoices.map((x) => ({ value: x, label: te(`type.${x}`), icon: <IssueTypeIcon type={x} /> }))}
              value={type}
              onChange={(v) => v && setType(v)}
              className="w-full"
              renderTrigger={() => (
                <span className="flex h-9 w-full min-w-[220px] items-center gap-2 rounded-[3px] border-2 border-neutral bg-input px-2 text-sm hover:bg-input-hover">
                  <IssueTypeIcon type={type} />
                  {te(`type.${type as IssueType}`)}
                </span>
              )}
            />
          </Field>
        </div>
        <div className="border-t border-line" />
        <Field label={t("summary")} htmlFor="ci-title" required>
          <Input id="ci-title" autoFocus value={title} onChange={(e) => setTitle(e.target.value)} maxLength={255} />
        </Field>
        <Field label={te("field.description")} htmlFor="ci-desc" hint={t("descriptionHint")}>
          <Textarea id="ci-desc" value={description} onChange={(e) => setDescription(e.target.value)} className="min-h-[110px]" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={tc("assignee")}>
            <Picker
              options={options.members.map((m) => ({ value: m.id, label: m.name, icon: <Avatar user={m} size="xs" /> }))}
              value={assigneeId}
              onChange={setAssigneeId}
              searchable
              emptyLabel={tc("unassigned")}
              renderTrigger={() => {
                const m = options.members.find((x) => x.id === assigneeId);
                return (
                  <span className="flex h-9 w-full min-w-[220px] items-center gap-2 rounded-[3px] border-2 border-neutral bg-input px-2 text-sm hover:bg-input-hover">
                    <Avatar user={m ?? null} size="xs" />
                    <span className={m ? "" : "text-ink-subtle"}>{m?.name ?? (loadingOpts ? tc("loading") : tc("unassigned"))}</span>
                  </span>
                );
              }}
            />
          </Field>
          <Field label={tc("priority")}>
            <Picker
              options={PRIORITIES.map((p) => ({ value: p, label: te(`priority.${p}`), icon: <PriorityIcon priority={p} /> }))}
              value={priority}
              onChange={(v) => v && setPriority(v)}
              renderTrigger={() => (
                <span className="flex h-9 w-full min-w-[220px] items-center gap-2 rounded-[3px] border-2 border-neutral bg-input px-2 text-sm hover:bg-input-hover">
                  <PriorityIcon priority={priority} withLabel />
                </span>
              )}
            />
          </Field>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {type !== "EPIC" && type !== "SUBTASK" && (
            <Field label={tc("epic")}>
              <Select value={parentId} onChange={(e) => setParentId(e.target.value)}>
                <option value="">{tc("none")}</option>
                {options.epics.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.key} — {e.title}
                  </option>
                ))}
              </Select>
            </Field>
          )}
          {isScrum && type !== "EPIC" && type !== "SUBTASK" && (
            <Field label={tc("sprint")}>
              <Select value={sprintId} onChange={(e) => setSprintId(e.target.value)}>
                <option value="">{tc("backlog")}</option>
                {options.sprints.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                    {s.state === "ACTIVE" ? ` ${t("activeSuffix")}` : ""}
                  </option>
                ))}
              </Select>
            </Field>
          )}
          {type !== "SUBTASK" && (
            <Field label={tc("storyPoints")}>
              <Input type="number" min={0} max={999} value={points} onChange={(e) => setPoints(e.target.value)} placeholder={t("pointsPlaceholder")} />
            </Field>
          )}
          <Field label={tc("dueDate")}>
            <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </Field>
        </div>
        <Field label={tc("labels")} hint={t("labelsHint")}>
          <Input value={labels} onChange={(e) => setLabels(e.target.value)} list="ci-labels" placeholder={t("labelsPlaceholder")} />
          <datalist id="ci-labels">
            {options.labels.map((l) => (
              <option key={l} value={l} />
            ))}
          </datalist>
        </Field>
        <button type="submit" hidden />
      </form>
    </Modal>
  );
}
