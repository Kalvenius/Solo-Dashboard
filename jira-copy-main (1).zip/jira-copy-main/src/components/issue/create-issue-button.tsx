"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { NavProject } from "@/components/layout/top-nav";
import { CreateIssueModal } from "./create-issue-modal";
import { Toaster } from "./toast";
import { useT } from "@/i18n/client";

/** Yuxarı paneldəki "Yarat" düyməsi. Qısayol: "c" */
export function CreateIssueButton({ projects }: { projects: NavProject[] }) {
  const [open, setOpen] = useState(false);
  const t = useT("createIssue");
  const tc = useT("common");
  const pathname = usePathname();
  const urlKey = pathname.match(/^\/projects\/([^/]+)/)?.[1]?.toUpperCase() ?? pathname.match(/^\/browse\/([A-Z0-9]+)-\d+/i)?.[1]?.toUpperCase();
  const currentProject = projects.find((p) => p.key === urlKey);

  useEffect(() => {
    if (!projects.length) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "c" || e.metaKey || e.ctrlKey || e.altKey) return;
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable)) return;
      if (document.querySelector('[role="dialog"]')) return;
      e.preventDefault();
      setOpen(true);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [projects.length]);

  return (
    <>
      <Button
        variant="primary"
        onClick={() => setOpen(true)}
        disabled={!projects.length}
        title={projects.length ? t("buttonTitle") : t("noProjects")}
      >
        <Plus className="h-4 w-4" />
        {tc("create")}
      </Button>
      {open && <CreateIssueModal open={open} onClose={() => setOpen(false)} projects={projects} defaultProjectId={currentProject?.id} />}
      <Toaster />
    </>
  );
}
