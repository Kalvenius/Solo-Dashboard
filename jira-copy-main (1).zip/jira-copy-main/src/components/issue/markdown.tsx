import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * Kiçik və təhlükəsiz markdown göstəricisi. HTML heç vaxt birbaşa daxil edilmir (React mətnləri escape edir).
 * Dəstəklənir: abzaslar, sətir keçidləri, **qalın**, *kursiv*, `kod`, "- " və "1." siyahılar, "# " başlıqlar, URL-lər.
 */
export function Markdown({ text, className }: { text: string; className?: string }) {
  return <div className={cn("space-y-2 break-words text-sm leading-relaxed text-ink", className)}>{blocks(text)}</div>;
}

const INLINE_RE = /(`[^`\n]+`)|(\*\*[^*\n]+\*\*)|(\*[^*\s\n][^*\n]*\*)|(https?:\/\/[^\s<]*[^\s<.,;:!?)\]'"])/g;

function inline(text: string, keyBase: string): ReactNode[] {
  const out: ReactNode[] = [];
  let last = 0;
  let i = 0;
  for (const m of text.matchAll(INLINE_RE)) {
    const idx = m.index ?? 0;
    if (idx > last) out.push(text.slice(last, idx));
    const tok = m[0];
    const k = `${keyBase}-${i++}`;
    if (m[1]) out.push(<code key={k} className="rounded-[3px] bg-tint-1 px-1 py-px font-mono text-[12.5px] text-danger">{tok.slice(1, -1)}</code>);
    else if (m[2]) out.push(<strong key={k} className="font-semibold">{inline(tok.slice(2, -2), k)}</strong>);
    else if (m[3]) out.push(<em key={k}>{tok.slice(1, -1)}</em>);
    else
      out.push(
        <a key={k} href={tok} target="_blank" rel="noopener noreferrer nofollow" className="text-brand-600 underline hover:text-brand-700">
          {tok}
        </a>,
      );
    last = idx + tok.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function withBreaks(lines: string[], keyBase: string) {
  return lines.flatMap((l, i) => (i === 0 ? inline(l, `${keyBase}-${i}`) : [<br key={`${keyBase}-br-${i}`} />, ...inline(l, `${keyBase}-${i}`)]));
}

function blocks(text: string): ReactNode[] {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  const out: ReactNode[] = [];
  let i = 0;
  let b = 0;
  while (i < lines.length) {
    const line = lines[i]!;
    if (!line.trim()) {
      i++;
      continue;
    }
    const key = `b${b++}`;
    if (/^\s*[-*]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i]!)) items.push(lines[i++]!.replace(/^\s*[-*]\s+/, ""));
      out.push(
        <ul key={key} className="list-disc space-y-0.5 pl-5">
          {items.map((it, j) => (
            <li key={j}>{inline(it, `${key}-${j}`)}</li>
          ))}
        </ul>,
      );
      continue;
    }
    if (/^\s*\d+[.)]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i]!)) items.push(lines[i++]!.replace(/^\s*\d+[.)]\s+/, ""));
      out.push(
        <ol key={key} className="list-decimal space-y-0.5 pl-5">
          {items.map((it, j) => (
            <li key={j}>{inline(it, `${key}-${j}`)}</li>
          ))}
        </ol>,
      );
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      const size = h[1]!.length === 1 ? "text-lg" : h[1]!.length === 2 ? "text-base" : "text-sm";
      out.push(
        <div key={key} className={cn("font-semibold text-ink", size)}>
          {inline(h[2]!, key)}
        </div>,
      );
      i++;
      continue;
    }
    const para: string[] = [];
    while (i < lines.length && lines[i]!.trim() && !/^\s*([-*]|\d+[.)])\s+/.test(lines[i]!) && !/^#{1,3}\s+/.test(lines[i]!)) para.push(lines[i++]!);
    out.push(<p key={key}>{withBreaks(para, key)}</p>);
  }
  return out;
}
