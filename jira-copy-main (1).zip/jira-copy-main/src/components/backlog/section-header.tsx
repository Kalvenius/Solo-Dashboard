"use client";

import { useState, useTransition } from "react";
import { ChevronDown, ChevronRight, Ellipsis, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Lozenge } from "@/components/ui/lozenge";
import { MenuItem, Popover } from "@/components/ui/popover";
import { createSprint } from "@/lib/actions/sprints";
import { useFormat, useT } from "@/i18n/client";
import { CompleteSprintModal, DeleteSprintModal, EditSprintModal, StartSprintModal, type SprintLite } from "./sprint-modals";

export type PointTotals = { todo: number; progress: number; done: number };

export function SectionHeader({
  projectId,
  sprint,
  collapsed,
  onToggle,
  issueCount,
  totals,
  canStart,
  doneCount,
  openCount,
  plannedSprints,
}: {
  projectId: string;
  /** null = Backlog bölməsi */
  sprint: SprintLite | null;
  collapsed: boolean;
  onToggle: () => void;
  issueCount: number;
  totals: PointTotals;
  /** bu, ilk planlaşdırılmış sprintdir və aktiv sprint yoxdur */
  canStart: boolean;
  doneCount: number;
  openCount: number;
  plannedSprints: { id: string; name: string }[];
}) {
  const t = useT("backlog");
  const tc = useT("common");
  const te = useT("enums");
  const f = useFormat();
  const [modal, setModal] = useState<null | "start" | "edit" | "delete" | "complete">(null);
  const [error, setError] = useState<string | null>(null);
  const [creating, startCreate] = useTransition();

  const dates = sprint?.startDate || sprint?.endDate ? `${f.date(sprint?.startDate)} – ${f.date(sprint?.endDate)}` : null;

  return (
    <div className="flex flex-wrap items-center gap-2 px-2 py-2">
      <button onClick={onToggle} className="flex min-w-0 items-center gap-1.5 rounded-[3px] px-1 py-0.5 text-left hover:bg-tint-1">
        {collapsed ? <ChevronRight className="h-4 w-4 shrink-0 text-ink-subtle" /> : <ChevronDown className="h-4 w-4 shrink-0 text-ink-subtle" />}
        <span className="truncate text-sm font-semibold text-ink">{sprint ? sprint.name : tc("backlog")}</span>
      </button>
      {sprint?.state === "ACTIVE" && <Lozenge tone="progress">{te("sprintState.ACTIVE")}</Lozenge>}
      {dates && <span className="text-xs text-ink-subtle">{dates}</span>}
      <span className="text-xs text-ink-subtle">{t("issueCount", { n: issueCount })}</span>
      {sprint?.goal && <span className="hidden max-w-[320px] truncate text-xs italic text-ink-subtle lg:inline">— {sprint.goal}</span>}

      <div className="ml-auto flex items-center gap-1.5">
        <span className="mr-1 flex items-center gap-1" title={t("pointsTitle")}>
          <Lozenge tone="todo">{totals.todo}</Lozenge>
          <Lozenge tone="progress">{totals.progress}</Lozenge>
          <Lozenge tone="done">{totals.done}</Lozenge>
        </span>

        {error && <span className="text-xs text-danger">{error}</span>}

        {sprint === null && (
          <Button
            size="sm"
            loading={creating}
            onClick={() =>
              startCreate(async () => {
                setError(null);
                const res = await createSprint(projectId);
                if (!res.ok) setError(res.error);
              })
            }
          >
            {t("createSprint")}
          </Button>
        )}
        {sprint?.state === "PLANNED" && canStart && (
          <Button size="sm" disabled={issueCount === 0} title={issueCount === 0 ? t("cantStartEmpty") : undefined} onClick={() => setModal("start")}>
            {t("startSprint")}
          </Button>
        )}
        {sprint?.state === "ACTIVE" && (
          <Button size="sm" onClick={() => setModal("complete")}>
            {t("completeSprint")}
          </Button>
        )}
        {sprint && (
          <Popover
            align="right"
            className="w-44"
            trigger={({ toggle }) => (
              <Button size="sm" variant="subtle" onClick={toggle} aria-label={t("sprintActions")} className="px-1.5">
                <Ellipsis className="h-4 w-4" />
              </Button>
            )}
          >
            {(close) => (
              <>
                <MenuItem
                  onClick={() => {
                    close();
                    setModal("edit");
                  }}
                >
                  <Pencil className="h-3.5 w-3.5" /> {tc("edit")}
                </MenuItem>
                {sprint.state === "PLANNED" && (
                  <MenuItem
                    danger
                    onClick={() => {
                      close();
                      setModal("delete");
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5" /> {tc("delete")}
                  </MenuItem>
                )}
              </>
            )}
          </Popover>
        )}
      </div>

      {sprint && (
        <>
          <StartSprintModal open={modal === "start"} onClose={() => setModal(null)} sprint={sprint} issueCount={issueCount} />
          <EditSprintModal open={modal === "edit"} onClose={() => setModal(null)} sprint={sprint} />
          <DeleteSprintModal open={modal === "delete"} onClose={() => setModal(null)} sprint={sprint} issueCount={issueCount} />
          <CompleteSprintModal
            open={modal === "complete"}
            onClose={() => setModal(null)}
            sprint={sprint}
            doneCount={doneCount}
            openCount={openCount}
            plannedSprints={plannedSprints}
          />
        </>
      )}
    </div>
  );
}
