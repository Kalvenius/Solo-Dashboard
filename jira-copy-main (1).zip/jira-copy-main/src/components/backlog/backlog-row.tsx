"use client";

import type { IssueCardData } from "@/lib/issue-select";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";
import { Avatar } from "@/components/ui/avatar";
import { StatusLozenge } from "@/components/ui/lozenge";
import { EpicTag, IssueTypeIcon, PointsBadge, PriorityIcon } from "@/components/issue/icons";

/** Backlog sətri: növ, açar, başlıq, epic, status, point, prioritet, icraçı */
export function BacklogRow({ issue, onOpen, dragging }: { issue: IssueCardData; onOpen?: (key: string) => void; dragging?: boolean }) {
  const t = useT("backlog");
  const epic = issue.parent?.type === "EPIC" ? issue.parent : null;
  const subCount = issue.type !== "EPIC" ? issue._count.children : 0;
  const done = issue.status === "DONE";
  return (
    <div
      role="button"
      tabIndex={-1}
      onClick={() => onOpen?.(issue.key)}
      className={cn("flex h-10 cursor-pointer select-none items-center gap-2 bg-surface-raised px-3 text-sm hover:bg-surface-hover", dragging && "opacity-40")}
    >
      <IssueTypeIcon type={issue.type} />
      <span className={cn("w-[72px] shrink-0 truncate text-xs font-semibold text-ink-subtle", done && "line-through")}>{issue.key}</span>
      <span className={cn("min-w-0 flex-1 truncate text-ink", done && "text-ink-muted")}>{issue.title}</span>
      {subCount > 0 && <span className="hidden shrink-0 text-xs text-ink-subtle sm:inline">{t("subtaskCount", { n: subCount })}</span>}
      {epic && <EpicTag title={epic.title} className="hidden md:inline-block" />}
      <StatusLozenge status={issue.status} className="shrink-0" />
      <span className="flex w-6 shrink-0 justify-center">
        <PointsBadge points={issue.storyPoints} />
      </span>
      <PriorityIcon priority={issue.priority} />
      <Avatar user={issue.assignee} size="sm" />
    </div>
  );
}
