"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Layers, X } from "lucide-react";
import { STATUS_META, type Status } from "@/lib/constants";
import type { IssueCardData } from "@/lib/issue-select";
import { moveIssue } from "@/lib/actions/board";
import { cn } from "@/lib/utils";
import { useT } from "@/i18n/client";
import { ProgressBar } from "@/components/ui/misc";
import { IssueTypeIcon } from "@/components/issue/icons";
import { useOpenIssue } from "@/components/issue/use-open-issue";
import { AssigneeFilter, SearchBox, ToggleChip, type MemberLite } from "@/components/board/filters";
import { QuickCreate } from "@/components/board/quick-create";
import { isBelow, neighbors, normalize, preferItems, rankBetween } from "@/components/board/dnd-utils";
import { BacklogRow } from "./backlog-row";
import { SectionHeader, type PointTotals } from "./section-header";
import type { SprintLite } from "./sprint-modals";

export type EpicProgress = { id: string; key: string; title: string; status: string; done: number; total: number };

const BACKLOG = "backlog";
const epicIdOf = (i: IssueCardData) => (i.parent?.type === "EPIC" ? i.parent.id : "none");

export function Backlog({
  projectId,
  sprints,
  issues: serverIssues,
  epics,
  members,
  currentUserId,
}: {
  projectId: string;
  /** aktiv + planlaşdırılmış sprintlər (sıralı) */
  sprints: SprintLite[];
  issues: IssueCardData[];
  epics: EpicProgress[];
  members: MemberLite[];
  currentUserId: string;
}) {
  const { open } = useOpenIssue();
  const t = useT("backlog");
  const tb = useT("board");
  const tc = useT("common");
  const [issues, setIssuesState] = useState(serverIssues);
  const issuesRef = useRef(serverIssues);
  const setIssues = useCallback((next: IssueCardData[]) => {
    issuesRef.current = next;
    setIssuesState(next);
  }, []);
  const dragging = useRef(false);
  const snapshot = useRef<IssueCardData[] | null>(null);

  useEffect(() => {
    if (!dragging.current) setIssues(serverIssues);
  }, [serverIssues, setIssues]);

  const [q, setQ] = useState("");
  const [assignees, setAssignees] = useState<Set<string>>(new Set());
  const [onlyMine, setOnlyMine] = useState(false);
  const [epic, setEpic] = useState<string | null>(null);
  const [showEpics, setShowEpics] = useState(false);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [activeId, setActiveId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const sprintIds = useMemo(() => new Set(sprints.map((s) => s.id)), [sprints]);
  const containerOfIssue = useCallback((i: IssueCardData) => (i.sprintId && sprintIds.has(i.sprintId) ? i.sprintId : BACKLOG), [sprintIds]);

  const matches = useCallback(
    (i: IssueCardData) => {
      if (q && !normalize(`${i.key} ${i.title}`).includes(normalize(q))) return false;
      if (onlyMine && i.assignee?.id !== currentUserId) return false;
      if (assignees.size && !assignees.has(i.assignee?.id ?? "none")) return false;
      if (epic && epicIdOf(i) !== epic) return false;
      return true;
    },
    [q, onlyMine, assignees, epic, currentUserId],
  );
  const anyFilter = !!q || assignees.size > 0 || onlyMine || !!epic;

  const containersFrom = useCallback(
    (list: IssueCardData[]) => {
      const map: Record<string, string[]> = { [BACKLOG]: [] };
      for (const s of sprints) map[s.id] = [];
      for (const i of list.filter(matches).sort((a, b) => a.rank - b.rank)) map[containerOfIssue(i)]!.push(i.id);
      return map;
    },
    [sprints, matches, containerOfIssue],
  );
  const containers = useMemo(() => containersFrom(issues), [containersFrom, issues]);
  const byId = useMemo(() => new Map(issues.map((i) => [i.id, i])), [issues]);

  // Bölmə statistikası filtrsiz hesablanır
  const stats = useMemo(() => {
    const out: Record<string, { count: number; totals: PointTotals; done: number; open: number }> = {};
    for (const id of [BACKLOG, ...sprints.map((s) => s.id)]) out[id] = { count: 0, totals: { todo: 0, progress: 0, done: 0 }, done: 0, open: 0 };
    for (const i of issues) {
      const s = out[containerOfIssue(i)]!;
      s.count++;
      const cat = STATUS_META[i.status as Status]?.category ?? "todo";
      s.totals[cat] += i.storyPoints ?? 0;
      if (i.status === "DONE") s.done++;
      else s.open++;
    }
    return out;
  }, [issues, sprints, containerOfIssue]);

  const hasActive = sprints.some((s) => s.state === "ACTIVE");
  const firstPlanned = sprints.find((s) => s.state === "PLANNED");
  const plannedSprints = sprints.filter((s) => s.state === "PLANNED").map((s) => ({ id: s.id, name: s.name }));

  // ---------- sürükləmə ----------
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );
  const collision = useMemo(() => preferItems((id) => id === BACKLOG || sprintIds.has(String(id))), [sprintIds]);
  const findContainer = (id: string) => {
    if (id === BACKLOG || sprintIds.has(id)) return id;
    const i = issuesRef.current.find((x) => x.id === id);
    return i ? containerOfIssue(i) : null;
  };
  const rankOf = (id: string | undefined) => (id ? issuesRef.current.find((i) => i.id === id)?.rank : undefined);
  const relocate = (id: string, container: string, rank: number) => {
    setIssues(issuesRef.current.map((i) => (i.id === id ? { ...i, sprintId: container === BACKLOG ? null : container, rank } : i)));
  };
  const revert = () => snapshot.current && setIssues(snapshot.current);

  const onDragStart = (e: DragStartEvent) => {
    dragging.current = true;
    snapshot.current = issuesRef.current;
    setActiveId(String(e.active.id));
    setError(null);
  };

  const onDragOver = ({ active, over }: DragOverEvent) => {
    if (!over) return;
    const a = findContainer(String(active.id));
    const o = findContainer(String(over.id));
    if (!a || !o || a === o) return;
    const list = (containersFrom(issuesRef.current)[o] ?? []).filter((x) => x !== active.id);
    let index = list.length;
    const overIndex = list.indexOf(String(over.id));
    if (overIndex >= 0) index = overIndex + (isBelow(active, over) ? 1 : 0);
    relocate(String(active.id), o, rankBetween(rankOf(list[index - 1]), rankOf(list[index])));
  };

  const onDragEnd = async ({ active, over }: DragEndEvent) => {
    setActiveId(null);
    const id = String(active.id);
    const before = snapshot.current?.find((i) => i.id === id);
    if (!over || !before) {
      revert();
      dragging.current = false;
      return;
    }
    const container = findContainer(id)!;
    let list = (containersFrom(issuesRef.current)[container] ?? []).slice();
    if (!list.includes(id)) list.push(id);
    const overId = String(over.id);
    if (overId !== id && list.includes(overId)) {
      list = arrayMove(list, list.indexOf(id), list.indexOf(overId));
      const idx = list.indexOf(id);
      relocate(id, container, rankBetween(rankOf(list[idx - 1]), rankOf(list[idx + 1])));
    }
    const origContainer = containerOfIssue(before);
    const origList = containersFrom(snapshot.current!)[origContainer] ?? [];
    const orig = neighbors(origList, id);
    const now = neighbors(list, id);
    dragging.current = false;
    const sprintChanged = container !== origContainer;
    if (!sprintChanged && orig.beforeId === now.beforeId && orig.afterId === now.afterId) return;

    const res = await moveIssue(id, {
      sprintId: sprintChanged ? (container === BACKLOG ? null : container) : undefined,
      beforeId: now.beforeId,
      afterId: now.afterId,
    });
    if (!res.ok) {
      revert();
      setError(res.error);
    }
  };

  const toggleCollapsed = (id: string) =>
    setCollapsed((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const activeIssue = activeId ? byId.get(activeId) : null;
  const sections: { id: string; sprint: SprintLite | null }[] = [...sprints.map((s) => ({ id: s.id, sprint: s })), { id: BACKLOG, sprint: null }];
  const selectedEpic = epics.find((e) => e.id === epic);

  return (
    <div className="flex min-h-0 flex-1 gap-4">
      {showEpics && (
        <EpicPanel
          projectId={projectId}
          epics={epics}
          selected={epic}
          onSelect={setEpic}
          onClose={() => setShowEpics(false)}
          onOpen={open}
        />
      )}

      <div className="min-w-0 flex-1">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <SearchBox value={q} onChange={setQ} placeholder={t("searchBacklog")} />
          <AssigneeFilter
            members={members}
            selected={assignees}
            onToggle={(id) =>
              setAssignees((prev) => {
                const n = new Set(prev);
                if (n.has(id)) n.delete(id);
                else n.add(id);
                return n;
              })
            }
          />
          <ToggleChip active={onlyMine} onClick={() => setOnlyMine((v) => !v)}>
            {tb("onlyMine")}
          </ToggleChip>
          <ToggleChip active={showEpics || !!epic} onClick={() => setShowEpics((v) => !v)}>
            <Layers className="h-4 w-4" /> {tc("epic")}
            {selectedEpic ? `: ${selectedEpic.title}` : epic === "none" ? `: ${t("noEpic")}` : ""}
          </ToggleChip>
          {anyFilter && (
            <button
              onClick={() => {
                setQ("");
                setAssignees(new Set());
                setOnlyMine(false);
                setEpic(null);
              }}
              className="inline-flex h-8 items-center gap-1 px-2 text-sm text-ink-muted hover:text-ink"
            >
              <X className="h-3.5 w-3.5" /> {tb("clearFilters")}
            </button>
          )}
        </div>

        {error && (
          <div className="mb-3 flex items-center justify-between rounded-[3px] border border-danger-border bg-danger-subtle px-3 py-2 text-sm text-danger">
            {error}
            <button onClick={() => setError(null)} aria-label={tc("close")}>
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        <DndContext
          id="backlog-dnd"
          sensors={sensors}
          collisionDetection={collision}
          onDragStart={onDragStart}
          onDragOver={onDragOver}
          onDragEnd={onDragEnd}
          onDragCancel={() => {
            revert();
            dragging.current = false;
            setActiveId(null);
          }}
        >
          <div className="space-y-3 pb-10">
            {sections.map(({ id, sprint }) => {
              const st = stats[id]!;
              const isCollapsed = collapsed.has(id);
              return (
                <Section key={id} id={id} isBacklog={!sprint} active={sprint?.state === "ACTIVE"}>
                  <SectionHeader
                    projectId={projectId}
                    sprint={sprint}
                    collapsed={isCollapsed}
                    onToggle={() => toggleCollapsed(id)}
                    issueCount={st.count}
                    totals={st.totals}
                    canStart={!!sprint && sprint.id === firstPlanned?.id && !hasActive}
                    doneCount={st.done}
                    openCount={st.open}
                    plannedSprints={plannedSprints}
                  />
                  {!isCollapsed && (
                    <div className="px-2 pb-2">
                      <SortableContext id={id} items={containers[id] ?? []} strategy={verticalListSortingStrategy}>
                        <div className="overflow-hidden rounded-[3px] border border-line bg-surface-raised empty:hidden">
                          {(containers[id] ?? []).map((iid) => {
                            const issue = byId.get(iid);
                            return issue ? <SortableRow key={iid} issue={issue} onOpen={open} hidden={activeId === iid} /> : null;
                          })}
                        </div>
                      </SortableContext>
                      {(containers[id] ?? []).length === 0 && (
                        <div className="rounded-[3px] border-2 border-dashed border-line px-4 py-5 text-center text-sm text-ink-subtle">
                          {st.count > 0 ? tb("noMatches") : sprint ? t("emptySprint") : t("emptyBacklog")}
                        </div>
                      )}
                      <div className="mt-1">
                        <QuickCreate
                          projectId={projectId}
                          variant="row"
                          label={t("createIssue")}
                          types={["STORY", "TASK", "BUG"]}
                          defaultType="STORY"
                          defaults={{ sprintId: sprint?.id ?? null, parentId: epic && epic !== "none" ? epic : null }}
                        />
                      </div>
                    </div>
                  )}
                </Section>
              );
            })}
          </div>

          <DragOverlay dropAnimation={{ duration: 180, easing: "cubic-bezier(0.2, 0, 0, 1)" }}>
            {activeIssue ? (
              <div className="overflow-hidden rounded-[3px] border border-line bg-surface-raised shadow-overlay">
                <BacklogRow issue={activeIssue} />
              </div>
            ) : null}
          </DragOverlay>
        </DndContext>
      </div>
    </div>
  );
}

function Section({ id, isBacklog, active, children }: { id: string; isBacklog: boolean; active: boolean; children: React.ReactNode }) {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <section
      ref={setNodeRef}
      className={cn(
        "rounded-[3px] transition-colors",
        isBacklog ? "bg-transparent" : "bg-surface-column",
        active && "ring-1 ring-inset ring-brand-200",
        isOver && "bg-brand-50",
      )}
    >
      {children}
    </section>
  );
}

function SortableRow({ issue, onOpen, hidden }: { issue: IssueCardData; onOpen: (key: string) => void; hidden: boolean }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: issue.id });
  return (
    <div ref={setNodeRef} style={{ transform: CSS.Translate.toString(transform), transition }} {...attributes} {...listeners} className="border-b border-line last:border-b-0">
      <BacklogRow issue={issue} onOpen={onOpen} dragging={hidden} />
    </div>
  );
}

function EpicPanel({
  projectId,
  epics,
  selected,
  onSelect,
  onClose,
  onOpen,
}: {
  projectId: string;
  epics: EpicProgress[];
  selected: string | null;
  onSelect: (id: string | null) => void;
  onClose: () => void;
  onOpen: (key: string) => void;
}) {
  const t = useT("backlog");
  const tb = useT("board");
  const tc = useT("common");
  const te = useT("enums");
  const item = (id: string | null, label: React.ReactNode) => (
    <button
      onClick={() => onSelect(id)}
      className={cn(
        "flex w-full items-center rounded-[3px] px-2 py-1.5 text-left text-sm hover:bg-tint-1",
        selected === id && "bg-brand-50 font-medium text-brand-700 hover:bg-brand-50",
      )}
    >
      {label}
    </button>
  );
  return (
    <aside className="w-64 shrink-0 self-start rounded-[3px] border border-line bg-surface-raised">
      <div className="flex items-center justify-between border-b border-line px-3 py-2">
        <span className="text-sm font-semibold text-ink">{t("epics")}</span>
        <button onClick={onClose} className="rounded p-0.5 text-ink-subtle hover:bg-surface-hover" aria-label={tc("close")}>
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="space-y-0.5 p-2">
        {item(null, t("allIssues"))}
        {epics.map((e) => (
          <div
            key={e.id}
            className={cn("group rounded-[3px] border border-transparent p-2 hover:bg-tint-1", selected === e.id && "border-brand-200 bg-brand-50 hover:bg-brand-50")}
          >
            <button onClick={() => onSelect(selected === e.id ? null : e.id)} className="block w-full text-left">
              <div className="flex items-start gap-1.5">
                <IssueTypeIcon type="EPIC" className="mt-0.5" />
                <span className={cn("text-sm text-ink", e.status === "DONE" && "line-through text-ink-muted")}>{e.title}</span>
              </div>
              <ProgressBar
                className="mt-2"
                segments={[
                  { value: e.done, color: "rgb(var(--c-success-bold))", label: te("status.DONE") },
                  { value: e.total - e.done, color: "rgb(var(--c-neutral))", label: t("progressRemaining") },
                ]}
              />
              <div className="mt-1 text-[11px] text-ink-subtle">
                {t("epicDoneOf", { done: e.done, total: e.total })}
              </div>
            </button>
            <button onClick={() => onOpen(e.key)} className="mt-1 text-[11px] font-medium text-brand-600 opacity-0 hover:underline group-hover:opacity-100">
              {t("epicDetails", { key: e.key })}
            </button>
          </div>
        ))}
        {item("none", <span className="text-ink-muted">{tb("issuesWithoutEpic")}</span>)}
        <div className="pt-1">
          <QuickCreate projectId={projectId} variant="row" label={t("createEpic")} types={["EPIC"]} defaultType="EPIC" />
        </div>
      </div>
    </aside>
  );
}
