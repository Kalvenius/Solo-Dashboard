"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addDays, addWeeks } from "date-fns";
import { Button } from "@/components/ui/button";
import { Field, FormError, Input, Select, Textarea } from "@/components/ui/input";
import { Modal } from "@/components/ui/modal";
import { completeSprint, deleteSprint, startSprint, updateSprint } from "@/lib/actions/sprints";
import { toDateInput } from "@/lib/utils";
import { useT } from "@/i18n/client";

export type SprintLite = {
  id: string;
  name: string;
  goal: string | null;
  state: string;
  startDate: Date | string | null;
  endDate: Date | string | null;
};

const DURATION_WEEKS = ["1", "2", "3", "4"] as const;

function endFrom(start: string, weeks: number) {
  const d = start ? new Date(start + "T00:00:00") : new Date();
  return toDateInput(addDays(addWeeks(d, weeks), -1));
}

/** Sprinti başlat modalı — ad, müddət, tarixlər, məqsəd */
export function StartSprintModal({ open, onClose, sprint, issueCount }: { open: boolean; onClose: () => void; sprint: SprintLite; issueCount: number }) {
  const t = useT("backlog");
  const tc = useT("common");
  const today = toDateInput(new Date());
  const [name, setName] = useState(sprint.name);
  const [goal, setGoal] = useState(sprint.goal ?? "");
  const [duration, setDuration] = useState("2");
  const [start, setStart] = useState(today);
  const [end, setEnd] = useState(endFrom(today, 2));
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  useEffect(() => {
    if (open) {
      setName(sprint.name);
      setGoal(sprint.goal ?? "");
      setDuration("2");
      setStart(today);
      setEnd(endFrom(today, 2));
      setError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, sprint.id]);

  const changeDuration = (v: string) => {
    setDuration(v);
    if (v !== "custom") setEnd(endFrom(start, Number(v)));
  };
  const changeStart = (v: string) => {
    setStart(v);
    if (duration !== "custom") setEnd(endFrom(v, Number(duration)));
  };

  const submit = () =>
    startTransition(async () => {
      setError(null);
      const res = await startSprint(sprint.id, { name, goal, startDate: start, endDate: end });
      if (!res.ok) return setError(res.error);
      onClose();
    });

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={t("startSprint")}
      footer={
        <>
          <Button variant="subtle" onClick={onClose}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" onClick={submit} loading={pending}>
            {t("start")}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <p className="text-sm text-ink-muted">{t("sprintIncludes", { n: issueCount })}</p>
        <FormError message={error} />
        <Field label={t("sprintName")} htmlFor="sprint-name" required>
          <Input id="sprint-name" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
        </Field>
        <div className="grid grid-cols-3 gap-3">
          <Field label={t("duration")} htmlFor="sprint-duration">
            <Select id="sprint-duration" value={duration} onChange={(e) => changeDuration(e.target.value)}>
              {DURATION_WEEKS.map((w) => (
                <option key={w} value={w}>
                  {t("weeks", { n: Number(w) })}
                </option>
              ))}
              <option value="custom">{t("customDuration")}</option>
            </Select>
          </Field>
          <Field label={tc("startDate")} htmlFor="sprint-start" required>
            <Input id="sprint-start" type="date" value={start} onChange={(e) => changeStart(e.target.value)} />
          </Field>
          <Field label={t("endDate")} htmlFor="sprint-end" required>
            <Input id="sprint-end" type="date" value={end} disabled={duration !== "custom"} onChange={(e) => setEnd(e.target.value)} />
          </Field>
        </div>
        <Field label={t("sprintGoal")} htmlFor="sprint-goal">
          <Textarea id="sprint-goal" value={goal} onChange={(e) => setGoal(e.target.value)} placeholder={t("goalPlaceholder")} />
        </Field>
      </div>
    </Modal>
  );
}

/** Sprinti redaktə et — ad, məqsəd, tarixlər */
export function EditSprintModal({ open, onClose, sprint }: { open: boolean; onClose: () => void; sprint: SprintLite }) {
  const t = useT("backlog");
  const tc = useT("common");
  const [name, setName] = useState(sprint.name);
  const [goal, setGoal] = useState(sprint.goal ?? "");
  const [start, setStart] = useState(toDateInput(sprint.startDate));
  const [end, setEnd] = useState(toDateInput(sprint.endDate));
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  useEffect(() => {
    if (open) {
      setName(sprint.name);
      setGoal(sprint.goal ?? "");
      setStart(toDateInput(sprint.startDate));
      setEnd(toDateInput(sprint.endDate));
      setError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, sprint.id]);

  const submit = () =>
    startTransition(async () => {
      setError(null);
      const res = await updateSprint(sprint.id, { name, goal, startDate: start || null, endDate: end || null });
      if (!res.ok) return setError(res.error);
      onClose();
    });

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={t("editSprint")}
      footer={
        <>
          <Button variant="subtle" onClick={onClose}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" onClick={submit} loading={pending}>
            {tc("save")}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <FormError message={error} />
        <Field label={t("sprintName")} htmlFor="edit-sprint-name" required>
          <Input id="edit-sprint-name" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={tc("startDate")} htmlFor="edit-sprint-start">
            <Input id="edit-sprint-start" type="date" value={start} onChange={(e) => setStart(e.target.value)} />
          </Field>
          <Field label={t("endDate")} htmlFor="edit-sprint-end">
            <Input id="edit-sprint-end" type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
          </Field>
        </div>
        <Field label={t("sprintGoal")} htmlFor="edit-sprint-goal">
          <Textarea id="edit-sprint-goal" value={goal} onChange={(e) => setGoal(e.target.value)} />
        </Field>
      </div>
    </Modal>
  );
}

/**
 * Sprinti tamamla modalı. Lövhə və backlog-da istifadə olunur.
 * Bitməmiş tapşırıqlar backlog-a, planlaşdırılmış sprintə və ya yeni sprintə köçür.
 */
export function CompleteSprintModal({
  open,
  onClose,
  sprint,
  doneCount,
  openCount,
  plannedSprints,
  onCompleted,
}: {
  open: boolean;
  onClose: () => void;
  sprint: { id: string; name: string };
  doneCount: number;
  openCount: number;
  plannedSprints: { id: string; name: string }[];
  onCompleted?: () => void;
}) {
  const t = useT("backlog");
  const tc = useT("common");
  const [target, setTarget] = useState("backlog");
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  useEffect(() => {
    if (open) {
      setTarget("backlog");
      setError(null);
    }
  }, [open]);

  const submit = () =>
    startTransition(async () => {
      setError(null);
      const res = await completeSprint(sprint.id, target);
      if (!res.ok) return setError(res.error);
      onClose();
      onCompleted?.();
    });

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={t("completeTitle", { name: sprint.name })}
      footer={
        <>
          <Button variant="subtle" onClick={onClose}>
            {tc("cancel")}
          </Button>
          <Button variant="primary" onClick={submit} loading={pending}>
            {t("completeSprint")}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <FormError message={error} />
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-[3px] border border-line bg-success-subtle p-3">
            <div className="text-2xl font-semibold text-success">{doneCount}</div>
            <div className="text-xs text-ink-subtle">{t("doneLabel")}</div>
          </div>
          <div className="rounded-[3px] border border-line bg-surface-sunken p-3">
            <div className="text-2xl font-semibold text-ink">{openCount}</div>
            <div className="text-xs text-ink-subtle">{t("openLabel")}</div>
          </div>
        </div>
        {openCount > 0 ? (
          <Field label={t("moveOpenTo")} htmlFor="complete-target">
            <Select id="complete-target" value={target} onChange={(e) => setTarget(e.target.value)}>
              <option value="backlog">{tc("backlog")}</option>
              {plannedSprints.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
              <option value="new">{t("newSprint")}</option>
            </Select>
          </Field>
        ) : (
          <p className="text-sm text-ink-muted">{t("allDone")}</p>
        )}
      </div>
    </Modal>
  );
}

/** Planlaşdırılmış sprinti silmək üçün təsdiq modalı */
export function DeleteSprintModal({ open, onClose, sprint, issueCount }: { open: boolean; onClose: () => void; sprint: { id: string; name: string }; issueCount: number }) {
  const t = useT("backlog");
  const tc = useT("common");
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const submit = () =>
    startTransition(async () => {
      setError(null);
      const res = await deleteSprint(sprint.id);
      if (!res.ok) return setError(res.error);
      onClose();
      router.refresh();
    });

  return (
    <Modal
      open={open}
      onClose={onClose}
      width="sm"
      title={t("deleteTitle")}
      footer={
        <>
          <Button variant="subtle" onClick={onClose}>
            {tc("cancel")}
          </Button>
          <Button variant="danger" onClick={submit} loading={pending}>
            {tc("delete")}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <FormError message={error} />
        <p className="text-sm text-ink-muted">
          {t("deleteText", { name: sprint.name })}
          {issueCount > 0 && ` ${t("deleteMoves", { n: issueCount })}`}
        </p>
      </div>
    </Modal>
  );
}
